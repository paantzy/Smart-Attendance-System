import React, { useEffect } from 'react';
import { Platform, View, Text } from 'react-native';
import { NativeTabs, Icon, Label } from 'expo-router/unstable-native-tabs';
import { Stack, useRouter, useSegments } from 'expo-router';
import FloatingTabBar, { TabBarItem } from '@/components/FloatingTabBar';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { getTabsForRole } from '@/utils/roleManager';

export default function TabLayout() {
  const { userRole, loading } = useAuth();
  const router = useRouter();
  const segments = useSegments();

  // Show loading state while auth is loading
  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Loading...</Text>
      </View>
    );
  }

  // Redirect to login if no role is set
  useEffect(() => {
    if (userRole === undefined || userRole === null) {
      // Still loading, don't redirect yet
      return;
    }
    
    if (!userRole && segments[0] === '(tabs)') {
      router.replace('/login');
    }
  }, [userRole, segments]);

  // If no role is set, don't render the tabs
  if (userRole === undefined || userRole === null) {
    return null;
  }

  // Define the tabs configuration based on user role
  const tabs: TabBarItem[] = getTabsForRole(userRole as any);

  // Use NativeTabs for iOS, custom FloatingTabBar for Android and Web
  if (Platform.OS === 'ios') {
    return (
      <NativeTabs>
        {tabs.map((tab) => (
          <NativeTabs.Trigger key={tab.name} name={tab.name}>
            <Icon 
              sf={tab.icon as any} 
              drawable={`ic_${tab.name}`} 
            />
            <Label>{tab.label}</Label>
          </NativeTabs.Trigger>
        ))}
      </NativeTabs>
    );
  }

  // For Android and Web, use Stack navigation with custom floating tab bar
  return (
    <>
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'slide_from_right',
        }}
      >
        {/* Define screens based on the tabs that are actually needed */}
        {tabs.map((tab) => (
          <Stack.Screen 
            key={tab.name}
            name={tab.name}
            options={{ 
              title: tab.label,
            }} 
          />
        ))}
        <Stack.Screen 
          name="student-profile" 
          options={{ 
            title: 'Student Profile',
            presentation: 'modal',
            headerShown: true,
            headerStyle: {
              backgroundColor: colors.background,
            },
            headerTintColor: colors.text,
            headerTitleStyle: {
              color: colors.text,
            },
          }} 
        />
        <Stack.Screen 
          name="attendance-history" 
          options={{ 
            title: 'Attendance History',
            presentation: 'card',
            headerShown: true,
            headerStyle: {
              backgroundColor: colors.background,
            },
            headerTintColor: colors.text,
            headerTitleStyle: {
              color: colors.text,
            },
          }} 
        />
      </Stack>
      <FloatingTabBar tabs={tabs} />
    </>
  );
}