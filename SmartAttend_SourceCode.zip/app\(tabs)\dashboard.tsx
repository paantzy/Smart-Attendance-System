import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView, useWindowDimensions, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { router } from 'expo-router';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { PieChart, LineChart } from 'react-native-chart-kit';
import { getStudents } from '../../utils/studentOperations';
import { getAttendanceRecords } from '../../utils/attendanceOperations';
import { supabase } from '../../utils/supabase';
import { useAuth } from '@/contexts/AuthContext'; // Add this import
import moment from 'moment-timezone';

interface AttendanceData {
  present: number;
  absent: number;
  late: number;
  total: number;
}

interface RecentSession {
  id: string;
  className: string;
  date: string;
  time: string;
  present: number;
  total: number;
}

interface WeeklyTrendData {
  labels: string[];
  datasets: {
    data: number[];
    color: (opacity: number) => string;
    strokeWidth: number;
  }[];
}

export default function DashboardScreen() {
  const { userRole } = useAuth(); // Add this line to get user role
  const { width: screenWidth } = useWindowDimensions();
  const [attendanceData, setAttendanceData] = useState<AttendanceData>({
    present: 0,
    absent: 0,
    late: 0,
    total: 0,
  });
  
  const [totalStudents, setTotalStudents] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [weeklyTrend, setWeeklyTrend] = useState<WeeklyTrendData>({
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        data: [0, 0, 0, 0, 0, 0, 0],
        color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
        strokeWidth: 3,
      },
    ],
  });

  const [recentSessions, setRecentSessions] = useState<RecentSession[]>([]);

  // Fetch all data from database
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch students
        const students = await getStudents();
        const studentCount = students.length;
        setTotalStudents(studentCount);
        
        // Fetch attendance records
        const attendanceRecords = await getAttendanceRecords();
        
        // Calculate today's attendance data
        const today = moment().tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD');
        const todayRecords = attendanceRecords.filter(record => {
          const recordDate = record.check_in_time 
            ? moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD')
            : null;
          return recordDate === today;
        });
        
        // Count present, absent, and late students
        const presentCount = todayRecords.length;
        // For absent count, we need to calculate students who didn't check in today
        const absentCount = studentCount - presentCount;
        // For late count, we would need a specific time threshold - for now we'll set it to 0
        const lateCount = 0;
        
        setAttendanceData({
          present: presentCount,
          absent: absentCount,
          late: lateCount,
          total: studentCount,
        });
        
        // Generate 7-day trend data
        const generateWeeklyTrend = () => {
          const labels = [];
          const data = [];
          
          for (let i = 6; i >= 0; i--) {
            const date = moment().tz('Asia/Kuala_Lumpur').subtract(i, 'days');
            const dateStr = date.format('YYYY-MM-DD');
            labels.push(date.format('ddd'));
            
            const dayRecords = attendanceRecords.filter(record => {
              const recordDate = record.check_in_time 
                ? moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD')
                : null;
              return recordDate === dateStr;
            });
            
            // Calculate attendance percentage for this day
            const percentage = studentCount > 0 
              ? Math.round((dayRecords.length / studentCount) * 100)
              : 0;
              
            data.push(percentage);
          }
          
          return {
            labels,
            datasets: [
              {
                data,
                color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
                strokeWidth: 3,
              },
            ],
          };
        };
        
        setWeeklyTrend(generateWeeklyTrend());
        
        // Generate recent sessions data
        const generateRecentSessions = () => {
          // Group attendance records by class and date
          const sessionMap: { [key: string]: { className: string; date: string; time: string; present: number; total: number } } = {};
          
          // Get unique classes and dates from attendance records
          const classDateMap: { [key: string]: { className: string; date: string; time: string; students: Set<string> } } = {};
          
          attendanceRecords.forEach(record => {
            if (record.check_in_time && record.class_name) {
              const recordDate = moment(record.check_in_time).tz('Asia/Kuala_Lumpur');
              const dateStr = recordDate.format('YYYY-MM-DD');
              const timeStr = recordDate.format('hh:mm A');
              const key = `${record.class_name}-${dateStr}`;
              
              if (!classDateMap[key]) {
                classDateMap[key] = {
                  className: record.class_name,
                  date: dateStr,
                  time: timeStr,
                  students: new Set()
                };
              }
              
              classDateMap[key].students.add(record.student_id);
            }
          });
          
          // Convert to recent sessions array
          const sessions: RecentSession[] = Object.values(classDateMap)
            .map(item => ({
              id: `${item.className}-${item.date}`,
              className: item.className,
              date: item.date === today ? 'Today' : moment(item.date).format('MMM D'),
              time: item.time,
              present: item.students.size,
              total: studentCount // This should be class-specific student count
            }))
            .sort((a, b) => b.date.localeCompare(a.date))
            .slice(0, 3); // Get only the 3 most recent sessions
          
          return sessions;
        };
        
        setRecentSessions(generateRecentSessions());
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        Alert.alert('Error', 'Failed to fetch dashboard data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    // Set up real-time listeners
    const studentsChannel = supabase
      .channel('students-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'students',
        },
        (payload) => {
          // A new student was added, increment the count
          setTotalStudents(prev => prev + 1);
          setAttendanceData(prev => ({
            ...prev,
            total: prev.total + 1
          }));
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'students',
        },
        (payload) => {
          // A student was deleted, decrement the count
          setTotalStudents(prev => prev - 1);
          setAttendanceData(prev => ({
            ...prev,
            total: prev.total - 1
          }));
        }
      )
      .subscribe();
      
    const attendanceChannel = supabase
      .channel('attendance-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'attendance',
        },
        (payload) => {
          // Refresh dashboard data when new attendance record is added
          fetchData();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'attendance',
        },
        (payload) => {
          // Refresh dashboard data when attendance record is updated
          fetchData();
        }
      )
      .subscribe();

    // Clean up the subscriptions
    return () => {
      supabase.removeChannel(studentsChannel);
      supabase.removeChannel(attendanceChannel);
    };
  }, []);

  // Redirect parents to parent-specific dashboard
  useEffect(() => {
    if (userRole === 'parent') {
      router.replace('/(tabs)/parent-dashboard');
    }
  }, [userRole]);

  const attendanceRate = totalStudents > 0 
    ? Math.round((attendanceData.present / totalStudents) * 100)
    : 0;

  const pieData = [
    {
      name: 'Present',
      population: attendanceData.present,
      color: colors.success,
      legendFontColor: colors.text,
      legendFontSize: 14,
    },
    {
      name: 'Absent',
      population: attendanceData.absent,
      color: colors.error,
      legendFontColor: colors.text,
      legendFontSize: 14,
    },
    {
      name: 'Late',
      population: attendanceData.late,
      color: colors.warning,
      legendFontColor: colors.text,
      legendFontSize: 14,
    },
  ];

  const chartConfig = {
    backgroundColor: colors.card,
    backgroundGradientFrom: colors.card,
    backgroundGradientTo: colors.card,
    decimalPlaces: 0,
    color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
    labelColor: (opacity = 1) => `rgba(33, 33, 33, ${opacity})`,
    style: {
      borderRadius: 16,
    },
    propsForDots: {
      r: '6',
      strokeWidth: '2',
      stroke: colors.primary,
    },
  };

  const StatCard = ({ title, value, subtitle, icon, color }: {
    title: string;
    value: string;
    subtitle?: string;
    icon: string;
    color: string;
  }) => (
    <View style={[styles.statCard, commonStyles.card]}>
      <View style={styles.statHeader}>
        <View style={[styles.statIcon, { backgroundColor: color }]}>
          <IconSymbol name={icon as any} size={24} color={colors.card} />
        </View>
        <Text style={styles.statTitle}>{title}</Text>
      </View>
      <Text style={styles.statValue}>{value}</Text>
      {subtitle && <Text style={styles.statSubtitle}>{subtitle}</Text>}
    </View>
  );

  const SessionCard = ({ session }: { session: RecentSession }) => (
    <View style={[styles.sessionCard, commonStyles.card]}>
      <View style={styles.sessionHeader}>
        <View>
          <Text style={styles.sessionClass}>{session.className}</Text>
          <Text style={styles.sessionTime}>{session.date} • {session.time}</Text>
        </View>
        <View style={styles.attendanceIndicator}>
          <Text style={styles.attendanceText}>
            {session.present}/{session.total}
          </Text>
          <View style={[
            styles.attendanceBadge,
            { backgroundColor: session.present === session.total ? colors.success : colors.warning }
          ]}>
            <Text style={styles.attendanceBadgeText}>
              {session.total > 0 ? Math.round((session.present / session.total) * 100) : 0}%
            </Text>
          </View>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <ScrollView 
        style={commonStyles.container}
        contentContainerStyle={[commonStyles.scrollContent, { paddingTop: spacing.md }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={commonStyles.content}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.headerContent}>
              <View style={{ flex: 1 }} />
              <View style={styles.titleContainer}>
                <Text style={styles.dashboardTitle} numberOfLines={1}>
                  SmartAttend
                </Text>
              </View>
              <View style={{ flex: 1 }} />
            </View>
            <Text style={commonStyles.caption}>
              {moment().tz('Asia/Kuala_Lumpur').format('dddd, MMMM D, YYYY')}
            </Text>
          </View>

          {/* Stats Cards */}
          <View style={styles.statsGrid}>
            <TouchableOpacity 
              style={styles.statCardWrapper}
              onPress={() => router.push('/(tabs)/students')}
            >
              <StatCard
                title="Total Students"
                value={loading ? 'Loading...' : totalStudents.toString()}
                subtitle="Enrolled"
                icon="person"
                color={colors.primary}
              />
            </TouchableOpacity>
            <StatCard
              title="Present Today"
              value={loading ? 'Loading...' : attendanceData.present.toString()}
              subtitle={loading ? '' : `${attendanceRate}% attendance`}
              icon="checkmark"
              color={colors.success}
            />
            <StatCard
              title="Absent Today"
              value={loading ? 'Loading...' : attendanceData.absent.toString()}
              subtitle="Students missing"
              icon="xmark"
              color={colors.error}
            />
            <StatCard
              title="Late Today"
              value={loading ? 'Loading...' : attendanceData.late.toString()}
              subtitle="Arrived late"
              icon="clock"
              color={colors.warning}
            />
          </View>

          {/* Today's Attendance Chart */}
          <View style={[commonStyles.card, styles.chartCard]}>
            <Text style={commonStyles.subtitle}>Today's Attendance</Text>
            <View style={styles.chartContainer}>
              <PieChart
                data={pieData}
                width={Math.min(screenWidth - 40, 400)} // Responsive width with max limit
                height={200}
                chartConfig={{
                  backgroundColor: colors.card,
                  backgroundGradientFrom: colors.card,
                  backgroundGradientTo: colors.card,
                  color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                }}
                accessor="population"
                backgroundColor="transparent"
                paddingLeft="15"
                center={[10, 0]}
                absolute
                style={Platform.OS === 'android' ? { marginLeft: -10 } : undefined} // Adjust for Android rendering
              />
            </View>
          </View>

          {/* 7-Day Trend */}
          <View style={[commonStyles.card, styles.chartCard]}>
            <Text style={commonStyles.subtitle}>7-Day Attendance Trend</Text>
            <View style={styles.chartContainer}>
              <LineChart
                data={weeklyTrend}
                width={Math.min(screenWidth - 40, 400)} // Responsive width with max limit
                height={200}
                chartConfig={chartConfig}
                bezier
                style={Platform.OS === 'android' ? { marginLeft: -10 } : undefined} // Adjust for Android rendering
              />
            </View>
          </View>

          {/* Recent Sessions */}
          <View style={[commonStyles.card, styles.sessionsCard]}>
            <TouchableOpacity 
              style={commonStyles.cardHeader}
              onPress={() => router.push('/(tabs)/classes')}
            >
              <Text style={commonStyles.subtitle}>Recent Sessions</Text>
              <IconSymbol name="chevron.right" size={16} color={colors.textSecondary} />
            </TouchableOpacity>
            {loading ? (
              <Text style={commonStyles.body}>Loading sessions...</Text>
            ) : recentSessions.length > 0 ? (
              recentSessions.map((session) => (
                <SessionCard key={`${session.className}-${session.date}`} session={session} />
              ))
            ) : (
              <Text style={commonStyles.body}>No recent sessions found</Text>
            )}
          </View>

          {/* Logout Button */}
          <TouchableOpacity 
            style={styles.logoutButton}
            onPress={() => {
              Alert.alert(
                'Logout',
                'Are you sure you want to logout?',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { 
                    text: 'Logout', 
                    style: 'destructive',
                    onPress: () => {
                      router.replace('/login');
                    }
                  },
                ]
              );
            }}
          >
            <Text style={styles.logoutButtonText}>Log Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    marginBottom: spacing.lg,
    alignItems: 'center',
  },
  
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
  },
  
  titleContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.md,
  },
  
  dashboardTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    textAlign: 'center',
  },
  
  logoutButton: {
    backgroundColor: colors.card,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadows.sm,
    alignSelf: 'center',
    marginTop: spacing.lg,
    marginBottom: spacing.xl,
  },
  
  logoutButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.error,
  },
  
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: spacing.lg,
  },
  
  statCardWrapper: {
    width: '48%',
    marginBottom: spacing.md,
  },
  
  statCard: {
    width: '100%',
    marginBottom: 0,
  },
  
  statHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },
  
  statTitle: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.textSecondary,
    flex: 1,
  },
  
  statValue: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  
  statSubtitle: {
    fontSize: typography.sizes.xs,
    color: colors.textSecondary,
  },
  
  chartCard: {
    marginBottom: spacing.lg,
  },
  
  chartContainer: {
    alignItems: 'center',
    marginTop: spacing.sm,
    // Add padding to prevent clipping on Android
    paddingHorizontal: spacing.sm,
  },
  
  chart: {
    marginVertical: spacing.sm,
    borderRadius: 16,
    // Add padding to prevent clipping on Android
    paddingHorizontal: spacing.sm,
  },
  
  sessionsCard: {
    marginBottom: spacing.lg,
  },
  
  sessionCard: {
    marginBottom: spacing.sm,
    marginHorizontal: 0,
    ...shadows.sm,
  },
  
  sessionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  
  sessionClass: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  
  sessionTime: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },
  
  attendanceIndicator: {
    alignItems: 'flex-end',
  },
  
  attendanceText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  
  attendanceBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 12,
  },
  
  attendanceBadgeText: {
    fontSize: typography.sizes.xs,
    fontWeight: typography.weights.bold,
    color: colors.card,
  },
});