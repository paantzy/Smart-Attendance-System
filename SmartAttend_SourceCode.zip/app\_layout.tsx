import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SystemBars } from "react-native-edge-to-edge";
import { useFonts, Roboto_400Regular, Roboto_500Medium, Roboto_700Bold } from '@expo-google-fonts/roboto';
import { OpenSans_400Regular, OpenSans_600SemiBold } from '@expo-google-fonts/open-sans';
import {
  DarkTheme,
  DefaultTheme,
  Theme,
  ThemeProvider,
} from "@react-navigation/native";
import * as SplashScreen from "expo-splash-screen";
import { useColorScheme, Alert, View, ActivityIndicator, Text, TouchableOpacity } from "react-native";
import { Button } from "@/components/button";
import React, { useEffect, useState } from "react";
import { StatusBar } from "expo-status-bar";
import { useNetworkState } from "expo-network";
import { WidgetProvider } from "@/contexts/WidgetContext";
import { AuthProvider } from "@/contexts/AuthContext";
import { NotificationProvider } from "@/contexts/NotificationContext";
import { Stack, router } from "expo-router";
import { colors } from "@/styles/commonStyles";
import "react-native-reanimated";
import ErrorBoundary from "@/components/ErrorBoundary";

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

// Custom theme for SmartAttend
const SmartAttendTheme: Theme = {
  dark: false,
  colors: {
    primary: colors.primary,
    background: colors.background,
    card: colors.card,
    text: colors.text,
    border: colors.border,
    notification: colors.accent,
  },
  fonts: {
    regular: {
      fontFamily: 'Roboto_400Regular',
      fontWeight: 'normal',
    },
    medium: {
      fontFamily: 'Roboto_500Medium',
      fontWeight: 'normal',
    },
    bold: {
      fontFamily: 'Roboto_700Bold',
      fontWeight: 'normal',
    },
    heavy: {
      fontFamily: 'Roboto_700Bold',
      fontWeight: 'normal',
    },
  },
};

export default function RootLayout() {
  const networkState = useNetworkState();
  const colorScheme = useColorScheme();
  
  const [loaded, error] = useFonts({
    Roboto_400Regular,
    Roboto_500Medium,
    Roboto_700Bold,
    OpenSans_400Regular,
    OpenSans_600SemiBold,
  });

  const [fontLoadTimeout, setFontLoadTimeout] = useState(false);

  useEffect(() => {
    // Set a timeout for font loading
    const timer = setTimeout(() => {
      console.log('Font loading timeout reached');
      setFontLoadTimeout(true);
    }, 10000); // 10 seconds timeout

    if (loaded || error || fontLoadTimeout) {
      SplashScreen.hideAsync();
      clearTimeout(timer);
    }

    return () => clearTimeout(timer);
  }, [loaded, error, fontLoadTimeout]);

  // If fonts fail to load or timeout, continue anyway
  if (!loaded && !error && !fontLoadTimeout) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f5f5f5' }}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={{ marginTop: 10, fontSize: 16, color: '#666' }}>
          Loading fonts...
        </Text>
        <Text style={{ marginTop: 5, fontSize: 14, color: '#999' }}>
          Please wait or check your internet connection
        </Text>
      </View>
    );
  }

  // If there was a font loading error, show a warning but continue
  if (error) {
    console.log('Font loading error:', error);
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f5f5f5', padding: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 10 }}>
          Font Loading Issue
        </Text>
        <Text style={{ fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 20 }}>
          There was an issue loading fonts. The app will continue with default fonts.
        </Text>
        <TouchableOpacity 
          style={{ backgroundColor: '#007AFF', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 8 }}
          onPress={() => {
            // Just hide splash and continue with default fonts
            SplashScreen.hideAsync();
          }}
        >
          <Text style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>
            Continue
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SystemBars style="auto" />
      <ThemeProvider value={SmartAttendTheme}>
        <ErrorBoundary>
          <AuthProvider>
            <NotificationProvider>
              <WidgetProvider>
                <Stack
                  screenOptions={{
                    headerShown: false,
                  }}
                >
                  <Stack.Screen 
                    name="index" 
                    options={{ 
                      headerShown: false,
                    }} 
                  />
                  <Stack.Screen 
                    name="login" 
                    options={{ 
                      headerShown: false,
                      presentation: 'card',
                    }} 
                  />
                  <Stack.Screen 
                    name="(tabs)" 
                    options={{ 
                      headerShown: false,
                    }} 
                  />
                  <Stack.Screen 
                    name="modal" 
                    options={{ 
                      presentation: "modal",
                      headerShown: true,
                      title: 'Modal',
                    }} 
                  />
                  <Stack.Screen 
                    name="formsheet" 
                    options={{ 
                      presentation: "formSheet",
                      headerShown: true,
                      title: 'Form',
                    }} 
                  />
                  <Stack.Screen 
                    name="transparent-modal" 
                    options={{ 
                      presentation: "transparentModal",
                      headerShown: false,
                    }} 
                  />
                </Stack>
                <StatusBar style="auto" />
              </WidgetProvider>
            </NotificationProvider>
          </AuthProvider>
        </ErrorBoundary>
      </ThemeProvider>
    </GestureHandlerRootView>
  );
}