import React, { createContext, useContext, ReactNode } from 'react';

// Define the context type
interface NotificationContextType {
  expoPushToken: string | undefined;
  notification: undefined;
}

// Create the context
const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

// Create a provider component
export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const expoPushToken = undefined;
  const notification = undefined;

  return (
    <NotificationContext.Provider value={{ expoPushToken, notification }}>
      {children}
    </NotificationContext.Provider>
  );
};

// Create a custom hook to use the notification context
export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
};