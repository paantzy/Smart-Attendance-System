import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { getStudents } from '../../utils/studentOperations';
import { supabase } from '../../utils/supabase'; // Add Supabase import for real-time updates
import QRCode from 'react-native-qrcode-svg';
import { generateQRCodeValue } from '../../utils/qrCodeGenerator'; // Import our QR code generator

interface StudentData {
  student_id: string;
  student_name: string;
  grade: string;
  class_name: string;
  parent_contact: string;
  email_student: string;
  created_at: string;
}

export default function QRCodesScreen() {
  const { userRole } = useAuth();
  const [students, setStudents] = useState<StudentData[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedForm, setSelectedForm] = useState('All');
  const [selectedClass, setSelectedClass] = useState('All');

  console.log('QRCodesScreen rendered on platform:', Platform.OS);

  // Load students from Supabase
  useEffect(() => {
    loadStudents();

    // Set up real-time listener for student changes
    const channel = supabase
      .channel('students-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'students',
        },
        (payload) => {
          // A new student was added, add it to the list
          const newStudent: StudentData = {
            student_id: payload.new.student_id,
            student_name: payload.new.student_name,
            grade: payload.new.grade,
            class_name: payload.new.class_name,
            parent_contact: payload.new.parent_contact,
            email_student: payload.new.email_student,
            created_at: payload.new.created_at,
          };
          setStudents(prev => [...prev, newStudent]);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'students',
        },
        (payload) => {
          // A student was deleted, remove it from the list
          const deletedStudentId = payload.old.student_id;
          setStudents(prev => prev.filter(student => student.student_id !== deletedStudentId));
        }
      )
      .subscribe();

    // Clean up the subscription
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const loadStudents = async () => {
    try {
      setLoading(true);
      const studentList = await getStudents();
      setStudents(studentList || []);
    } catch (error) {
      console.error('Error loading students:', error);
      Alert.alert('Error', 'Failed to load students: ' + (error as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadStudents();
    setRefreshing(false);
  };

  // Get unique forms and classes
  const uniqueForms = ['All', ...Array.from(new Set(students.map(s => s.grade).filter(Boolean)))];
  const uniqueClasses = ['All', ...Array.from(new Set(students.map(s => s.class_name).filter(Boolean)))];

  // Filter students based on selected form and class
  const filteredStudents = students.filter(student => {
    const matchesForm = selectedForm === 'All' || student.grade === selectedForm;
    const matchesClass = selectedClass === 'All' || student.class_name === selectedClass;
    return matchesForm && matchesClass;
  });

  // Function to generate and share QR code sheet
  const handleGenerateQRSheet = async () => {
    try {
      // Import the generator function dynamically to avoid issues
      const { generateQRCodeSheet } = await import('../../utils/qrCodeGenerator');
      await generateQRCodeSheet(students);
    } catch (error) {
      console.error('Error generating QR code sheet:', error);
      Alert.alert('Error', 'Failed to generate QR code sheet: ' + (error as Error).message);
    }
  };

  // Check if user is a parent
  const isParent = userRole === 'parent';

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={[commonStyles.container, commonStyles.center]}>
          <Text style={commonStyles.body}>Loading QR codes...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={commonStyles.title}>Student QR Codes</Text>
        </View>

        {/* Filters */}
        <View style={styles.filtersContainer}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filtersContent}
          >
            {/* Form Filter */}
            <TouchableOpacity
              style={styles.filterButton}
              onPress={() => {
                const currentIndex = uniqueForms.indexOf(selectedForm);
                const nextIndex = (currentIndex + 1) % uniqueForms.length;
                setSelectedForm(uniqueForms[nextIndex]);
              }}
            >
              <IconSymbol name="book" size={16} color={colors.textSecondary} />
              <Text style={styles.filterText}>
                {selectedForm === 'All' ? 'All Forms' : selectedForm}
              </Text>
              <IconSymbol name="chevron.down" size={12} color={colors.textSecondary} />
            </TouchableOpacity>

            {/* Class Filter */}
            <TouchableOpacity
              style={styles.filterButton}
              onPress={() => {
                const currentIndex = uniqueClasses.indexOf(selectedClass);
                const nextIndex = (currentIndex + 1) % uniqueClasses.length;
                setSelectedClass(uniqueClasses[nextIndex]);
              }}
            >
              <IconSymbol name="square.grid.2x2" size={16} color={colors.textSecondary} />
              <Text style={styles.filterText}>
                {selectedClass === 'All' ? 'All Classes' : selectedClass}
              </Text>
              <IconSymbol name="chevron.down" size={12} color={colors.textSecondary} />
            </TouchableOpacity>
          </ScrollView>
        </View>

        {/* Students List with QR Codes */}
        <ScrollView
          style={styles.content}
          contentContainerStyle={commonStyles.scrollContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        >
          {filteredStudents.length > 0 ? (
            filteredStudents.map((student) => (
              <View key={student.student_id} style={[commonStyles.card, styles.studentCard]}>
                <View style={styles.studentHeader}>
                  <View style={styles.studentInfo}>
                    <Text style={styles.studentName}>{student.student_name}</Text>
                    <Text style={styles.studentGrade}>{student.grade}</Text>
                    <Text style={styles.studentClass}>{student.class_name}</Text>
                  </View>
                </View>

                <View style={styles.qrCodeContainer}>
                  <View style={styles.qrCodeWrapper}>
                    <QRCode
                      value={generateQRCodeValue(student.student_id, student.student_name)}
                      size={Platform.OS === 'web' ? 150 : 130} // Smaller QR code on mobile for better performance
                      color={colors.primary}
                      backgroundColor={colors.card}
                      quietZone={10}
                      onError={(error: any) => {
                        console.error('QR Code rendering error:', error);
                      }}
                    />
                  </View>
                  <Text style={styles.studentIdText}>ID: {student.student_id}</Text>
                </View>

                <View style={styles.studentDetails}>
                  <View style={styles.detailRow}>
                    <IconSymbol name="phone" size={16} color={colors.textSecondary} />
                    <Text style={styles.detailText}>{student.parent_contact}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <IconSymbol name="envelope" size={16} color={colors.textSecondary} />
                    <Text style={styles.detailText}>{student.email_student}</Text>
                  </View>
                </View>
              </View>
            ))
          ) : (
            <View style={styles.emptyState}>
              <IconSymbol name="qrcode" size={48} color={colors.textSecondary} />
              <Text style={styles.emptyText}>No students found</Text>
              <Text style={styles.emptySubtext}>
                Add students to generate QR codes
              </Text>
            </View>
          )}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  generateButton: {
    backgroundColor: colors.primary,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },

  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },

  studentCard: {
    marginBottom: spacing.md,
  },

  studentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },

  studentInfo: {
    flex: 1,
  },

  studentName: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  studentGrade: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },

  studentClass: {
    fontSize: typography.sizes.sm,
    color: colors.primary,
    fontWeight: typography.weights.medium,
  },

  qrCodeContainer: {
    alignItems: 'center',
    marginBottom: spacing.md,
    padding: spacing.md,
    backgroundColor: colors.background,
    borderRadius: 12,
  },

  qrCodeWrapper: {
    padding: spacing.sm,
    backgroundColor: colors.card,
    borderRadius: 8,
    marginBottom: spacing.sm,
  },

  studentIdText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    textAlign: 'center',
  },

  studentDetails: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.md,
  },

  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },

  detailText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    marginLeft: spacing.sm,
  },

  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl,
  },

  emptyText: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginTop: spacing.md,
    marginBottom: spacing.xs,
  },

  emptySubtext: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
  },

  filtersContainer: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  filtersContent: {
    paddingRight: spacing.md,
  },

  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 8,
    marginRight: spacing.sm,
    ...shadows.sm,
  },

  filterText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
    marginHorizontal: spacing.xs,
    fontWeight: typography.weights.medium,
  },
});