import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { supabase } from '../utils/supabase'; // Use direct supabase import instead

export default function StudentTestPage() {
  const [studentName, setStudentName] = useState('');
  const [grade, setGrade] = useState('');
  const [classValue, setClassValue] = useState('');
  const [parentContact, setParentContact] = useState('');
  const [emailStudent, setEmailStudent] = useState('');
  const [students, setStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const handleAddStudent = async () => {
    // Basic validation
    if (!studentName || !grade || !classValue || !parentContact || !emailStudent) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      console.log('🔧 Attempting to insert student:', {
        student_name: studentName,
        grade: grade,
        class_name: classValue, // Changed from 'class' to 'class_name'
        parent_contact: parentContact,
        email_student: emailStudent,
      });
      
      const { data, error } = await supabase
        .from('students')
        .insert([
          {
            student_name: studentName,
            grade: grade,
            class_name: classValue, // Changed from 'class' to 'class_name'
            parent_contact: parentContact,
            email_student: emailStudent,
          }
        ])
        .select();

      console.log('📋 Insert result - Data:', data);
      console.log('📋 Insert result - Error:', error);

      if (error) {
        console.error('❌ Error adding student to Supabase:', error);
        Alert.alert('Error', `Failed to add student: ${error.message}`);
        return;
      }

      Alert.alert('Success', 'Student added successfully!');
      
      // Clear form
      setStudentName('');
      setGrade('');
      setClassValue('');
      setParentContact('');
      setEmailStudent('');
      
      // Refresh the student list
      loadStudents();
    } catch (error: any) {
      console.error('💥 Unexpected error adding student:', error);
      Alert.alert('Error', `Unexpected error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const loadStudents = async () => {
    setRefreshing(true);
    try {
      console.log('🔧 Attempting to fetch all students');
      
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('student_name', { ascending: true });

      console.log('📋 Fetch result - Data length:', data?.length);
      console.log('📋 Fetch result - Error:', error);

      if (error) {
        console.error('❌ Error fetching students from Supabase:', error);
        Alert.alert('Error', `Failed to load students: ${error.message}`);
        return;
      }

      setStudents(data || []);
      console.log('✅ Students fetched successfully from Supabase');
    } catch (error: any) {
      console.error('💥 Unexpected error fetching students:', error);
      Alert.alert('Error', `Unexpected error: ${error.message}`);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadStudents();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Student Test Page</Text>
      
      <View style={styles.form}>
        <Text style={styles.label}>Student Name</Text>
        <TextInput
          style={styles.input}
          value={studentName}
          onChangeText={setStudentName}
          placeholder="Enter student name"
        />
        
        <Text style={styles.label}>Grade</Text>
        <TextInput
          style={styles.input}
          value={grade}
          onChangeText={setGrade}
          placeholder="Enter grade"
        />
        
        <Text style={styles.label}>Class</Text>
        <TextInput
          style={styles.input}
          value={classValue}
          onChangeText={setClassValue}
          placeholder="Enter class"
        />
        
        <Text style={styles.label}>Parent Contact</Text>
        <TextInput
          style={styles.input}
          value={parentContact}
          onChangeText={setParentContact}
          placeholder="Enter parent contact"
          keyboardType="phone-pad"
        />
        
        <Text style={styles.label}>Student Email</Text>
        <TextInput
          style={styles.input}
          value={emailStudent}
          onChangeText={setEmailStudent}
          placeholder="Enter student email"
          keyboardType="email-address"
        />
        
        <TouchableOpacity 
          style={[styles.button, loading && styles.buttonDisabled]} 
          onPress={handleAddStudent}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? 'Adding...' : 'Add Student'}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.button, styles.secondaryButton]} 
          onPress={loadStudents}
        >
          <Text style={[styles.buttonText, styles.secondaryButtonText]}>
            Refresh Students
          </Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.studentsSection}>
        <Text style={styles.sectionTitle}>Students ({students.length})</Text>
        {students.map((student, index) => (
          <View key={student.student_id || index} style={styles.studentCard}>
            <Text style={styles.studentName}>{student.student_name}</Text>
            <Text>Grade: {student.grade}</Text>
            <Text>Class: {student.class_name}</Text> {/* Changed from 'class' to 'class_name' */}
            <Text>Parent Contact: {student.parent_contact}</Text>
            <Text>Email: {student.email_student}</Text>
            <Text>ID: {student.student_id}</Text>
          </View>
        ))}
        
        {students.length === 0 && (
          <Text style={styles.emptyText}>No students found</Text>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: '#333',
  },
  form: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 3,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 5,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 15,
  },
  button: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonDisabled: {
    backgroundColor: '#ccc',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  secondaryButton: {
    backgroundColor: '#f0f0f0',
  },
  secondaryButtonText: {
    color: '#333',
  },
  studentsSection: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 3,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  studentCard: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  studentName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  emptyText: {
    textAlign: 'center',
    color: '#666',
    fontStyle: 'italic',
  },
});