import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { getAttendanceByStudentId } from '@/utils/attendanceOperations';
import { getStudentById } from '@/utils/studentOperations';
import { supabase } from '@/utils/supabase';
import { useAuth } from '@/contexts/AuthContext';
import moment from 'moment-timezone';

interface AttendanceRecord {
  id: string;
  student_id: string;
  student_name: string;
  class_name: string;
  check_in_time: string;
  check_out_time: string | null;
  status: 'present' | 'absent' | 'late';
  teacher_name: string;
  created_at: string;
  updated_at: string;
}

export default function AttendanceHistoryScreen() {
  const { userId } = useAuth();
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [studentName, setStudentName] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);

  // Fetch parent's child attendance history
  useEffect(() => {
    fetchAttendanceHistory();
  }, [userId]);

  const fetchAttendanceHistory = async () => {
    try {
      setLoading(true);
      
      // Get the parent's child ID from the users table
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('child_id')
        .eq('id', userId)
        .single();
      
      if (userError) {
        console.error('Error fetching user data:', userError);
        Alert.alert('Error', 'Failed to fetch user data');
        return;
      }
      
      if (!userData?.child_id) {
        console.error('No child associated with this parent account');
        Alert.alert('Error', 'No child associated with this account. Please contact administrator.');
        return;
      }
      
      // Fetch student data using the child ID
      const student = await getStudentById(userData.child_id);
      if (!student) {
        console.error('Student not found');
        Alert.alert('Error', 'Student data not found. Please check the ID with your teacher.');
        return;
      }
      
      setStudentName(student.student_name);
      
      // Fetch attendance records for the student
      const records = await getAttendanceByStudentId(userData.child_id);
      setAttendanceRecords(records);
    } catch (error) {
      console.error('Error fetching attendance history:', error);
      Alert.alert('Error', 'Failed to fetch attendance history');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchAttendanceHistory();
    setRefreshing(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present': return colors.success;
      case 'absent': return colors.error;
      case 'late': return colors.warning;
      default: return colors.textSecondary;
    }
  };

  const getStatusText = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  const formatDate = (dateString: string) => {
    return moment(dateString).tz('Asia/Kuala_Lumpur').format('DD/MM/YYYY');
  };

  const formatTime = (dateString: string) => {
    return moment(dateString).tz('Asia/Kuala_Lumpur').format('hh:mm A');
  };

  const AttendanceRecordItem = ({ record }: { record: AttendanceRecord }) => {
    const isAbsent = record.status === 'absent';
    
    // For absent records, try to get date from check_in_time, created_at, or updated_at
    const getRecordDate = () => {
      if (record.check_in_time) {
        return formatDate(record.check_in_time);
      } else if (record.created_at) {
        return formatDate(record.created_at);
      } else if (record.updated_at) {
        return formatDate(record.updated_at);
      }
      return 'Date unavailable';
    };
    
    return (
      <View style={[styles.recordCard, commonStyles.card]}>
        <View style={styles.recordHeader}>
          <Text style={styles.dateText}>{getRecordDate()}</Text>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(record.status) }]}>
            <Text style={styles.statusBadgeText}>{getStatusText(record.status)}</Text>
          </View>
        </View>
        
        {isAbsent ? (
          // Show absent status details
          <View style={styles.recordDetails}>
            <View style={styles.absentInfo}>
              <Text style={styles.absentInfoText}>No check-in/check-out recorded</Text>
              <Text style={styles.absentDateText}>Date: {getRecordDate()}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <IconSymbol name="person" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Teacher: {record.teacher_name}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <IconSymbol name="graduationcap" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Class: {record.class_name}</Text>
            </View>
          </View>
        ) : (
          // Show normal check-in/check-out details
          <View style={styles.recordDetails}>
            <View style={styles.detailRow}>
              <IconSymbol name="clock" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Check-in: {formatTime(record.check_in_time)}</Text>
            </View>
            
            {record.check_out_time && (
              <View style={styles.detailRow}>
                <IconSymbol name="clock.fill" size={16} color={colors.textSecondary} />
                <Text style={styles.detailText}>Check-out: {formatTime(record.check_out_time)}</Text>
              </View>
            )}
            
            <View style={styles.detailRow}>
              <IconSymbol name="person" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Teacher: {record.teacher_name}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <IconSymbol name="graduationcap" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Class: {record.class_name}</Text>
            </View>
          </View>
        )}
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={[commonStyles.container, commonStyles.center]}>
          <Text style={commonStyles.body}>Loading attendance history...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={commonStyles.title}>Attendance History</Text>
          <Text style={commonStyles.caption}>
            {studentName ? `${studentName}'s attendance records` : 'Your child\'s attendance records'}
          </Text>
        </View>

        {/* Attendance Records */}
        <ScrollView 
          style={styles.content}
          contentContainerStyle={commonStyles.scrollContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        >
          {attendanceRecords.length > 0 ? (
            attendanceRecords
              .sort((a, b) => new Date(b.check_in_time).getTime() - new Date(a.check_in_time).getTime())
              .map((record) => (
                <AttendanceRecordItem key={record.id} record={record} />
              ))
          ) : (
            <View style={[commonStyles.card, styles.emptyState]}>
              <IconSymbol name="list.bullet" size={48} color={colors.textSecondary} />
              <Text style={styles.emptyText}>No attendance records found</Text>
              <Text style={styles.emptySubtext}>
                There are no attendance records for your child yet
              </Text>
            </View>
          )}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    marginBottom: spacing.lg,
    alignItems: 'center',
    paddingHorizontal: spacing.md,
  },

  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },

  recordCard: {
    marginBottom: spacing.md,
    padding: spacing.md,
  },

  recordHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },

  dateText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },

  statusBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 12,
  },

  statusBadgeText: {
    fontSize: typography.sizes.xs,
    fontWeight: typography.weights.bold,
    color: colors.card,
  },

  recordDetails: {
    paddingLeft: spacing.md,
  },

  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },

  detailText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
    marginLeft: spacing.sm,
  },

  absentInfo: {
    backgroundColor: colors.background,
    padding: spacing.sm,
    borderRadius: 8,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.error + '30',
  },

  absentInfoText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.error,
    marginBottom: spacing.xs,
    textAlign: 'center',
  },

  absentDateText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
    textAlign: 'center',
  },

  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl,
  },

  emptyText: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginTop: spacing.md,
    marginBottom: spacing.xs,
  },

  emptySubtext: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});
