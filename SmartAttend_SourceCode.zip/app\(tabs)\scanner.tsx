import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView,
  Modal,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { router } from 'expo-router';
import { getStudents } from '../../utils/studentOperations';
import { getClassNames } from '../../utils/classTeacherStudentOperations'; // Updated import
import { getClassTeacherStudents } from '../../utils/classTeacherStudentOperations';
import { addAttendanceRecord, getAttendanceRecords, updateAttendanceRecord, hasStudentCheckedInToday, deleteAttendanceRecord } from '../../utils/attendanceOperations';
import moment from 'moment-timezone';

interface ScannedStudent {
  id: string;
  name: string;
  class: string;
  qrCode: string;
  status: 'present' | 'late';
  timestamp: string;
}

interface AttendanceSession {
  id: string;
  className: string;
  // Removed classId since we're using class_name directly
  teacherName: string;
  date: string;
  startTime: string;
  totalStudents: number;
  scannedStudents: ScannedStudent[];
}

interface Student {
  student_id: string;
  student_name: string;
  grade: string;
  class_name: string;
  parent_contact: string;
  email_student: string;
  created_at: string;
}

// Removed Class interface since we're not using a separate class table

interface ClassTeacherStudent {
  id: number;
  class_name: string;  // Changed from class_id to class_name
  teacher_name: string;
  form_level: string;
  student_id: string;
  created_at: string;
  updated_at: string;
  student?: {
    student_name: string;
    grade: string;
  };
}

// Define the AttendanceRecord interface to match the Attendance Status design
interface AttendanceRecord {
  id: string;
  studentName: string;
  className: string;
  form: string;
  checkInTime: string;
  checkOutTime?: string;
  date?: string; // Add date property
  teacher: string;
  status: 'present' | 'late' | 'absent';
}

export default function ScannerScreen() {
  const { userRole } = useAuth();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [activeSession, setActiveSession] = useState<AttendanceSession | null>(null);
  const [showStartModal, setShowStartModal] = useState(false);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedForm, setSelectedForm] = useState(''); // New state for form selection
  const [students, setStudents] = useState<Student[]>([]);
  const [classNames, setClassNames] = useState<string[]>([]); // Changed from classes to classNames
  const [classTeacherStudents, setClassTeacherStudents] = useState<ClassTeacherStudent[]>([]);
  const [loading, setLoading] = useState(true);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  
  // Ref to track the last scanned QR code and timestamp for debouncing
  const lastScanRef = useRef<{ data: string; timestamp: number } | null>(null);

  // Add a ref to track active alerts
  const activeAlertRef = useRef(false);

  // Check if user is a parent
  const isParent = userRole === 'parent';

  // Function to load data from Supabase
  const loadData = async () => {
    try {
      setLoading(true);
      // Updated to use getClassNames instead of getClasses
      const [studentsData, classNamesData, classTeacherStudentsData, attendanceData] = await Promise.all([
        getStudents(),
        getClassNames(), // Updated function
        getClassTeacherStudents(),
        getAttendanceRecords(),
      ]);
      
      setStudents(studentsData || []);
      setClassNames(classNamesData || []); // Updated state setter
      setClassTeacherStudents(classTeacherStudentsData || []);
      
      // Transform attendance data to match the Attendance Status design
      // Simplified transformation without moment-timezone to avoid potential issues
      const transformedRecords: AttendanceRecord[] = (attendanceData || []).map((record: any) => {
        // Simple time formatting without moment-timezone
        const formatTime = (dateString: string | undefined) => {
          if (!dateString) return 'N/A';
          try {
            const date = new Date(dateString);
            return date.toLocaleTimeString('en-US', {
              hour: '2-digit',
              minute: '2-digit',
              hour12: true
            });
          } catch (e) {
            console.error('Error formatting time:', e);
            return 'Invalid Time';
          }
        };
        
        // Extract date part for comparison
        const extractDate = (dateString: string | undefined) => {
          if (!dateString) return undefined;
          try {
            const date = moment(dateString).tz('Asia/Kuala_Lumpur');
            return date.format('YYYY-MM-DD');
          } catch (e) {
            console.error('Error extracting date:', e);
            return undefined;
          }
        };
        
        const transformed = {
          id: record.id?.toString() || Date.now().toString(),
          studentName: record.student?.student_name || 'Unknown Student',
          className: record.class_name || 'Unknown Class',
          form: record.student?.grade || 'Unknown Form',
          checkInTime: formatTime(record.check_in_time),
          checkOutTime: record.check_out_time ? formatTime(record.check_out_time) : undefined,
          date: extractDate(record.check_in_time),
          teacher: record.teacher_name || 'Unknown Teacher',
          status: record.status || 'present',
        };
        return transformed;
      });
      
      setAttendanceRecords(transformedRecords);
    } catch (error) {
      console.error('Error loading data:', error);
      Alert.alert('Error', 'Failed to load data: ' + (error as Error).message);
    } finally {
      setLoading(false);
    }
  };

  // Add a refresh function
  const refreshData = async () => {
    await loadData();
  };

  // Load data from Supabase on component mount
  useEffect(() => {
    loadData();
  }, []);

  // Add pull-to-refresh capability
  useEffect(() => {
    // Force an immediate refresh after a short delay to ensure data loads
    const timer = setTimeout(() => {
      loadData();
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  // Redirect parents away from scanner screen
  useEffect(() => {
    if (isParent) {
      Alert.alert(
        'Access Denied',
        'Parents do not have access to the scanner functionality.',
        [{ text: 'OK', onPress: () => router.replace('/(tabs)/dashboard') }]
      );
    }
  }, [isParent]);

  // If user is a parent, don't render the scanner
  if (isParent) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={[commonStyles.container, commonStyles.center]}>
          <Text style={commonStyles.body}>Redirecting...</Text>
        </View>
      </SafeAreaView>
    );
  }

  useEffect(() => {
    requestPermission();
  }, []);

  // Debugging: Log activeSession state changes
  useEffect(() => {
    console.log('Active session state changed:', activeSession);
  }, [activeSession]);

  const startSession = () => {
    if (!selectedClass) {
      Alert.alert('Error', 'Please select a class');
      return;
    }

    // Check if the selected class exists in our classNames array
    const classExists = classNames.includes(selectedClass);
    if (!classExists) {
      Alert.alert('Error', 'Class not found');
      return;
    }

    // Get teacher name for this class
    // Updated to use class_name instead of class_id
    const classTeacherStudent = classTeacherStudents.find(
      (cts) => {
        return cts.class_name === selectedClass;
      }
    );
    
    const teacherName = classTeacherStudent?.teacher_name || 'Unknown Teacher';

    // Get total students for this class
    // Updated to use class_name instead of class_id
    const studentsInClass = classTeacherStudents.filter(
      (cts) => {
        return cts.class_name === selectedClass;
      }
    ).length;

    // Generate session time in Malaysia timezone
    const now = moment().tz('Asia/Kuala_Lumpur');
    
    const newSession: AttendanceSession = {
      id: Date.now().toString(),
      className: selectedClass, // Use selectedClass directly
      teacherName: teacherName,
      date: now.format('YYYY-MM-DD'),
      startTime: now.format('hh:mm A'),
      totalStudents: studentsInClass,
      scannedStudents: [],
    };

    setActiveSession(newSession);
    setShowStartModal(false);
    Alert.alert('Session Started', `Attendance session for ${selectedClass} has started`);
  };

  const endSession = () => {
    if (!activeSession) {
      Alert.alert('No Active Session', 'There is no active session to end');
      return;
    }

    Alert.alert(
      'End Session',
      `End attendance session for ${activeSession.className}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'End Session',
          style: 'destructive',
          onPress: () => {
            setActiveSession(null);
            setSelectedClass('');
            setSelectedForm('');
            Alert.alert('Session Ended', 'Attendance session has been saved successfully');
          },
        },
      ]
    );
  };

  const handleBarCodeScanned = async ({ type, data }: { type: string; data: string }) => {
    // Prevent multiple alerts from being shown simultaneously
    if (activeAlertRef.current) {
      return;
    }
    
    // Prevent processing if we're already handling a scan
    if (scanned) {
      return;
    }
    
    // Debounce scans - prevent multiple scans of the same QR code within 5 seconds
    const now = Date.now();
    if (lastScanRef.current && 
        lastScanRef.current.data === data && 
        now - lastScanRef.current.timestamp < 5000) {
      return;
    }
    
    // Update the last scan ref
    lastScanRef.current = { data, timestamp: now };
    
    // Prevent multiple scans of the same QR code in quick succession
    if (!activeSession) {
      activeAlertRef.current = true;
      Alert.alert('No Active Session', 'Please start an attendance session first', [
        { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
      ]);
      // Reset the last scan ref to allow future scans
      setTimeout(() => {
        lastScanRef.current = null;
      }, 5000);
      return;
    }

    // Set scanned state immediately to prevent multiple simultaneous scans
    setScanned(true);

    try {
      // Refresh student data to ensure we have the latest students
      const latestStudents = await getStudents();
      setStudents(latestStudents || []);
      
      // Extract student ID from QR code if it's in the format STUDENT_ID:{id}|NAME:{name}
      let extractedStudentId = data;
      if (data.startsWith('STUDENT_ID:')) {
        const match = data.match(/STUDENT_ID:([^|]+)/);
        if (match && match[1]) {
          extractedStudentId = match[1];
        }
      }
      
      // Approach 1: Direct match with extracted ID
      let student = latestStudents.find((s) => {
        return s.student_id === extractedStudentId;
      });
      
      // Approach 2: Case insensitive match
      if (!student) {
        student = latestStudents.find((s) => {
          return s.student_id?.toLowerCase() === extractedStudentId?.toLowerCase();
        });
      }
      
      // Approach 3: Trim whitespace
      if (!student) {
        student = latestStudents.find((s) => {
          return s.student_id?.trim() === extractedStudentId?.trim();
        });
      }
      
      if (!student) {
        activeAlertRef.current = true;
        Alert.alert('Invalid QR Code', `Student not found in database. Scanned: ${data}`, [
          { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
        ]);
        setTimeout(() => {
          setScanned(false);
          lastScanRef.current = null;
        }, 2000);
        return;
      }

      // Check if student is in the selected class
      // Updated to use class_name instead of class_id
      const isStudentInClass = classTeacherStudents.some(
        (cts) => {
          const classNameMatch = cts.class_name === selectedClass; // Updated to use class_name
          // Ensure we're comparing the same data types for student_id
          const studentIdMatch = cts.student_id.toString() === student.student_id.toString();
          return classNameMatch && studentIdMatch;
        }
      );
      
      if (!isStudentInClass) {
        activeAlertRef.current = true;
        Alert.alert('Wrong Class', `${student.student_name} is not in this class`, [
          { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
        ]);
        setTimeout(() => {
          setScanned(false);
          lastScanRef.current = null;
        }, 2000);
        return;
      }

      // Refresh attendance records to ensure we have the latest data
      const latestAttendanceRecords = await getAttendanceRecords();
      
      // Use a more robust date comparison that handles timezone issues
      const today = moment().tz('Asia/Kuala_Lumpur');
      const todayDateString = today.format('YYYY-MM-DD');
      
      const transformedRecords: AttendanceRecord[] = latestAttendanceRecords.map((record: any) => {
        // Extract date part from check_in_time for comparison
        let recordDate = 'N/A';
        if (record.check_in_time) {
          // Use consistent timezone handling
          recordDate = moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD');
        }
        
        return {
          id: record.id.toString(),
          studentName: record.student?.student_name || 'Unknown Student',
          className: record.class_name || 'Unknown Class',
          form: record.student?.grade || 'Unknown Form',
          checkInTime: record.check_in_time ? moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('hh:mm A') : 'N/A',
          checkOutTime: record.check_out_time ? moment(record.check_out_time).tz('Asia/Kuala_Lumpur').format('hh:mm A') : undefined,
          date: recordDate,
          teacher: record.teacher_name || 'Unknown Teacher',
          status: record.status || 'present',
        };
      });
      
      // Update local state with latest attendance records
      setAttendanceRecords(transformedRecords);
      
      // Check if student already has an attendance record for today in the current class
      // More accurate check for existing records - match by student_id, class_name, and date
      const existingRecord = transformedRecords.find(record => {
        // Get the original record to access student_id
        const originalRecord = latestAttendanceRecords.find(r => r.id.toString() === record.id);
        // Match by student ID, class name, and today's date
        const studentIdMatch = originalRecord?.student_id === student.student_id;
        const classNameMatch = record.className === activeSession.className;
        const dateMatch = record.date === todayDateString;
        
        return studentIdMatch && classNameMatch && dateMatch;
      });

      if (existingRecord && !existingRecord.checkOutTime) {
        // Student already checked in, so this is a checkout
        // Get the original record to access the ID
        const originalRecord = latestAttendanceRecords.find(r => {
          const transformed = transformedRecords.find(tr => tr.id === r.id.toString());
          return transformed?.studentName === existingRecord.studentName && 
                 transformed?.className === existingRecord.className;
        });

        if (originalRecord) {
          try {
            // Update the existing record with checkout time
            // Generate timestamp in Malaysia timezone using consistent approach
            const now = moment().tz('Asia/Kuala_Lumpur');
            const malaysiaTimestamp = now.toISOString();
            
            await updateAttendanceRecord(originalRecord.id, {
              check_out_time: malaysiaTimestamp,
              updated_at: malaysiaTimestamp
            });

            // Refresh attendance records to get the updated data
            const updatedAttendanceRecords = await getAttendanceRecords();
            const refreshedRecords: AttendanceRecord[] = updatedAttendanceRecords.map((record: any) => ({
              id: record.id.toString(),
              studentName: record.student?.student_name || 'Unknown Student',
              className: record.class_name || 'Unknown Class',
              form: record.student?.grade || 'Unknown Form',
              checkInTime: record.check_in_time ? moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('hh:mm A') : 'N/A',
              checkOutTime: record.check_out_time ? moment(record.check_out_time).tz('Asia/Kuala_Lumpur').format('hh:mm A') : undefined,
              date: record.check_in_time ? moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD') : undefined,
              teacher: record.teacher_name || 'Unknown Teacher',
              status: record.status || 'present',
            }));
            
            setAttendanceRecords(refreshedRecords);

            activeAlertRef.current = true;
            Alert.alert('Success', `${student.student_name} checked out successfully`, [
              { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
            ]);
          } catch (updateError: any) {
            activeAlertRef.current = true;
            Alert.alert('Error', `Failed to update attendance record: ${updateError.message || updateError}`, [
              { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
            ]);
          }
        }
      } else if (existingRecord && existingRecord.checkOutTime) {
        // Student already checked in and out
        activeAlertRef.current = true;
        Alert.alert('Already Completed', `${student.student_name} has already checked in and out today`, [
          { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
        ]);
      } else {
        // Check if student has already checked in today to prevent duplicates
        try {
          const alreadyCheckedIn = await hasStudentCheckedInToday(student.student_id, activeSession.className);
          
          if (alreadyCheckedIn) {
            activeAlertRef.current = true;
            Alert.alert('Already Checked In', `${student.student_name} has already checked in today for this class`, [
              { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
            ]);
            setTimeout(() => {
              setScanned(false);
              lastScanRef.current = null;
            }, 2000);
            return;
          }
        } catch (checkError) {
          console.error('Error checking student check-in status:', checkError);
          // Continue with the check-in process if we can't verify
        }
        
        // Student hasn't checked in yet, so this is a checkin
        // Add attendance record to database
        // Generate timestamp in Malaysia timezone
        const now = moment().tz('Asia/Kuala_Lumpur');
        const malaysiaTimestamp = now.toISOString();
        
        const attendanceData = {
          student_id: student.student_id,
          class_name: activeSession.className, // Updated to use class_name
          teacher_name: activeSession.teacherName,
          check_in_time: malaysiaTimestamp,
          status: 'present' as const,
        };

        try {
          const newRecord = await addAttendanceRecord(attendanceData);

          // Add student to session
          const scannedStudent: ScannedStudent = {
            id: student.student_id,
            name: student.student_name,
            class: student.class_name,
            qrCode: data,
            status: 'present',
            timestamp: newRecord?.check_in_time ? moment(newRecord.check_in_time).tz('Asia/Kuala_Lumpur').format('hh:mm A') : 'N/A',
          };

          const updatedSession = {
            ...activeSession,
            scannedStudents: [...activeSession.scannedStudents, scannedStudent],
          };

          setActiveSession(updatedSession);

          // Update local attendance records
          const newAttendanceRecord: AttendanceRecord = {
            id: newRecord?.id.toString() || Date.now().toString(),
            studentName: student.student_name,
            className: activeSession.className,
            form: student.grade,
            checkInTime: newRecord?.check_in_time ? moment(newRecord.check_in_time).tz('Asia/Kuala_Lumpur').format('hh:mm A') : 'N/A',
            checkOutTime: undefined,
            date: newRecord?.check_in_time ? moment(newRecord.check_in_time).tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD') : undefined,
            teacher: activeSession.teacherName,
            status: 'present',
          };

          setAttendanceRecords([newAttendanceRecord, ...transformedRecords]);

          activeAlertRef.current = true;
          Alert.alert('Success', `${student.student_name} checked in successfully at ${now.format('hh:mm A')}`, [
            { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
          ]);
        } catch (saveError: any) {
          activeAlertRef.current = true;
          Alert.alert('Error', `Failed to save attendance record: ${saveError.message || saveError}`, [
            { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
          ]);
        }
      }
    } catch (error) {
      console.error('Error saving attendance:', error);
      activeAlertRef.current = true;
      Alert.alert('Error', 'Failed to save attendance record', [
        { text: 'OK', onPress: () => { activeAlertRef.current = false; } }
      ]);
    } finally {
      // Always reset the scanned state after a delay to prevent multiple scans
      setTimeout(() => {
        setScanned(false);
        // Reset the last scan ref after the timeout to allow future scans
        lastScanRef.current = null;
      }, 3000); // Reduced timeout to 3 seconds
    }
  };

  if (!permission) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={[commonStyles.container, commonStyles.center]}>
          <Text style={commonStyles.body}>Requesting camera permission...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!permission.granted) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={[commonStyles.container, commonStyles.center]}>
          <IconSymbol name="camera" size={48} color={colors.textSecondary} />
          <Text style={[commonStyles.subtitle, { textAlign: 'center', marginTop: spacing.md }]}>
            Camera Permission Required
          </Text>
          <Text style={[commonStyles.body, { textAlign: 'center', marginTop: spacing.sm }]}>
            Please enable camera access to scan QR codes for attendance
          </Text>
          <TouchableOpacity style={[commonStyles.button, { marginTop: spacing.md }]} onPress={requestPermission}>
            <Text style={commonStyles.buttonText}>Allow Camera</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const SessionStats = () => (
    <View style={[commonStyles.card, styles.statsCard]}>
      <View style={styles.statsHeader}>
        <Text style={styles.sessionTitle}>{activeSession?.className}</Text>
        <View style={styles.sessionButtons}>
          {/* Clock Out All Students Button */}
          <TouchableOpacity
            style={styles.clockOutAllButton}
            onPress={clockOutAllStudents}
          >
            <Text style={styles.clockOutAllButtonText}>Clock Out All</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{activeSession?.scannedStudents.length || 0}</Text>
          <Text style={styles.statLabel}>Present</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{activeSession?.totalStudents || 0}</Text>
          <Text style={styles.statLabel}>Total</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>
            {activeSession ? Math.round((activeSession.scannedStudents.length / activeSession.totalStudents) * 100) : 0}%
          </Text>
          <Text style={styles.statLabel}>Rate</Text>
        </View>
      </View>
    </View>
  );

  // Attendance Record Item component with the same design as Attendance Status
  const AttendanceRecordItem = ({ record }: { record: AttendanceRecord }) => (
    <View style={[styles.recordCard, commonStyles.card]}>
      <View style={styles.recordHeader}>
        <Text style={styles.studentName}>{record.studentName}</Text>
      </View>
      
      <View style={styles.recordDetails}>
        <View style={styles.detailRow}>
          <IconSymbol name="building.2.fill" size={16} color={colors.textSecondary} />
          <Text style={styles.detailText}>{record.className} ({record.form})</Text>
        </View>
        
        <View style={styles.detailRow}>
          <IconSymbol name="person.fill" size={16} color={colors.textSecondary} />
          <Text style={styles.detailText}>{record.teacher}</Text>
        </View>
        
        <View style={styles.timeRow}>
          <View style={styles.timeItem}>
            <View style={styles.timeIconContainer}>
              <IconSymbol name="arrow.down" size={16} color={colors.success} />
            </View>
            <View>
              <Text style={styles.timeLabel}>Check-In</Text>
              <Text style={styles.timeValue}>{record.checkInTime}</Text>
            </View>
          </View>
          
          <View style={styles.timeItem}>
            <View style={styles.timeIconContainer}>
              <IconSymbol name="arrow.up" size={16} color={record.checkOutTime ? colors.error : colors.textSecondary} />
            </View>
            <View>
              <Text style={styles.timeLabel}>Check-Out</Text>
              <Text style={[styles.timeValue, !record.checkOutTime && { color: colors.textSecondary }]}>
                {record.checkOutTime || 'Not checked out'}
              </Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );

  const StudentList = () => {
    // Filter to show only students with actual check-in records (present or late)
    // Exclude students with default 'absent' status
    const presentStudents = attendanceRecords.filter(record => 
      record.status === 'present' || record.status === 'late' || record.checkInTime !== 'N/A'
    );
    
    return (
      <View style={[commonStyles.card, styles.studentListCard]}>
        <View style={styles.recordHeader}>
          <Text style={styles.studentName}>Attendance Records ({presentStudents.length} present)</Text>
          {attendanceRecords.length > 0 && (
            <TouchableOpacity 
              style={styles.deleteButton}
              onPress={() => {
                Alert.alert(
                  'Delete All Records',
                  'Are you sure you want to delete all attendance records?',
                  [
                    { text: 'Cancel', style: 'cancel' },
                    {
                      text: 'Delete All',
                      style: 'destructive',
                      onPress: async () => {
                        try {
                          // Get all record IDs to delete
                          const recordIds = attendanceRecords.map(r => Number(r.id));
                          
                          // Delete all records from Supabase
                          const deletePromises = recordIds.map(id => deleteAttendanceRecord(id));
                          await Promise.all(deletePromises);
                          
                          // Update local state
                          setAttendanceRecords([]);
                          
                          Alert.alert('Success', 'All attendance records deleted successfully');
                        } catch (error) {
                          console.error('Error deleting all attendance records:', error);
                          Alert.alert('Error', 'Failed to delete all attendance records');
                        }
                      }
                    }
                  ]
                );
              }}
            >
              <IconSymbol name="trash" size={16} color={colors.error} />
            </TouchableOpacity>
          )}
        </View>
        <ScrollView style={styles.studentList} showsVerticalScrollIndicator={false}>
          {presentStudents.length > 0 ? (
            presentStudents.map((record) => {
              return <AttendanceRecordItem key={record.id} record={record} />;
            })
          ) : (
            <View style={styles.emptyList}>
              <IconSymbol name="qrcode" size={32} color={colors.textSecondary} />
              <Text style={styles.emptyText}>No attendance records yet</Text>
              <Text style={[styles.emptyText, { fontSize: 14, marginTop: 8 }]}>
                {loading ? 'Loading...' : 'Start scanning QR codes to create attendance records'}
              </Text>
            </View>
          )}
        </ScrollView>
      </View>
    );
  };

  const StartSessionModal = () => {
    // Get unique form levels from classTeacherStudents
    const formLevels = [...new Set(classTeacherStudents.map(cts => cts.form_level).filter(Boolean))] as string[];
    
    // Filter classes based on selected form level
    const filteredClassNames = selectedForm 
      ? classNames.filter(className => {
          // Check if any class-teacher-student relationship exists for this class and form level
          return classTeacherStudents.some(cts => 
            cts.class_name === className && cts.form_level === selectedForm
          );
        })
      : classNames;

    // State to control dropdown visibility
    const [showFormDropdown, setShowFormDropdown] = useState(false);
    const [showClassDropdown, setShowClassDropdown] = useState(false);

    return (
      <Modal
        visible={showStartModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowStartModal(false)}
      >
        <SafeAreaView style={commonStyles.safeArea}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setShowStartModal(false)}>
              <Text style={styles.cancelButton}>Cancel</Text>
            </TouchableOpacity>
            <Text style={commonStyles.subtitle}>Start Attendance Session</Text>
            <TouchableOpacity onPress={startSession}>
              <Text style={styles.startButton}>Start</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={commonStyles.content}>
            {/* Form Level Selection */}
            <Text style={styles.modalLabel}>Select Form Level</Text>
            <TouchableOpacity 
              style={commonStyles.input}
              onPress={() => {
                setShowFormDropdown(!showFormDropdown);
                setShowClassDropdown(false); // Close class dropdown when opening form dropdown
              }}
            >
              <View style={styles.dropdownContainer}>
                <Text style={[styles.dropdownText, !selectedForm && styles.dropdownPlaceholderText]}>
                  {selectedForm || 'Select Form Level'}
                </Text>
                <IconSymbol name="chevron.down" size={16} color={colors.textSecondary} />
              </View>
            </TouchableOpacity>
            
            {/* Form Level Dropdown - Positioned absolutely to prevent layout shifts */}
            {showFormDropdown && (
              <View style={styles.absoluteDropdown}>
                <View style={styles.dropdownOptions}>
                  {formLevels.length > 0 ? (
                    formLevels.map((formLevel) => (
                      <TouchableOpacity
                        key={formLevel}
                        style={styles.dropdownOption}
                        onPress={() => {
                          setSelectedForm(formLevel);
                          setSelectedClass('');
                          setShowFormDropdown(false);
                        }}
                      >
                        <Text style={[
                          styles.dropdownOptionText,
                          selectedForm === formLevel && styles.selectedOption
                        ]}>
                          {formLevel}
                        </Text>
                      </TouchableOpacity>
                    ))
                  ) : (
                    <Text style={commonStyles.body}>No form levels found</Text>
                  )}
                </View>
              </View>
            )}

            <Text style={[styles.modalLabel, { marginTop: spacing.md }]}>Select Class</Text>
            <TouchableOpacity 
              style={[commonStyles.input, !selectedForm && styles.disabledInput]}
              onPress={() => {
                console.log('Class dropdown clicked, current selectedClass:', selectedClass);
                if (selectedForm) {
                  setShowClassDropdown(!showClassDropdown);
                  setShowFormDropdown(false); // Close form dropdown when opening class dropdown
                }
              }}
              disabled={!selectedForm}
            >
              <View style={styles.dropdownContainer}>
                <Text style={[styles.dropdownText, (!selectedForm || !selectedClass) && styles.dropdownPlaceholderText]}>
                  {selectedClass || (selectedForm ? 'Select Class' : 'Select Form First')}
                </Text>
                <IconSymbol name="chevron.down" size={16} color={selectedForm ? colors.textSecondary : colors.textSecondary} />
              </View>
            </TouchableOpacity>
            
            {/* Class Dropdown - Positioned absolutely to prevent layout shifts */}
            {showClassDropdown && selectedForm && (
              <View style={styles.absoluteDropdown}>
                <View style={styles.dropdownOptions}>
                  {filteredClassNames.length > 0 ? (
                    filteredClassNames.map((className) => {
                      // Count students for this class and form level
                      const studentCount = classTeacherStudents.filter(
                        cts => cts.class_name === className && cts.form_level === selectedForm
                      ).length;
                      
                      return (
                        <TouchableOpacity
                          key={className}
                          style={styles.dropdownOption}
                          onPress={() => {
                            console.log('Class selected:', className);
                            setSelectedClass(className);
                            setShowClassDropdown(false);
                            console.log('After setting, selectedClass should be:', className);
                          }}
                        >
                          <View>
                            <Text style={[
                              styles.dropdownOptionText,
                              selectedClass === className && styles.selectedOption
                            ]}>
                              {className}
                            </Text>
                            <Text style={styles.dropdownSubtext}>{studentCount} students</Text>
                          </View>
                        </TouchableOpacity>
                      );
                    })
                  ) : (
                    <Text style={commonStyles.body}>
                      No classes found for selected form level
                    </Text>
                  )}
                </View>
              </View>
            )}

            {/* Touchable overlay to close dropdowns when tapping outside */}
            {(showFormDropdown || showClassDropdown) && (
              <TouchableOpacity 
                style={styles.dropdownBackdrop}
                activeOpacity={1}
                onPress={() => {
                  setShowFormDropdown(false);
                  setShowClassDropdown(false);
                }}
              />
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>
    );
  };

  // Function to clock out all students in the current class
  const clockOutAllStudents = async () => {
    if (!activeSession) {
      Alert.alert('No Active Session', 'Please start an attendance session first');
      return;
    }

    try {
      // Get students in the current class
      const studentsInClass = classTeacherStudents
        .filter(cts => cts.class_name === activeSession.className)
        .map(cts => cts.student_id);

      if (studentsInClass.length === 0) {
        Alert.alert('No Students', 'No students found in this class');
        return;
      }

      // Get today's date for filtering records - using consistent format
      const todayDateString = moment().tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD');

      // Get current attendance records
      const currentAttendanceRecords = await getAttendanceRecords();

      // Filter records for today and students in this class who haven't checked out yet
      const recordsToCheckout = currentAttendanceRecords.filter(record => {
        // Extract date part from check_in_time for comparison using consistent format
        let recordDate = null;
        if (record.check_in_time) {
          recordDate = moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD');
        }
        return (
          recordDate === todayDateString &&
          record.class_name === activeSession.className &&
          record.check_in_time && // Has checked in
          !record.check_out_time // Has not checked out
        );
      });

      if (recordsToCheckout.length === 0) {
        Alert.alert('No Students to Clock Out', 'All students in this class have already been clocked out or haven\'t checked in yet');
        return;
      }

      // Confirm with user before proceeding
      Alert.alert(
        'Clock Out All Students',
        `Are you sure you want to clock out ${recordsToCheckout.length} students in ${activeSession.className}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Clock Out All',
            style: 'destructive',
            onPress: async () => {
              try {
                // Generate timestamp in Malaysia timezone
                const now = moment().tz('Asia/Kuala_Lumpur');
                const malaysiaTimestamp = now.toISOString();

                // Update all records that need to be checked out
                const updatePromises = recordsToCheckout.map(record =>
                  updateAttendanceRecord(Number(record.id), {
                    check_out_time: malaysiaTimestamp,
                    updated_at: malaysiaTimestamp
                  })
                );

                await Promise.all(updatePromises);

                // Refresh attendance records
                const updatedAttendanceRecords = await getAttendanceRecords();
                const refreshedRecords: AttendanceRecord[] = updatedAttendanceRecords.map((record: any) => ({
                  id: record.id.toString(),
                  studentName: record.student?.student_name || 'Unknown Student',
                  className: record.class_name || 'Unknown Class',
                  form: record.student?.grade || 'Unknown Form',
                  checkInTime: record.check_in_time ? moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('hh:mm A') : 'N/A',
                  checkOutTime: record.check_out_time ? moment(record.check_out_time).tz('Asia/Kuala_Lumpur').format('hh:mm A') : undefined,
                  teacher: record.teacher_name || 'Unknown Teacher',
                  status: record.status || 'present',
                }));

                setAttendanceRecords(refreshedRecords);

                // Use setTimeout to ensure state update is processed before showing alert
                setTimeout(() => {
                  Alert.alert(
                    'Success',
                    `Successfully clocked out ${recordsToCheckout.length} students at ${now.format('hh:mm A')}`
                  );
                }, 100);
              } catch (error) {
                console.error('Error clocking out students:', error);
                Alert.alert('Error', 'Failed to clock out students: ' + (error as Error).message);
              }
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error getting students or attendance records:', error);
      Alert.alert('Error', 'Failed to get students or attendance records: ' + (error as Error).message);
    }
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={commonStyles.title}>QR Attendance Scanner</Text>
        </View>

        {/* Start/End Session Button - Moved below header */}
        <View style={styles.sessionButtonsContainer}>
          {!activeSession ? (
            <TouchableOpacity
              style={styles.sessionButton}
              onPress={async () => {
                // Refresh data before opening modal
                await loadData();
                setShowStartModal(true);
              }}
            >
              <Text style={styles.sessionButtonText}>Start Class Session</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={[styles.sessionButton, styles.endSessionButton]}
              onPress={() => {
                endSession();
              }}
            >
              <Text style={styles.sessionButtonText}>End Class Session</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Scrollable Content */}
        <ScrollView 
          style={styles.scrollContent}
          showsVerticalScrollIndicator={true}
          bounces={true}
        >
          {activeSession && <SessionStats />}

          {/* Camera View */}
          <View style={styles.cameraContainer}>
            {activeSession ? (
              <CameraView
                style={styles.camera}
                facing="back"
                onBarcodeScanned={scanned || activeAlertRef.current ? undefined : handleBarCodeScanned}
                barcodeScannerSettings={{
                  barcodeTypes: ['qr'],
                }}
              >
                <View style={styles.overlay}>
                  <View style={styles.scanArea}>
                    <View style={styles.scanCorner} />
                    <View style={[styles.scanCorner, styles.scanCornerTopRight]} />
                    <View style={[styles.scanCorner, styles.scanCornerBottomLeft]} />
                    <View style={[styles.scanCorner, styles.scanCornerBottomRight]} />
                  </View>
                  {scanned || activeAlertRef.current ? (
                    <Text style={styles.scanInstruction}>
                      Processing scan...
                    </Text>
                  ) : (
                    <Text style={styles.scanInstruction}>
                      Point camera at student QR code
                    </Text>
                  )}
                </View>
              </CameraView>
            ) : (
              <View style={[styles.camera, styles.cameraPlaceholder]}>
                <IconSymbol name="qrcode" size={64} color={colors.textSecondary} />
                <Text style={styles.placeholderText}>Start a session to begin scanning</Text>
              </View>
            )}
          </View>

          <StudentList />
        </ScrollView>

        <StartSessionModal />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  sessionButtonsContainer: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginBottom: spacing.sm,
  },

  scrollContent: {
    flex: 1,
  },

  sessionButton: {
    backgroundColor: colors.success,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 12,
    ...shadows.sm,
    minWidth: 120,
    minHeight: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 3,
  },

  endSessionButton: {
    backgroundColor: colors.error,
  },

  sessionButtonText: {
    color: colors.card,
    fontWeight: typography.weights.bold,
    fontSize: typography.sizes.md,
    textAlign: 'center',
  },

  statsCard: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
  },

  statsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },

  sessionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },

  sessionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  clockOutAllButton: {
    backgroundColor: colors.warning,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 16,
    marginRight: spacing.md,
  },

  clockOutAllButtonText: {
    color: colors.card,
    fontWeight: typography.weights.semibold,
    fontSize: typography.sizes.sm,
  },

  endButton: {
    backgroundColor: colors.error,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 16,
  },

  endButtonText: {
    color: colors.card,
    fontWeight: typography.weights.semibold,
    fontSize: typography.sizes.sm,
  },

  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  statItem: {
    flex: 1,
    alignItems: 'center',
  },

  statValue: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
  },

  statLabel: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },

  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: colors.border,
  },

  cameraContainer: {
    flex: 1,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    borderRadius: 16,
    overflow: 'hidden',
    ...shadows.md,
  },

  camera: {
    flex: 1,
  },

  cameraPlaceholder: {
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
  },

  placeholderText: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    marginTop: spacing.md,
    textAlign: 'center',
  },

  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  scanArea: {
    width: 200,
    height: 200,
    position: 'relative',
  },

  scanCorner: {
    position: 'absolute',
    width: 30,
    height: 30,
    borderColor: colors.card,
    borderWidth: 3,
    borderTopWidth: 3,
    borderLeftWidth: 3,
    borderRightWidth: 0,
    borderBottomWidth: 0,
    top: 0,
    left: 0,
  },

  scanCornerTopRight: {
    borderTopWidth: 3,
    borderRightWidth: 3,
    borderLeftWidth: 0,
    borderBottomWidth: 0,
    top: 0,
    right: 0,
    left: undefined,
  },

  scanCornerBottomLeft: {
    borderBottomWidth: 3,
    borderLeftWidth: 3,
    borderTopWidth: 0,
    borderRightWidth: 0,
    bottom: 0,
    left: 0,
    top: undefined,
  },

  scanCornerBottomRight: {
    borderBottomWidth: 3,
    borderRightWidth: 3,
    borderTopWidth: 0,
    borderLeftWidth: 0,
    bottom: 0,
    right: 0,
    top: undefined,
    left: undefined,
  },

  scanInstruction: {
    color: colors.card,
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
    textAlign: 'center',
    marginTop: spacing.lg,
  },

  studentListCard: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    maxHeight: 500,
  },

  studentList: {
    marginTop: spacing.sm,
  },

  // Attendance Record Styles (matching Attendance Status design)
  recordCard: {
    marginBottom: spacing.md,
  },

  recordHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
    paddingBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  studentName: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.text,
  },

  dateText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },

  recordDetails: {
    // No additional styling needed
  },

  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },

  detailText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    marginLeft: spacing.sm,
  },

  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: spacing.md,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },

  timeItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  timeIconContainer: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },

  timeLabel: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },

  timeValue: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },

  emptyList: {
    alignItems: 'center',
    paddingVertical: spacing.lg,
  },

  emptyText: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    marginTop: spacing.sm,
  },

  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  cancelButton: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },

  startButton: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.success,
  },

  modalLabel: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
  },

  pickerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },

  picker: {
    flex: 1,
    backgroundColor: colors.card,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  pickerText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  disabledPicker: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    opacity: 0.6,
  },

  disabledPickerText: {
    color: colors.textSecondary,
    opacity: 0.6,
  },

  clearSelection: {
    marginLeft: spacing.sm,
    backgroundColor: colors.card,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },

  clearText: {
    fontSize: typography.sizes.md,
    color: colors.error,
    fontWeight: typography.weights.medium,
  },

  optionsContainer: {
    backgroundColor: colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    maxHeight: 200,
    marginBottom: spacing.md,
  },

  optionItem: {
    padding: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  optionText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    fontWeight: typography.weights.medium,
  },

  optionSubtext: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },

  absoluteDropdown: {
    position: 'absolute',
    top: 100, // Adjust this value based on the position of the picker
    left: 16, // Match the horizontal padding of the content
    right: 16, // Match the horizontal padding of the content
    zIndex: 1000, // Ensure it appears above other elements
    elevation: 5, // For Android shadow
  },

  // Dropdown styles (copied from student-form-modal.tsx)
  dropdownContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  dropdownText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  dropdownPlaceholderText: {
    color: colors.textSecondary,
  },

  dropdownOptions: {
    backgroundColor: colors.card,
    borderRadius: 8,
    marginTop: spacing.xs,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
    }),
  },

  dropdownOption: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  dropdownOptionText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  selectedOption: {
    fontWeight: typography.weights.bold,
    color: colors.primary,
  },

  dropdownSubtext: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },

  disabledInput: {
    opacity: 0.6,
  },

  deleteButton: {
    padding: spacing.sm,
    borderRadius: 8,
    backgroundColor: colors.error + '20', // 20 is 20% opacity
  },

  dropdownBackdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 999,
  },
});