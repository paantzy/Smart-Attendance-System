import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Dimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
// import { useTheme } from '@react-navigation/native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  interpolate,
} from 'react-native-reanimated';
import { colors } from '@/styles/commonStyles';
import { IconSymbol } from '@/components/IconSymbol';
import { useRouter, usePathname } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

export interface TabBarItem {
  name: string;
  route: string;
  icon: string;
  label: string;
}

interface FloatingTabBarProps {
  tabs: TabBarItem[];
  containerWidth?: number;
  borderRadius?: number;
  bottomMargin?: number;
}

export default function FloatingTabBar({
  tabs,
  containerWidth = Dimensions.get('window').width - 32,
  borderRadius = 25,
  bottomMargin = 20,
}: FloatingTabBarProps) {
  const pathname = usePathname();
  // const theme = useTheme();
  const router = useRouter();
  const translateY = useSharedValue(0);

  // Log the tabs being received for debugging
  React.useEffect(() => {
    console.log('FloatingTabBar received tabs:', tabs);
    console.log('Number of tabs to render:', tabs.length);
    tabs.forEach((tab, index) => {
      console.log(`Tab ${index + 1}: ${tab.label} (${tab.name}) - Route: ${tab.route}`);
    });
  }, [tabs]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        {
          translateY: withSpring(translateY.value, {
            damping: 20,
            stiffness: 90,
          }),
        },
      ],
    };
  });

  const handleTabPress = (route: string) => {
    console.log('Tab pressed:', route);
    router.push(route as any);
  };

  const isActive = (route: string) => {
    return pathname === route || pathname.startsWith(route);
  };

  // Platform-specific styling for better compatibility
  const getTabBarStyle = () => {
    if (Platform.OS === 'web') {
      // Simpler styling for web to avoid performance issues
      return {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.15)',
        borderWidth: 0.5,
        borderColor: 'rgba(0, 0, 0, 0.1)',
      };
    } else {
      // Native styling with blur effect
      return {
        backgroundColor: colors.card,
        shadowColor: colors.shadow,
        shadowOffset: {
          width: 0,
          height: 8,
        },
        shadowOpacity: 0.15,
        shadowRadius: 20,
        elevation: 10,
        borderWidth: Platform.OS === 'ios' ? 0.5 : 0,
        borderColor: 'rgba(0, 0, 0, 0.1)',
      };
    }
  };

  // Calculate tab width based on number of tabs for better responsiveness
  const getTabWidth = () => {
    if (tabs.length <= 4) {
      return { flex: 1 };
    } else {
      // For more tabs, use fixed width to prevent overcrowding
      const maxWidth = (containerWidth - 32) / 5; // Leave some padding
      return { 
        minWidth: Math.min(maxWidth, 80),
        maxWidth: 100,
        paddingHorizontal: 2
      };
    }
  };

  return (
    <SafeAreaView style={[styles.container, { bottom: bottomMargin }]} edges={['bottom']}>
      <Animated.View style={[animatedStyle]}>
        {Platform.OS === 'web' ? (
          // Simpler view for web without BlurView for better performance
          <View
            style={[
              styles.tabBar,
              getTabBarStyle(),
              {
                width: containerWidth,
                borderRadius,
              },
            ]}
          >
            <View style={styles.tabContainer}>
              {tabs.map((tab, index) => {
                const active = isActive(tab.route);
                return (
                  <TouchableOpacity
                    key={tab.name}
                    style={[
                      styles.tab,
                      active && styles.activeTab,
                      getTabWidth()
                    ]}
                    onPress={() => handleTabPress(tab.route)}
                    activeOpacity={0.7}
                    // Enhanced touch properties for web
                    delayPressIn={Platform.OS === 'web' ? 100 : 0}
                    delayPressOut={Platform.OS === 'web' ? 100 : 0}
                  >
                    <View style={styles.tabContent}>
                      <IconSymbol
                        name={tab.icon as any}
                        size={24}
                        color={active ? colors.primary : colors.textSecondary}
                      />
                      <Text
                        style={[
                          styles.tabLabel,
                          {
                            color: active ? colors.primary : colors.textSecondary,
                            fontWeight: active ? '600' : '400',
                          },
                        ]}
                        numberOfLines={1}
                        adjustsFontSizeToFit={true}
                        minimumFontScale={0.8}
                      >
                        {tab.label}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        ) : (
          // Native implementation with BlurView
          <BlurView
            intensity={80}
            tint="light"
            style={[
              styles.tabBar,
              {
                width: containerWidth,
                borderRadius,
              },
            ]}
          >
            <View style={styles.tabContainer}>
              {tabs.map((tab, index) => {
                const active = isActive(tab.route);
                return (
                  <TouchableOpacity
                    key={tab.name}
                    style={[
                      styles.tab,
                      active && styles.activeTab,
                      getTabWidth()
                    ]}
                    onPress={() => handleTabPress(tab.route)}
                    activeOpacity={0.7}
                    // Enhanced touch properties for mobile
                    delayPressIn={Platform.OS === 'ios' ? 50 : 0}
                    delayPressOut={Platform.OS === 'ios' ? 50 : 0}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <View style={styles.tabContent}>
                      <IconSymbol
                        name={tab.icon as any}
                        size={24}
                        color={active ? colors.primary : colors.textSecondary}
                      />
                      <Text
                        style={[
                          styles.tabLabel,
                          {
                            color: active ? colors.primary : colors.textSecondary,
                            fontWeight: active ? '600' : '400',
                          },
                        ]}
                        numberOfLines={1}
                        adjustsFontSizeToFit={true}
                        minimumFontScale={0.8}
                      >
                        {tab.label}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          </BlurView>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 16,
    right: 16,
    alignItems: 'center',
    zIndex: 1000,
  },
  tabBar: {
    // Common styles for both platforms
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 8,
    paddingVertical: 8,
    justifyContent: 'space-around', // Better distribution of tabs
  },
  tab: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    borderRadius: 16,
    minHeight: 60,
  },
  activeTab: {
    backgroundColor: 'rgba(63, 81, 181, 0.1)',
  },
  tabContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabLabel: {
    fontSize: 11,
    marginTop: 4,
    textAlign: 'center',
    // Added responsive text properties
    includeFontPadding: false,
    textAlignVertical: 'center',
  },
});