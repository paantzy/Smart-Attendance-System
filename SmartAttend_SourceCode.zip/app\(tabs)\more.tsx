import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { router } from 'expo-router';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';

export default function MoreScreen() {
  const { userRole } = useAuth();

  // Define the options available in the More section
  const moreOptions = [
    {
      id: 'reports',
      title: 'Reports',
      description: 'Generate attendance reports',
      icon: 'doc.text.fill',
      route: '/(tabs)/reports',
      roles: ['admin', 'teacher'],
    },
    {
      id: 'qrCodes',
      title: 'QR Codes',
      description: 'Manage class QR codes',
      icon: 'qrcode',
      route: '/(tabs)/qr-codes',
      roles: ['admin', 'teacher'],
    },
    {
      id: 'attendanceStatus',
      title: 'Attendance Status',
      description: 'View attendance records',
      icon: 'list.bullet',
      route: '/(tabs)/attendance',
      roles: ['admin', 'teacher'],
    },
  ];

  // Filter options based on user role
  const filteredOptions = moreOptions.filter(option => 
    option.roles.includes(userRole as string)
  );

  const handleOptionPress = (route: string) => {
    router.push(route as any);
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <ScrollView 
        style={commonStyles.container}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>More Options</Text>
          <Text style={styles.subtitle}>Access additional features</Text>
        </View>

        <View style={styles.optionsContainer}>
          {filteredOptions.map((option) => (
            <TouchableOpacity
              key={option.id}
              style={[commonStyles.card, styles.optionCard]}
              onPress={() => handleOptionPress(option.route)}
              activeOpacity={0.7}
            >
              <View style={styles.optionIcon}>
                <IconSymbol 
                  name={option.icon as any} 
                  size={24} 
                  color={colors.card} 
                />
              </View>
              <View style={styles.optionContent}>
                <Text style={styles.optionTitle}>{option.title}</Text>
                <Text style={styles.optionDescription}>{option.description}</Text>
              </View>
              <IconSymbol 
                name="chevron.right" 
                size={20} 
                color={colors.textSecondary} 
              />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  contentContainer: {
    padding: spacing.lg,
  },
  header: {
    marginBottom: spacing.xl,
    alignItems: 'center',
  },
  title: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },
  optionsContainer: {
    width: '100%',
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
    padding: spacing.md,
  },
  optionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  optionContent: {
    flex: 1,
  },
  optionTitle: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  optionDescription: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },
});