import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { supabase } from '@/utils/supabase';
import { colors, typography, spacing } from '@/styles/commonStyles';

export default function ConnectionTest() {
  const [testStatus, setTestStatus] = useState('Not started');
  const [testResults, setTestResults] = useState<string[]>([]);

  const addResult = (result: string) => {
    setTestResults(prev => [...prev, result]);
  };

  const runConnectionTest = async () => {
    setTestStatus('Running...');
    setTestResults([]);
    
    try {
      addResult('1. Checking Supabase client initialization...');
      
      if (!supabase) {
        throw new Error('Supabase client is not initialized');
      }
      addResult('✅ Supabase client is initialized');
      
      addResult('2. Testing basic database connection...');
      // Try to connect to the database
      try {
        const { data, error } = await supabase.from('users').select('count').limit(1);
        if (error) {
          if (error.message.includes('Relation "users" does not exist')) {
            addResult('⚠️ Database connected but users table does not exist (this is expected initially)');
          } else {
            addResult(`⚠️ Database test returned error: ${error.message}`);
          }
        } else {
          addResult('✅ Database connection and users table both exist');
        }
      } catch (dbError: any) {
        addResult(`❌ Database connection failed: ${dbError.message}`);
        console.error('Database connection error:', dbError);
      }
      
      addResult('3. Testing auth session...');
      try {
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) {
          addResult(`⚠️ Auth session check has error: ${sessionError.message}`);
        } else {
          addResult(`✅ Auth session check passed. Session exists: ${!!sessionData.session}`);
        }
      } catch (authError: any) {
        addResult(`❌ Auth session check failed: ${authError.message}`);
        console.error('Auth session error:', authError);
      }
      
      setTestStatus('Completed');
      Alert.alert('Connection Test Completed', 'Check the results below');
    } catch (error: any) {
      setTestStatus('Error');
      addResult(`❌ Test failed: ${error.message}`);
      Alert.alert('Connection Test Failed', error.message);
      console.error('Connection test error:', error);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Server Connection Test</Text>
        <Text style={styles.subtitle}>Diagnose connection issues with your Supabase server</Text>
      </View>

      <View style={styles.content}>
        <TouchableOpacity 
          style={styles.testButton} 
          onPress={runConnectionTest}
        >
          <Text style={styles.testButtonText}>Test Server Connection</Text>
        </TouchableOpacity>

        <View style={styles.statusCard}>
          <Text style={styles.statusLabel}>Test Status:</Text>
          <Text style={styles.statusValue}>{testStatus}</Text>
        </View>

        <View style={styles.resultsCard}>
          <Text style={styles.resultsLabel}>Test Results:</Text>
          {testResults.map((result, index) => (
            <Text key={index} style={styles.resultItem}>{result}</Text>
          ))}
        </View>

        <View style={styles.troubleshooting}>
          <Text style={styles.troubleshootingTitle}>Troubleshooting Guide</Text>
          <Text style={styles.troubleshootingText}>1. Check your internet connection</Text>
          <Text style={styles.troubleshootingText}>2. Verify your Supabase URL is correct</Text>
          <Text style={styles.troubleshootingText}>3. Check that your API key is valid</Text>
          <Text style={styles.troubleshootingText}>4. Ensure your Supabase project is not paused</Text>
          <Text style={styles.troubleshootingText}>5. Check if your IP is allowed in Supabase settings</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: spacing.lg,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  title: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },
  content: {
    flex: 1,
  },
  testButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  testButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.card,
  },
  statusCard: {
    backgroundColor: colors.card,
    padding: spacing.lg,
    borderRadius: 12,
    marginBottom: spacing.md,
  },
  statusLabel: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  statusValue: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.text,
  },
  resultsCard: {
    backgroundColor: colors.card,
    padding: spacing.lg,
    borderRadius: 12,
    marginBottom: spacing.md,
  },
  resultsLabel: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  resultItem: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    fontFamily: 'monospace',
  },
  troubleshooting: {
    backgroundColor: colors.card,
    padding: spacing.lg,
    borderRadius: 12,
  },
  troubleshootingTitle: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
  },
  troubleshootingText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
});