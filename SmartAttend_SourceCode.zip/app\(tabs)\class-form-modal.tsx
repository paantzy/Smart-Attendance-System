import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';

interface ClassFormData {
  name: string;
  teacher: string;
  schedule: string;
  form: string;
}

interface ClassFormModalProps {
  visible: boolean;
  editingClass: any;
  initialFormData: ClassFormData;
  onClose: () => void;
  onSave: (formData: ClassFormData) => void;
}

export default function ClassFormModal({
  visible,
  editingClass,
  initialFormData,
  onClose,
  onSave,
}: ClassFormModalProps) {
  const [formData, setFormData] = useState<ClassFormData>(initialFormData);
  const [showFormDropdown, setShowFormDropdown] = useState(false);

  // Form options
  const formOptions = ['Form1', 'Form2', 'Form3', 'Form4', 'Form5'];

  // Reset form data when initialFormData changes
  useEffect(() => {
    setFormData(initialFormData);
  }, [initialFormData]);

  // Focus management to prevent autocomplete issues
  const inputRefs = {
    name: React.useRef(null),
    teacher: React.useRef(null),
    schedule: React.useRef(null),
  };

  const handleFormChange = useCallback((field: keyof ClassFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  }, []);

  const handleSave = useCallback(() => {
    onSave(formData);
  }, [formData, onSave]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView 
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 80}
      >
        <SafeAreaView style={commonStyles.safeArea}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={onClose}>
              <Text style={styles.cancelButton}>Cancel</Text>
            </TouchableOpacity>
            <Text style={commonStyles.subtitle}>
              {editingClass ? 'Edit Class' : 'Add New Class'}
            </Text>
            <TouchableOpacity onPress={handleSave}>
              <Text style={styles.saveButton}>Save</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={commonStyles.content}>
            <View style={styles.formGroup}>
              <Text style={styles.label}>Class Name</Text>
              <TextInput
                style={commonStyles.input}
                value={formData.name}
                onChangeText={(text) => handleFormChange('name', text)}
                placeholder="Enter class name"
                placeholderTextColor={colors.textSecondary}
                key="name-input"
                autoComplete="off"
                autoCorrect={false}
                spellCheck={false}
                autoCapitalize="none"
                textContentType="none"
                keyboardType="default"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Teacher</Text>
              <TextInput
                style={commonStyles.input}
                value={formData.teacher}
                onChangeText={(text) => handleFormChange('teacher', text)}
                placeholder="e.g., Cikgu Asliza, Cikgu Nonie, Cikgu Fariha, Cikgu Rosliza"
                placeholderTextColor={colors.textSecondary}
                key="teacher-input"
                autoComplete="off"
                autoCorrect={false}
                spellCheck={false}
                autoCapitalize="words"
                textContentType="none"
                keyboardType="default"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Schedule</Text>
              <TextInput
                style={commonStyles.input}
                value={formData.schedule}
                onChangeText={(text) => handleFormChange('schedule', text)}
                placeholder="e.g., Mon - 7:00 AM"
                placeholderTextColor={colors.textSecondary}
                key="schedule-input"
                autoComplete="off"
                autoCorrect={false}
                spellCheck={false}
                autoCapitalize="none"
                textContentType="none"
                keyboardType="default"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Form</Text>
              <TouchableOpacity
                style={commonStyles.input}
                onPress={() => setShowFormDropdown(!showFormDropdown)}
                key="form-dropdown"
              >
                <View style={styles.dropdownContainer}>
                  <Text style={[styles.dropdownText, !formData.form && styles.placeholderText]}>
                    {formData.form || 'Select Form'}
                  </Text>
                  <IconSymbol name="chevron.down" size={16} color={colors.textSecondary} />
                </View>
              </TouchableOpacity>
              
              {showFormDropdown && (
                <View style={styles.dropdownOptions}>
                  {formOptions.map((form) => (
                    <TouchableOpacity
                      key={form}
                      style={styles.dropdownOption}
                      onPress={() => {
                        handleFormChange('form', form);
                        setShowFormDropdown(false);
                      }}
                    >
                      <Text style={[
                        styles.dropdownOptionText,
                        formData.form === form && styles.selectedOption
                      ]}>
                        {form}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>
          </ScrollView>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  cancelButton: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },

  saveButton: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.primary,
  },

  formGroup: {
    marginBottom: spacing.md,
  },

  label: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  dropdownContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  dropdownText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  placeholderText: {
    color: colors.textSecondary,
  },

  dropdownOptions: {
    backgroundColor: colors.card,
    borderRadius: 8,
    marginTop: spacing.xs,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
    }),
  },

  dropdownOption: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  dropdownOptionText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  selectedOption: {
    fontWeight: typography.weights.bold,
    color: colors.primary,
  },
});