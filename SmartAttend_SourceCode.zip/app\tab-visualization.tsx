import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';
import { IconSymbol } from '@/components/IconSymbol';

export default function TabVisualizationScreen() {
  // Define the tabs as they should appear
  const allTabs = [
    { name: 'dashboard', label: 'Dashboard', icon: 'chart.bar.fill' },
    { name: 'classes', label: 'Classes', icon: 'building.2.fill' },
    { name: 'students', label: 'Students', icon: 'person.3.fill' },
    { name: 'scanner', label: 'Scanner', icon: 'qrcode.viewfinder' },
    { name: 'reports', label: 'Reports', icon: 'doc.text.fill' },
    { name: 'attendance', label: 'Attendance', icon: 'list.bullet' },
    { name: 'qrcodes', label: 'QR Codes', icon: 'qrcode' },
    // Removed appqrcode tab
  ];

  // Define role-specific access
  const roleAccess = {
    admin: allTabs.map(tab => tab.name),
    teacher: allTabs.map(tab => tab.name),
    parent: allTabs.filter(tab => !['scanner'].includes(tab.name)).map(tab => tab.name),
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        <Text style={commonStyles.title}>Tab Navigation Visualization</Text>
        <Text style={styles.subtitle}>Expected bottom tab navigation layout</Text>
        
        <ScrollView style={styles.content}>
          {/* Visual representation of the tab bar */}
          <View style={styles.tabBarVisualization}>
            <Text style={styles.tabBarTitle}>Bottom Tab Navigation</Text>
            <View style={styles.tabBarContainer}>
              {allTabs.map((tab, index) => (
                <View key={index} style={styles.tabItem}>
                  <IconSymbol name={tab.icon as any} size={24} color={colors.primary} />
                  <Text style={styles.tabLabel}>{tab.label}</Text>
                </View>
              ))}
            </View>
          </View>
          
          {/* Role-specific access information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Role-Based Tab Access</Text>
            
            <View style={styles.roleSection}>
              <Text style={styles.roleTitle}>Admin</Text>
              <View style={styles.roleTabs}>
                {allTabs.map((tab, index) => (
                  <View 
                    key={index} 
                    style={[
                      styles.roleTab, 
                      roleAccess.admin.includes(tab.name) ? styles.accessGranted : styles.accessDenied
                    ]}
                  >
                    <Text style={styles.roleTabText}>{tab.label}</Text>
                  </View>
                ))}
              </View>
            </View>
            
            <View style={styles.roleSection}>
              <Text style={styles.roleTitle}>Teacher</Text>
              <View style={styles.roleTabs}>
                {allTabs.map((tab, index) => (
                  <View 
                    key={index} 
                    style={[
                      styles.roleTab, 
                      roleAccess.teacher.includes(tab.name) ? styles.accessGranted : styles.accessDenied
                    ]}
                  >
                    <Text style={styles.roleTabText}>{tab.label}</Text>
                  </View>
                ))}
              </View>
            </View>
            
            <View style={styles.roleSection}>
              <Text style={styles.roleTitle}>Parent</Text>
              <View style={styles.roleTabs}>
                {allTabs.map((tab, index) => (
                  <View 
                    key={index} 
                    style={[
                      styles.roleTab, 
                      roleAccess.parent.includes(tab.name) ? styles.accessGranted : styles.accessDenied
                    ]}
                  >
                    <Text style={styles.roleTabText}>{tab.label}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>
          
          {/* Scanner Tab Details */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Scanner Tab Details</Text>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Tab Name:</Text>
              <Text style={styles.detailValue}>Scanner</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Icon:</Text>
              <Text style={styles.detailValue}>qrcode.viewfinder</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Route:</Text>
              <Text style={styles.detailValue}>/(tabs)/scanner</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Access:</Text>
              <Text style={styles.detailValue}>Admin & Teacher only</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Functionality:</Text>
              <Text style={styles.detailValue}>QR code scanning for student attendance</Text>
            </View>
          </View>
          
          {/* QR Codes Tab Details */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>QR Codes Tab Details</Text>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Tab Name:</Text>
              <Text style={styles.detailValue}>QR Codes</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Icon:</Text>
              <Text style={styles.detailValue}>qrcode</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Route:</Text>
              <Text style={styles.detailValue}>/(tabs)/qr-codes</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Access:</Text>
              <Text style={styles.detailValue}>All roles</Text>
            </View>
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>Functionality:</Text>
              <Text style={styles.detailValue}>Display QR codes for all students</Text>
            </View>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },
  
  subtitle: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  
  tabBarVisualization: {
    ...commonStyles.card,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  
  tabBarTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
    textAlign: 'center',
  },
  
  tabBarContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 16,
    paddingVertical: spacing.sm,
  },
  
  tabItem: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xs,
  },
  
  tabLabel: {
    fontSize: typography.sizes.xs,
    color: colors.text,
    marginTop: spacing.xs,
  },
  
  section: {
    ...commonStyles.card,
    marginBottom: spacing.md,
    padding: spacing.md,
  },
  
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
    textAlign: 'center',
  },
  
  roleSection: {
    marginBottom: spacing.md,
  },
  
  roleTitle: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  
  roleTabs: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  
  roleTab: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 8,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
  },
  
  accessGranted: {
    backgroundColor: colors.success + '20',
    borderColor: colors.success,
    borderWidth: 1,
  },
  
  accessDenied: {
    backgroundColor: colors.error + '20',
    borderColor: colors.error,
    borderWidth: 1,
  },
  
  roleTabText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
  },
  
  detailItem: {
    flexDirection: 'row',
    marginBottom: spacing.sm,
    alignItems: 'center',
  },
  
  detailLabel: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
    color: colors.textSecondary,
    width: 100,
  },
  
  detailValue: {
    fontSize: typography.sizes.md,
    color: colors.text,
    flex: 1,
  },
});