import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@/contexts/AuthContext';
import { getTabsForRole } from '@/utils/roleManager';
import { supabase } from '@/utils/supabase';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';

export default function DiagnosticScreen() {
  const { userRole, userId } = useAuth();
  const [dbUserRole, setDbUserRole] = useState<string | null>(null);
  const [sessionInfo, setSessionInfo] = useState<any>(null);
  const [tabsInfo, setTabsInfo] = useState<any>(null);

  useEffect(() => {
    const runDiagnostics = async () => {
      try {
        // Get session info
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) {
          console.error('Session error:', sessionError);
        } else {
          setSessionInfo(session);
        }

        // Get user role from database
        if (userId) {
          const { data, error } = await supabase
            .from('users')
            .select('user_type')
            .eq('id', userId)
            .single();
          
          if (error) {
            console.error('Database query error:', error);
          } else if (data) {
            setDbUserRole(data.user_type);
          }
        }

        // Get tabs info
        if (userRole) {
          const tabs = getTabsForRole(userRole);
          setTabsInfo({
            role: userRole,
            tabs: tabs,
            hasQrCodes: tabs.some(tab => tab.name === 'qrcodes'),
            tabCount: tabs.length
          });
        }
      } catch (error) {
        console.error('Diagnostic error:', error);
        Alert.alert('Error', 'Failed to run diagnostics: ' + (error as Error).message);
      }
    };

    runDiagnostics();
  }, [userRole, userId]);

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        <Text style={commonStyles.title}>App Diagnostics</Text>
        
        <ScrollView style={styles.content}>
          <View style={commonStyles.card}>
            <Text style={styles.sectionTitle}>Authentication Status</Text>
            <Text style={styles.infoText}>App Context User Role: {userRole || 'Not set'}</Text>
            <Text style={styles.infoText}>Database User Role: {dbUserRole || 'Not fetched'}</Text>
            <Text style={styles.infoText}>User ID: {userId || 'Not set'}</Text>
            <Text style={styles.infoText}>Session Active: {sessionInfo ? 'Yes' : 'No'}</Text>
          </View>

          <View style={commonStyles.card}>
            <Text style={styles.sectionTitle}>Tab Configuration</Text>
            {tabsInfo ? (
              <>
                <Text style={styles.infoText}>Role: {tabsInfo.role}</Text>
                <Text style={styles.infoText}>Tab Count: {tabsInfo.tabCount}</Text>
                <Text style={styles.infoText}>Has QR Codes Tab: {tabsInfo.hasQrCodes ? '✅ Yes' : '❌ No'}</Text>
                <Text style={styles.sectionTitle}>Tabs List:</Text>
                {tabsInfo.tabs.map((tab: any, index: number) => (
                  <Text key={index} style={styles.tabItem}>
                    {index + 1}. {tab.name} - {tab.label}
                  </Text>
                ))}
              </>
            ) : (
              <Text style={styles.infoText}>Loading tab information...</Text>
            )}
          </View>

          <View style={commonStyles.card}>
            <Text style={styles.sectionTitle}>Debug Information</Text>
            <Text style={styles.infoText}>Platform: {require('react-native').Platform.OS}</Text>
            <Text style={styles.infoText}>Timestamp: {new Date().toISOString()}</Text>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  infoText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  tabItem: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginLeft: spacing.md,
    marginBottom: spacing.xs,
  },
});