import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import { addStudent } from '../utils/studentUtils';

export default function AddStudentScreen() {
  const [studentName, setStudentName] = useState('');
  const [grade, setGrade] = useState('');
  const [classValue, setClassValue] = useState('');
  const [parentContact, setParentContact] = useState('');
  const [emailStudent, setEmailStudent] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAddStudent = async () => {
    // Basic validation
    if (!studentName || !grade || !classValue || !parentContact || !emailStudent) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailStudent)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    setLoading(true);
    try {
      await addStudent({
        student_name: studentName,
        grade: grade,
        class_name: classValue,
        parent_contact: parentContact,
        email_student: emailStudent,
      });
      
      Alert.alert('Success', 'Student added successfully!');
      
      // Clear form
      setStudentName('');
      setGrade('');
      setClassValue('');
      setParentContact('');
      setEmailStudent('');
    } catch (error) {
      console.error('Error adding student:', error);
      Alert.alert('Error', 'Failed to add student. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add New Student</Text>
      
      <View style={styles.form}>
        <Text style={styles.label}>Student Name</Text>
        <TextInput
          style={styles.input}
          value={studentName}
          onChangeText={setStudentName}
          placeholder="Enter student name"
        />
        
        <Text style={styles.label}>Grade</Text>
        <TextInput
          style={styles.input}
          value={grade}
          onChangeText={setGrade}
          placeholder="Enter grade"
        />
        
        <Text style={styles.label}>Class</Text>
        <TextInput
          style={styles.input}
          value={classValue}
          onChangeText={setClassValue}
          placeholder="Enter class"
        />
        
        <Text style={styles.label}>Parent Contact</Text>
        <TextInput
          style={styles.input}
          value={parentContact}
          onChangeText={setParentContact}
          placeholder="Enter parent contact"
          keyboardType="phone-pad"
        />
        
        <Text style={styles.label}>Student Email</Text>
        <TextInput
          style={styles.input}
          value={emailStudent}
          onChangeText={setEmailStudent}
          placeholder="Enter student email"
          keyboardType="email-address"
        />
        
        <TouchableOpacity 
          style={[styles.button, loading && styles.buttonDisabled]} 
          onPress={handleAddStudent}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? 'Adding...' : 'Add Student'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: '#333',
  },
  form: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 3,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 5,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 15,
  },
  button: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonDisabled: {
    backgroundColor: '#ccc',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
});