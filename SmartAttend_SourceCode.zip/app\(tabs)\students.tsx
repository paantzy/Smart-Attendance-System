import React, { useState, useCallback, useMemo, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  Image,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { router } from 'expo-router';
import StudentFormModal from './student-form-modal';
import { useAuth } from '@/contexts/AuthContext';
import { addStudent, getStudents, deleteStudent, updateStudent } from '../../utils/studentOperations';
import { addClassTeacherStudent } from '../../utils/classTeacherStudentOperations';
import { supabase } from '../../utils/supabase';

interface StudentData {
  id: string;
  name: string;
  grade: string;
  parentContact: string;
  email: string;
  photo: string;
  attendanceRate: number;
  className?: string;  // Added back: className for display purposes
}

interface StudentFormData {
  name: string;
  grade: string;
  class: string;  // Class field (optional)
  parentContact: string;
  email: string;
}

interface StudentFormModalProps {
  visible: boolean;
  editingStudent: any;
  initialFormData: StudentFormData;
  onClose: () => void;
  onSave: (formData: StudentFormData) => void;
  onFormChange: (formData: StudentFormData) => void;
}

function StudentsScreen() {
  const { userRole } = useAuth();
  const [students, setStudents] = useState<StudentData[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<StudentData | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('All');
  const [formData, setFormData] = useState({
    name: '',
    grade: '',
    class: '',  // Class field (optional)
    parentContact: '',
    email: '',
  });
  
  // Add state for attendance data
  const [studentAttendanceData, setStudentAttendanceData] = useState<Record<string, any>>({});
  const [loadingAttendance, setLoadingAttendance] = useState(false);

  console.log('StudentsScreen rendered on platform:', Platform.OS);

  // Load students from Supabase on component mount
  useEffect(() => {
    loadStudents();
    
    // Set up real-time listener for student changes
    const channel = supabase
      .channel('students-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'students',
        },
        (payload) => {
          // A new student was added, add it to the list
          const newStudentRecord = payload.new;
          const newStudent: StudentData = {
            id: newStudentRecord.student_id,
            name: newStudentRecord.student_name,
            grade: newStudentRecord.grade,
            parentContact: newStudentRecord.parent_contact,
            email: newStudentRecord.email_student,
            photo: 'person', // Default photo
            attendanceRate: 0, // Default to 0%
            className: newStudentRecord.class_name || undefined,  // Added back: className
          };
          setStudents(prev => [...prev, newStudent]);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'students',
        },
        (payload) => {
          // A student was updated, update it in the list
          const updatedStudentRecord = payload.new;
          const updatedStudent: StudentData = {
            id: updatedStudentRecord.student_id,
            name: updatedStudentRecord.student_name,
            grade: updatedStudentRecord.grade,
            parentContact: updatedStudentRecord.parent_contact,
            email: updatedStudentRecord.email_student,
            photo: 'person', // Default photo
            attendanceRate: 0, // Default to 0%
            className: updatedStudentRecord.class_name || undefined,  // Added back: className
          };
          
          setStudents(prev => 
            prev.map(student => 
              student.id === updatedStudent.id ? updatedStudent : student
            )
          );
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'students',
        },
        (payload) => {
          // A student was deleted, remove it from the list
          const deletedStudentId = payload.old.student_id;
          setStudents(prev => prev.filter(student => student.id !== deletedStudentId));
        }
      )
      .subscribe();

    // Clean up the subscription
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Load attendance data whenever students list changes
  useEffect(() => {
    if (students.length > 0) {
      loadStudentAttendanceData(students);
    }
  }, [students]);

  const loadStudents = async () => {
    try {
      setLoading(true);
      console.log('Loading students on platform:', Platform.OS);
      const supabaseStudents = await getStudents();
      console.log('Students loaded:', supabaseStudents?.length || 0);
      
      // Transform Supabase data to match the existing UI structure
      const transformedStudents: StudentData[] = supabaseStudents.map((student: any) => ({
        id: student.student_id,
        name: student.student_name,
        grade: student.grade,
        parentContact: student.parent_contact,
        email: student.email_student,
        photo: 'person', // Default photo
        attendanceRate: 0, // Default to 0% until we load real data
        className: student.class_name || undefined,  // Added back: className
      }));
        
      // Initialize studentAttendanceData with default values for all students
      const initialAttendanceData: Record<string, any> = {};
      transformedStudents.forEach(student => {
        initialAttendanceData[student.id] = { present: 0, total: 0, rate: 0 };
      });
      setStudentAttendanceData(initialAttendanceData);
      
      console.log('Transformed students:', transformedStudents.length);
      setStudents(transformedStudents);
    } catch (error) {
      console.error('Error loading students:', error);
      Alert.alert('Error', 'Failed to load students: ' + (error as Error).message);
    } finally {
      setLoading(false);
    }
  };

  // Function to load attendance data for all students
  const loadStudentAttendanceData = async (currentStudents: StudentData[] = students) => {
    try {
      setLoadingAttendance(true);
      // Dynamically import to avoid circular dependencies
      const { getAttendanceRecords } = await import('../../utils/attendanceOperations');
      const attendanceRecords = await getAttendanceRecords();
      
      // Process attendance records to calculate rates per student
      const attendanceMap: Record<string, { present: number; total: number; rate: number }> = {};
      
      // Initialize all students with 0 attendance
      currentStudents.forEach(student => {
        attendanceMap[student.id] = { present: 0, total: 0, rate: 0 };
      });
      
      // Calculate attendance rates
      attendanceRecords.forEach(record => {
        const studentId = record.student_id;
        if (studentId) {
          // Initialize entry if it doesn't exist
          if (!attendanceMap[studentId]) {
            attendanceMap[studentId] = { present: 0, total: 0, rate: 0 };
          }
          
          attendanceMap[studentId].total += 1;
          if (record.status === 'present' || record.status === 'late') {
            attendanceMap[studentId].present += 1;
          }
          // Calculate rate: present/total * 100
          if (attendanceMap[studentId].total > 0) {
            attendanceMap[studentId].rate = Math.round(
              (attendanceMap[studentId].present / attendanceMap[studentId].total) * 100
            );
          }
        }
      });
      
      setStudentAttendanceData(attendanceMap);
      console.log('Loaded attendance data for', Object.keys(attendanceMap).length, 'students');
    } catch (error) {
      console.error('Error loading student attendance data:', error);
    } finally {
      setLoadingAttendance(false);
    }
  };

  // Import the sync function
  const handleSyncAttendance = async () => {
    try {
      setLoading(true);
      // Dynamically import the sync function to avoid circular dependencies
      const { syncAttendanceWithStudents } = await import('../../utils/attendanceSync');
      await syncAttendanceWithStudents();
      Alert.alert('Success', 'Attendance data synchronized successfully');
      // Reload students and attendance data to update UI
      await loadStudents();
      // Note: loadStudentAttendanceData will be called automatically by the useEffect when students change
    } catch (error) {
      console.error('Error syncing attendance:', error);
      Alert.alert('Error', 'Failed to sync attendance data: ' + (error as Error).message);
    } finally {
      setLoading(false);
    }
  };

  // Check if user is a parent
  const isParent = userRole === 'parent';

  // Get unique grades from students
  const uniqueGrades = useMemo(() => {
    const grades = students.map(student => student.grade);
    return ['All', ...Array.from(new Set(grades))];
  }, [students]);

  // Filter students based on search query and selected grade
  const filteredStudents = useMemo(() => {
    return students.filter(student => {
      const matchesSearch = 
        (student.name && student.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (student.email && student.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (student.className && student.className.toLowerCase().includes(searchQuery.toLowerCase()));  // Added back: className search
      
      const matchesGrade = selectedGrade === 'All' || student.grade === selectedGrade;
      
      return matchesSearch && matchesGrade;
    });
  }, [students, searchQuery, selectedGrade]);

  const handleDeleteStudent = async (studentId: string) => {
    Alert.alert(
      'Delete Student',
      'Are you sure you want to delete this student?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              // Delete from Supabase
              console.log('Attempting to delete student with ID:', studentId);
              await deleteStudent(studentId);
              console.log('Successfully deleted student from Supabase');
              
              // Update local state
              setStudents(students.filter(student => student.id !== studentId));
              
              Alert.alert('Success', 'Student deleted successfully');
            } catch (error: any) {
              console.error('Error deleting student:', error);
              console.error('Supabase delete error:', error.message);
              
              // Provide more specific error messages
              let errorMessage = 'Failed to delete student';
              if (error?.message) {
                errorMessage = error.message;
              }
              Alert.alert('Error', errorMessage);
            }
          },
        },
      ]
    );
  };

  const openEditModal = (student: StudentData) => {
    setEditingStudent(student);
    setFormData({
      name: student.name,
      grade: student.grade,
      class: student.className || '',  // Added back: class field
      parentContact: student.parentContact,
      email: student.email,
    });
  };

  const handleSaveStudent = async (currentFormData: any) => {
    try {
      // Trim whitespace from all fields
      const trimmedData = {
        name: currentFormData.name.trim(),
        grade: currentFormData.grade.trim(),
        class: currentFormData.class.trim(),
        parentContact: currentFormData.parentContact.trim(),
        email: currentFormData.email.trim(),
      };
      
      // Debugging: Log the form data to see what's actually in each field
      console.log('Students Form Data Debug:', {
        original: currentFormData,
        trimmed: trimmedData,
        nameEmpty: !trimmedData.name,
        gradeEmpty: !trimmedData.grade,
        parentContactEmpty: !trimmedData.parentContact,
        emailEmpty: !trimmedData.email
      });
      
      // Validation - class is optional, others are required
      if (!trimmedData.name) {
        Alert.alert('Error', 'Student name is required');
        return;
      }
      
      if (!trimmedData.grade) {
        Alert.alert('Error', 'Form level is required');
        return;
      }
      
      if (!trimmedData.parentContact) {
        Alert.alert('Error', 'Parent contact is required');
        return;
      }
      
      if (!trimmedData.email) {
        Alert.alert('Error', 'Student email is required');
        return;
      }

      const studentData = {
        student_name: trimmedData.name,
        grade: trimmedData.grade,
        class_name: trimmedData.class || '',  // Include class name
        parent_contact: trimmedData.parentContact,
        email_student: trimmedData.email,
      };

      let newStudentRecord;
      if (editingStudent) {
        // Update existing student
        newStudentRecord = await updateStudent(editingStudent.id, studentData);
        Alert.alert('Success', 'Student updated successfully');
      } else {
        // Add new student
        newStudentRecord = await addStudent(studentData);
        Alert.alert('Success', 'Student added successfully!');
      }

      // Add to local state for immediate UI update
      const newStudent: StudentData = {
        id: newStudentRecord?.student_id || Date.now().toString(),
        name: trimmedData.name,
        grade: trimmedData.grade,
        parentContact: trimmedData.parentContact,
        email: trimmedData.email,
        photo: 'person',
        attendanceRate: 0,
        className: trimmedData.class || undefined,  // Added back: className
      };
      
      if (editingStudent) {
        // Update existing student in the list
        setStudents(students.map(student => 
          student.id === editingStudent.id ? newStudent : student
        ));
      } else {
        // Add new student to the list
        setStudents([...students, newStudent]);
      }

      // Reset form and close modal
      setEditingStudent(null);
      setFormData({
        name: '',
        grade: '',
        class: '',  // Class field (optional)
        parentContact: '',
        email: '',
      });
      setShowAddModal(false);
    } catch (error: any) {
      console.error('Error saving student:', error);
      // Provide more specific error messages
      let errorMessage = 'Failed to save student';
      if (error?.message) {
        errorMessage += `: ${error.message}`;
      } else if (error?.code) {
        errorMessage += `: ${error.code}`;
      }
      Alert.alert('Error', errorMessage);
    }
  };

  const StudentCard = ({ student }: { student: StudentData }) => {
    // Get attendance data for this student
    const attendanceData = studentAttendanceData[student.id];
    const hasAttendanceData = !!attendanceData;
    const attendanceRate = hasAttendanceData ? attendanceData.rate : 0;
    
    return (
      <View style={[commonStyles.card, styles.studentCard]}>
        <TouchableOpacity 
          style={styles.studentContent}
          onPress={() => {
            console.log('Student card pressed:', student.id);
            // Navigate to student profile
            router.push({
              pathname: '/(tabs)/student-profile',
              params: { studentId: student.id }
            });
          }}
          activeOpacity={0.7}
          // Enhanced touch properties for better mobile responsiveness
          delayPressIn={Platform.OS === 'ios' ? 50 : 0}
          delayPressOut={Platform.OS === 'ios' ? 50 : 0}
          delayLongPress={Platform.OS === 'ios' ? 500 : 300}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <View style={styles.studentHeader}>
            {student.photo === 'person' ? (
              <View style={[styles.studentPhoto, { justifyContent: 'center', alignItems: 'center', backgroundColor: colors.card }]}>
                <IconSymbol name="person.fill" size={24} color={colors.textSecondary} />
              </View>
            ) : (
              <Image source={{ uri: student.photo }} style={styles.studentPhoto} />
            )}
            <View style={styles.studentInfo}>
              <Text style={styles.studentName}>{student.name}</Text>
              <Text style={styles.studentGrade}>{student.grade}</Text>
              {student.className && (  // Added back: className display
                <Text style={styles.studentClass}>{student.className}</Text>
              )}
            </View>
            {/* QR Code Icon */}
            <View style={styles.qrIconContainer}>
              <IconSymbol name="qrcode" size={20} color={colors.primary} />
            </View>
          </View>

          <View style={styles.studentDetails}>
            <View style={styles.detailRow}>
              <IconSymbol name="phone" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>{student.parentContact}</Text>
            </View>
            <View style={styles.detailRow}>
              <IconSymbol name="envelope" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>{student.email}</Text>
            </View>
          </View>

          <View style={styles.attendanceSection}>
            <Text style={styles.attendanceLabel}>Attendance Rate</Text>
            <View style={styles.attendanceIndicator}>
              <View style={styles.attendanceBar}>
                <View
                  style={[
                    styles.attendanceProgress,
                    {
                      width: `${attendanceRate}%`,
                      backgroundColor: attendanceRate >= 90 ? colors.success :
                        attendanceRate >= 75 ? colors.warning : colors.error,
                    },
                  ]}
                />
              </View>
              <Text style={styles.attendanceRate}>{attendanceRate}%</Text>
            </View>
            {loadingAttendance && (
              <Text style={[styles.attendanceLabel, { fontSize: typography.sizes.xs, color: colors.textSecondary, marginTop: 2 }]}>
                Loading...
              </Text>
            )}
            {!loadingAttendance && !hasAttendanceData && (
              <Text style={[styles.attendanceLabel, { fontSize: typography.sizes.xs, color: colors.textSecondary, marginTop: 2 }]}>
                No attendance records
              </Text>
            )}
          </View>
        </TouchableOpacity>
        
        {/* Hide edit and delete buttons for parents */}
        {!isParent && (
          <View style={styles.studentActions}>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => {
                console.log('Edit button pressed for student:', student.id);
                openEditModal(student);
              }}
              activeOpacity={0.7}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              delayPressIn={Platform.OS === 'ios' ? 50 : 0}
              delayPressOut={Platform.OS === 'ios' ? 50 : 0}
            >
              <IconSymbol name="pencil" size={16} color={colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => {
                console.log('Delete button pressed for student:', student.id);
                handleDeleteStudent(student.id);
              }}
              activeOpacity={0.7}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              delayPressIn={Platform.OS === 'ios' ? 50 : 0}
              delayPressOut={Platform.OS === 'ios' ? 50 : 0}
            >
              <IconSymbol name="trash" size={16} color={colors.error} />
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={commonStyles.title}>Student Management</Text>
          <View style={{ flexDirection: 'row' }}>
            {/* Sync Attendance Button */}
            {!isParent && (
              <TouchableOpacity
                style={[styles.addButton, { marginRight: 10, backgroundColor: colors.warning }]}
                onPress={handleSyncAttendance}
                disabled={loading}
              >
                <IconSymbol name="arrow.clockwise" size={20} color={colors.card} />
              </TouchableOpacity>
            )}
            {/* Hide add button for parents */}
            {!isParent && (
              <TouchableOpacity
                style={styles.addButton}
                onPress={() => {
                  setEditingStudent(null);
                  setFormData({
                    name: '',
                    grade: '',
                    class: '',  // Added back: class field
                    parentContact: '',
                    email: '',
                  });
                  setShowAddModal(true);
                }}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                delayPressIn={Platform.OS === 'ios' ? 50 : 0}
                delayPressOut={Platform.OS === 'ios' ? 50 : 0}
              >
                <IconSymbol name="plus" size={20} color={colors.card} />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Search and Filter */}
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <IconSymbol name="magnifyingglass" size={20} color={colors.textSecondary} />
            <TextInput
              style={[styles.searchInput, { marginLeft: spacing.sm }]}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search students..."
              placeholderTextColor={colors.textSecondary}
            />
          </View>
          
          {/* Grade Filter */}
          <View style={styles.filterContainer}>
            <ScrollView 
              horizontal 
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.filterContent}
            >
              {uniqueGrades.map((grade) => (
                <TouchableOpacity
                  key={grade}
                  style={[
                    styles.filterButton,
                    selectedGrade === grade && styles.selectedFilterButton
                  ]}
                  onPress={() => setSelectedGrade(grade)}
                  hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  delayPressIn={Platform.OS === 'ios' ? 50 : 0}
                  delayPressOut={Platform.OS === 'ios' ? 50 : 0}
                >
                  <Text style={[
                    styles.filterButtonText,
                    selectedGrade === grade && styles.selectedFilterButtonText
                  ]}>
                    {grade}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>

        {/* Students List */}
        <ScrollView
          style={styles.content}
          contentContainerStyle={commonStyles.scrollContent}
          showsVerticalScrollIndicator={false}
          scrollEventThrottle={16}
          nestedScrollEnabled={false}
          bounces={false}
        >
          {loading ? (
            <View style={styles.loadingContainer}>
              <Text>Loading students...</Text>
            </View>
          ) : (
            <>
              {filteredStudents.map((student) => (
                <StudentCard key={student.id} student={student} />
              ))}
              
              {filteredStudents.length === 0 && (
                <View style={styles.emptyState}>
                  <IconSymbol name="person" size={48} color={colors.textSecondary} />
                  <Text style={styles.emptyText}>No students found</Text>
                  <Text style={styles.emptySubtext}>
                    {searchQuery || selectedGrade !== 'All'
                      ? 'Try adjusting your search or filter'
                      : 'Add your first student to get started'}
                  </Text>
                </View>
              )}
            </>
          )}
        </ScrollView>

        {/* Add/Edit Student Modal */}
        <StudentFormModal
          visible={showAddModal}
          onClose={() => setShowAddModal(false)}
          onSave={handleSaveStudent}
          editingStudent={editingStudent}
          initialFormData={formData}
          onFormChange={setFormData}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  addButton: {
    backgroundColor: colors.primary,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.sm,
  },

  searchContainer: {
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },

  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: spacing.md,
    borderRadius: 12,
    ...shadows.sm,
  },

  searchInput: {
    flex: 1,
    paddingVertical: spacing.sm,
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  filterContainer: {
    marginTop: spacing.sm,
  },

  filterContent: {
    paddingVertical: spacing.xs,
  },

  filterButton: {
    backgroundColor: colors.card,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: 16,
    marginRight: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },

  selectedFilterButton: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },

  filterButtonText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },

  selectedFilterButtonText: {
    color: colors.card,
    fontWeight: typography.weights.semibold,
  },

  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },

  studentCard: {
    marginBottom: spacing.md,
  },

  studentContent: {
    padding: spacing.md,
  },

  studentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },

  studentPhoto: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: spacing.md,
  },

  studentInfo: {
    flex: 1,
  },

  studentName: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  studentGrade: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },

  studentClass: {
    fontSize: typography.sizes.sm,
    color: colors.primary,
    fontWeight: typography.weights.medium,
  },

  qrIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
  },

  studentDetails: {
    marginBottom: spacing.md,
  },

  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },

  detailText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
    marginLeft: spacing.sm,
  },

  attendanceSection: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.md,
  },

  attendanceLabel: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },

  attendanceIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  attendanceBar: {
    flex: 1,
    height: 8,
    backgroundColor: colors.background,
    borderRadius: 4,
    overflow: 'hidden',
    marginRight: spacing.md,
  },

  attendanceProgress: {
    height: '100%',
    borderRadius: 4,
  },

  attendanceRate: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    minWidth: 40,
    textAlign: 'right',
  },

  studentActions: {
    position: 'absolute',
    right: spacing.md,
    bottom: spacing.md,
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: spacing.xs,
    ...shadows.sm,
  },

  actionButton: {
    padding: spacing.xs,
    marginHorizontal: spacing.xs,
  },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.xxl,
  },

  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.xxl,
  },

  emptyText: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginTop: spacing.md,
    marginBottom: spacing.xs,
  },

  emptySubtext: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: spacing.xl,
  },
});

export default StudentsScreen;