import React, { Component, ErrorInfo, ReactNode } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.setState({
      error,
      errorInfo,
    });
    
    // Log the error to console
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    // Also log to alert for immediate visibility
    Alert.alert(
      'Application Error',
      `An error occurred: ${error.message || 'Unknown error'}. The app will attempt to continue, but you may experience issues.`,
      [{ text: 'OK' }]
    );
  }

  public render() {
    if (this.state.hasError) {
      return (
        <View style={styles.container}>
          <Text style={styles.title}>Something went wrong</Text>
          <ScrollView style={styles.errorContainer}>
            <Text style={styles.errorText}>
              {this.state.error && this.state.error.toString()}
            </Text>
            <Text style={styles.errorDetails}>
              {this.state.errorInfo?.componentStack}
            </Text>
          </ScrollView>
          <TouchableOpacity 
            style={styles.retryButton}
            onPress={() => {
              this.setState({
                hasError: false,
                error: null,
                errorInfo: null,
              });
            }}
          >
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.retryButton, { backgroundColor: '#007AFF', marginTop: 10 }]}
            onPress={() => {
              // Try to reload the app
              // This is a simple way to reload the app
              try {
                // For Expo, we can try to reload the bundle
                // This might not work in all cases, but it's worth trying
                if (typeof require !== 'undefined' && require('expo')) {
                  const { reload } = require('expo');
                  reload();
                }
              } catch (e) {
                console.log('Could not reload app:', e);
                // If reload fails, at least reset the error state
                this.setState({
                  hasError: false,
                  error: null,
                  errorInfo: null,
                });
              }
            }}
          >
            <Text style={styles.retryButtonText}>Reload App</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return this.props.children;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  errorContainer: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
    maxHeight: 300,
  },
  errorText: {
    color: '#d32f2f',
    fontSize: 16,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  errorDetails: {
    color: '#666',
    fontSize: 12,
    fontFamily: 'monospace',
  },
  retryButton: {
    backgroundColor: '#1976d2',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  retryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ErrorBoundary;