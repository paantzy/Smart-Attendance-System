import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { getStudents } from '../../utils/studentOperations';
import { addClassTeacherStudent, getClassTeacherStudents, deleteClassTeacherStudent, ClassTeacherStudent, getClassNames, deleteClassByName } from '../../utils/classTeacherStudentOperations';
import { supabase } from '../../utils/supabase';

interface StudentData {
  student_id: string;
  student_name: string;
  grade: string;
  class_name: string;
  parent_contact: string;
}

interface ClassTeacherStudentData {
  id: number;
  class_name: string;  // Changed from class_id to class_name
  teacher_name: string;
  teacher_phone?: string;
  form_level: string;
  student_id: string;
  created_at: string;
  updated_at: string;
  student?: {
    student_name: string;
    grade: string;
    parent_contact: string;
    email_student: string;
  };
}

interface ClassGroup {
  className: string;  // Changed from classId and className
  teacherName: string;
  teacherPhone?: string;
  formLevel: string;
  students: {
    id: string;
    name: string;
    grade: string;
    parentContact?: string;
    email?: string;
  }[];
}

function ClassesScreen() {
  const { userRole } = useAuth();
  const [students, setStudents] = useState<StudentData[]>([]);
  const [classTeacherStudents, setClassTeacherStudents] = useState<ClassTeacherStudentData[]>([]);
  const [classNames, setClassNames] = useState<string[]>([]); // New state for class names
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedClassGroup, setSelectedClassGroup] = useState<ClassGroup | null>(null);
  const [editingClass, setEditingClass] = useState<ClassGroup | null>(null); // Changed type
  const [searchQuery, setSearchQuery] = useState('');
  
  // Form state for the enhanced class management
  const [selectedClass, setSelectedClass] = useState<string>(''); // Changed to string
  const [teacherName, setTeacherName] = useState<string>('');
  const [teacherPhone, setTeacherPhone] = useState<string>(''); // Teacher phone field
  const [formLevel, setFormLevel] = useState<string>('');
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  
  // Dropdown visibility state
  const [showClassDropdown, setShowClassDropdown] = useState(false);
  const [showFormLevelDropdown, setShowFormLevelDropdown] = useState(false);

  // Load classes, students, and relationships from Supabase on component mount
  useEffect(() => {
    loadAllData();
  }, []);

  // Set up real-time listener for student changes
  useEffect(() => {
    const channel = supabase
      .channel('student-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'students',
        },
        (payload: any) => {
          // A new student was added, refresh the student list
          loadStudents();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'students',
        },
        (payload: any) => {
          // A student was updated, refresh the student list
          loadStudents();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'students',
        },
        (payload: any) => {
          // A student was deleted, refresh the student list
          loadStudents();
        }
      )
      .subscribe();

    // Clean up the subscription
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const loadAllData = async () => {
    try {
      setLoading(true);
      await Promise.all([
        loadStudents(),
        loadClassTeacherStudents(),
        loadClassNames() // Load class names
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
      Alert.alert('Error', 'Failed to load data: ' + (error as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const loadStudents = async () => {
    try {
      const studentList = await getStudents();
      setStudents(studentList || []);
    } catch (error) {
      console.error('Error loading students:', error);
      throw error;
    }
  };

  const loadClassTeacherStudents = async () => {
    try {
      const relationships = await getClassTeacherStudents();
      console.log('Loaded class-teacher-student relationships:', relationships);
      setClassTeacherStudents(relationships || []);
    } catch (error) {
      console.error('Error loading class-teacher-student relationships:', error);
      throw error;
    }
  };

  const loadClassNames = async () => {
    try {
      const names = await getClassNames();
      setClassNames(names || []);
    } catch (error) {
      console.error('Error loading class names:', error);
      throw error;
    }
  };

  // Import the reset function
  const handleResetAttendance = async () => {
    Alert.alert(
      'Reset Attendance',
      'Are you sure you want to reset all attendance data to default (absent) for today? This will remove all current check-in/check-out data.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              // Dynamically import the reset function to avoid circular dependencies
              const { resetAttendanceToDefault } = await import('../../utils/attendanceSync');
              await resetAttendanceToDefault();
              Alert.alert('Success', 'Attendance data reset to default successfully');
              // Reload data to update UI
              await loadAllData();
            } catch (error) {
              console.error('Error resetting attendance:', error);
              Alert.alert('Error', 'Failed to reset attendance data: ' + (error as Error).message);
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  // Group relationships by class, teacher, and form level
  const groupedRelationships = classTeacherStudents.reduce((acc, relationship) => {
    const className = relationship.class_name;
    const teacherName = relationship.teacher_name;
    const teacherPhone = relationship.teacher_phone || '';
    const formLevel = relationship.form_level;
    
    const key = `${className}-${teacherName}-${formLevel}`;
    
    if (!acc[key]) {
      acc[key] = {
        className,
        teacherName,
        teacherPhone,
        formLevel,
        students: []
      };
    }
    
    // Add student information if available
    if (relationship.student) {
      acc[key].students.push({
        id: relationship.student_id,
        name: relationship.student.student_name,
        grade: relationship.student.grade,
        parentContact: relationship.student.parent_contact,
        email: relationship.student.email_student
      });
    }
    
    return acc;
  }, {} as Record<string, ClassGroup>);

  // Check if user is a parent
  const isParent = userRole === 'parent';

  // Filter classes based on search query
  const filteredClassGroups = Object.values(groupedRelationships).filter(group => 
    (group.className && group.className.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleDeleteClass = async (className: string, formLevel: string) => {
    Alert.alert(
      'Delete Class',
      `Are you sure you want to delete all relationships for class ${className} in ${formLevel}? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              // Delete from Supabase
              console.log('Attempting to delete class relationships for:', className, 'in form level:', formLevel);
              await deleteClassByName(className, formLevel); // Changed to delete by name and form level
              console.log('Successfully deleted class relationships from Supabase');
              
              // Update local state - only remove relationships for this specific class and form level
              setClassTeacherStudents(classTeacherStudents.filter(cts => 
                !(cts.class_name === className && cts.form_level === formLevel)
              ));
              
              Alert.alert('Success', 'Class relationships deleted successfully');
            } catch (error: any) {
              console.error('Error deleting class:', error);
              console.error('Supabase delete error:', error.message);
              
              // Provide more specific error messages
              let errorMessage = 'Failed to delete class';
              if (error?.message) {
                errorMessage = error.message;
              } else if (error?.code) {
                errorMessage += `: ${error.code}`;
              }
              
              Alert.alert('Error', errorMessage);
            }
          },
        },
      ]
    );
  };

  const handleSaveClassRelationship = async () => {
    // Updated validation - students are now optional
    if (!formLevel || !selectedClass || !teacherName) {
      Alert.alert('Error', 'Please fill in all required fields (Form Level, Class, and Teacher Name)');
      return;
    }

    try {
      console.log('Saving class relationships:', {
        selectedClass,
        teacherName,
        teacherPhone,
        formLevel,
        selectedStudents,
        editingClass
      });

      // If we're editing, we need to first delete existing relationships for this class-teacher-form combination
      if (editingClass) {
        // Find existing relationships for this class, teacher, and form level
        const relationshipsToDelete = classTeacherStudents.filter(
          cts => cts.class_name === editingClass.className && 
                 cts.teacher_name === editingClass.teacherName && 
                 cts.form_level === editingClass.formLevel
        );
        
        // Delete existing relationships
        const deletePromises = relationshipsToDelete.map(cts => 
          deleteClassTeacherStudent(cts.id)
        );
        
        await Promise.all(deletePromises);
        console.log('Deleted existing relationships:', relationshipsToDelete.length);
      }

      // Save class-teacher-student relationships to Supabase (only if students are selected)
      if (selectedStudents.length > 0) {
        const promises = selectedStudents.map(studentId => {
          const relationshipData: Omit<ClassTeacherStudent, 'id' | 'created_at' | 'updated_at'> = {
            class_name: selectedClass,  // Changed from class_id
            teacher_name: teacherName,
            form_level: formLevel,
            student_id: studentId,
          };
          
          // Only add teacher_phone if it's not empty (as per requirements, it's optional)
          if (teacherPhone && teacherPhone.trim() !== '') {
            relationshipData.teacher_phone = teacherPhone;
          }
          
          console.log('Creating relationship:', relationshipData);
          return addClassTeacherStudent(relationshipData);
        });
        
        const results = await Promise.all(promises);
        console.log('Save results:', results);
      } else {
        // If no students are selected, we still want to create a class-teacher relationship
        // We can do this by creating a relationship with a dummy student ID or by modifying the schema
        // For now, we'll just log that no students were selected
        console.log('No students selected for this class relationship');
      }

      // Refresh the relationships list
      await loadClassTeacherStudents();

      Alert.alert('Success', editingClass ? 'Class relationship updated successfully' : 'Class relationship saved successfully');
      
      // Reset form and close modal
      setEditingClass(null);
      setSelectedClass('');
      setTeacherName('');
      setTeacherPhone(''); // Reset phone field
      setFormLevel('');
      setSelectedStudents([]);
      setShowAddModal(false);
    } catch (error: any) {
      console.error('Error saving class relationships:', error);
      let errorMessage = 'Failed to save class relationships';
      if (error?.message) {
        errorMessage += `: ${error.message}`;
      }
      Alert.alert('Error', errorMessage);
    }
  };

  const toggleStudentSelection = (studentId: string) => {
    console.log('Toggling student selection:', studentId);
    console.log('Current selected students:', selectedStudents);
    
    if (selectedStudents.includes(studentId)) {
      const newSelected = selectedStudents.filter(id => id !== studentId);
      console.log('Removing student, new selection:', newSelected);
      setSelectedStudents(newSelected);
    } else {
      const newSelected = [...selectedStudents, studentId];
      console.log('Adding student, new selection:', newSelected);
      setSelectedStudents(newSelected);
    }
  };

  const handleClassPress = (classGroup: ClassGroup) => {
    setSelectedClassGroup(classGroup);
    setShowDetailModal(true);
  };

  const ClassCard = ({ 
    className, 
    teacherName, 
    teacherPhone,
    formLevel, 
    studentCount 
  }: { 
    className: string; 
    teacherName: string; 
    teacherPhone?: string;
    formLevel: string; 
    studentCount: number;
  }) => (
    <View style={[commonStyles.card, styles.classCard]}>
      <TouchableOpacity 
        style={styles.classCardTouchable}
        onPress={() => handleClassPress({
          className,
          teacherName,
          teacherPhone,
          formLevel,
          students: groupedRelationships[`${className}-${teacherName}-${formLevel}`]?.students || []
        })}
      >
        <View style={styles.classHeader}>
          <View style={styles.classInfo}>
            <Text style={styles.className}>{className}</Text>
            <Text style={styles.classTeacher}>{teacherName}</Text>
            <Text style={styles.classForm}>{formLevel}</Text>
          </View>
          <View style={styles.classStats}>
            <Text style={styles.studentCount}>{studentCount} students</Text>
          </View>
        </View>
      </TouchableOpacity>
      
      {/* Edit and Delete Buttons */}
      <View style={styles.actionButtonsContainer}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.editButton]}
          onPress={() => {
            // Pre-fill the form with existing data
            setEditingClass({
              className,
              teacherName,
              teacherPhone: teacherPhone || '',
              formLevel,
              students: groupedRelationships[`${className}-${teacherName}-${formLevel}`]?.students || []
            });
            setSelectedClass(className);
            setTeacherName(teacherName);
            setTeacherPhone(teacherPhone || '');
            setFormLevel(formLevel);
            // Get student IDs for this class relationship
            const classStudents = groupedRelationships[`${className}-${teacherName}-${formLevel}`]?.students || [];
            setSelectedStudents(classStudents.map(s => s.id));
            setShowAddModal(true);
          }}
        >
          <IconSymbol name="pencil" size={16} color={colors.card} />
          <Text style={styles.actionButtonText}>Edit</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => handleDeleteClass(className, formLevel)} // Pass both className and formLevel
        >
          <IconSymbol name="trash" size={16} color={colors.card} />
          <Text style={styles.actionButtonText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  // Prepare picker items - now using class names directly
  // Updated to use consistent naming pattern for all forms
  const getClassItemsByFormLevel = (formLevel: string) => {
    switch (formLevel) {
      case 'Form 1':
        return [
          { label: '1SC', value: '1SC' },
          { label: '1AC', value: '1AC' },
          { label: '1CC', value: '1CC' }
        ];
      case 'Form 2':
        return [
          { label: '2SC', value: '2SC' },
          { label: '2AC', value: '2AC' },
          { label: '2CC', value: '2CC' }
        ];
      case 'Form 3':
        return [
          { label: '3A2', value: '3A2' },
          { label: '3A4', value: '3A4' },
          { label: '3A5', value: '3A5' }
        ];
      case 'Form 4':
        return [
          { label: '4SC', value: '4SC' },
          { label: '4AC', value: '4AC' },
          { label: '4CC', value: '4CC' }
        ];
      case 'Form 5':
        return [
          { label: '5SC', value: '5SC' },
          { label: '5AC', value: '5AC' },
          { label: '5CC', value: '5CC' }
        ];
      default:
        // For other forms, use the existing class names from database or default options
        if (classNames.length > 0) {
          return classNames.map(className => ({
            label: className,
            value: className
          }));
        } else {
          return [
            { label: '1SC', value: '1SC' },
            { label: '1AC', value: '1AC' },
            { label: '1CC', value: '1CC' }
          ];
        }
    }
  };

  // Get class items based on selected form level
  const classItems = formLevel ? getClassItemsByFormLevel(formLevel) : [];

  const formLevelItems = [
    { label: 'Form 1', value: 'Form 1' },
    { label: 'Form 2', value: 'Form 2' },
    { label: 'Form 3', value: 'Form 3' },
    { label: 'Form 4', value: 'Form 4' },
    { label: 'Form 5', value: 'Form 5' },
  ];

  // Filter students by selected form level and class assignment from Student Management
  // Only show students that match the form level AND have been assigned to the selected class
  const filteredStudentsByForm = formLevel && selectedClass
    ? students.filter(student => 
        student.grade === formLevel && 
        student.class_name === selectedClass
      )
    : formLevel 
    ? students.filter(student => student.grade === formLevel)
    : students;

  // Add state for attendance data
  const [attendanceData, setAttendanceData] = useState<any[]>([]);
  const [loadingAttendance, setLoadingAttendance] = useState(false);

  // Function to load attendance data for the selected class
  const loadClassAttendance = async (className: string) => {
    if (!className) return;
    
    try {
      setLoadingAttendance(true);
      // Dynamically import to avoid circular dependencies
      const { getAttendanceByClassName } = await import('../../utils/attendanceOperations');
      const data = await getAttendanceByClassName(className);
      setAttendanceData(data || []);
      console.log(`Loaded ${data?.length || 0} attendance records for class ${className}`);
    } catch (error) {
      console.error('Error loading class attendance:', error);
      setAttendanceData([]);
    } finally {
      setLoadingAttendance(false);
    }
  };

  // Function to reset attendance to default for the selected class
  const resetClassAttendanceToDefault = async (className: string) => {
    Alert.alert(
      'Reset Attendance',
      `Are you sure you want to reset all attendance data to default (absent) for class ${className}? This will remove all current check-in/check-out data for today.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoadingAttendance(true);
              // Dynamically import the reset function
              const { resetAttendanceToDefault } = await import('../../utils/attendanceSync');
              await resetAttendanceToDefault();
              // Reload attendance data
              await loadClassAttendance(className);
              Alert.alert('Success', 'Attendance data reset to default successfully');
            } catch (error) {
              console.error('Error resetting class attendance:', error);
              Alert.alert('Error', 'Failed to reset attendance data: ' + (error as Error).message);
            } finally {
              setLoadingAttendance(false);
            }
          },
        },
      ]
    );
  };

  // Update the useEffect to load attendance when a class is selected
  useEffect(() => {
    if (selectedClassGroup) {
      loadClassAttendance(selectedClassGroup.className);
    }
  }, [selectedClassGroup]);

  // Add a function to refresh attendance data
  const refreshClassAttendance = async (className: string) => {
    if (!className) return;
    
    try {
      setLoadingAttendance(true);
      // Dynamically import to avoid circular dependencies
      const { getAttendanceByClassName } = await import('../../utils/attendanceOperations');
      const data = await getAttendanceByClassName(className);
      setAttendanceData(data || []);
      console.log(`Refreshed ${data?.length || 0} attendance records for class ${className}`);
    } catch (error) {
      console.error('Error refreshing class attendance:', error);
      setAttendanceData([]);
    } finally {
      setLoadingAttendance(false);
    }
  };

  // Add a useEffect to periodically refresh attendance data
  useEffect(() => {
    let intervalId: ReturnType<typeof setInterval> | null = null;
    
    if (selectedClassGroup) {
      // Refresh attendance data every 30 seconds
      intervalId = setInterval(() => {
        refreshClassAttendance(selectedClassGroup.className);
      }, 30000);
    }
    
    // Clean up interval on unmount or when class changes
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [selectedClassGroup]);

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={commonStyles.title}>Class Management</Text>
          <View style={{ flexDirection: 'row' }}>
            {/* Hide add button for parents */}
            {!isParent && (
              <TouchableOpacity
                style={styles.addButton}
                onPress={() => {
                  setEditingClass(null);
                  setSelectedClass('');
                  setTeacherName('');
                  setTeacherPhone(''); // Reset teacher phone field
                  setFormLevel('');
                  setSelectedStudents([]);
                  setShowAddModal(true);
                  // Close dropdowns when opening modal
                  setShowClassDropdown(false);
                  setShowFormLevelDropdown(false);
                }}
              >
                <IconSymbol name="plus" size={20} color={colors.card} />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <IconSymbol name="magnifyingglass" size={20} color={colors.textSecondary} />
            <TextInput
              style={[styles.searchInput, { marginLeft: spacing.sm }]}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search classes..."
              placeholderTextColor={colors.textSecondary}
            />
          </View>
        </View>

        {/* Classes List */}
        <ScrollView
          style={styles.content}
          contentContainerStyle={commonStyles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {loading ? (
            <View style={styles.loadingContainer}>
              <Text>Loading classes...</Text>
            </View>
          ) : (
            <>
              {filteredClassGroups.map((group, index) => (
                <ClassCard
                  key={index}
                  className={group.className}
                  teacherName={group.teacherName}
                  teacherPhone={group.teacherPhone}
                  formLevel={group.formLevel}
                  studentCount={group.students.length}
                />
              ))}
              
              {filteredClassGroups.length === 0 && (
                <View style={styles.emptyState}>
                  <IconSymbol name="book" size={48} color={colors.textSecondary} />
                  <Text style={styles.emptyText}>No class relationships found</Text>
                  <Text style={styles.emptySubtext}>
                    {searchQuery
                      ? 'Try adjusting your search'
                      : 'Add your first class relationship to get started'}
                  </Text>
                </View>
              )}
            </>
          )}
        </ScrollView>

        {/* Add Class Modal */}
        <Modal
          visible={showAddModal}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={() => setShowAddModal(false)}
        >
          <SafeAreaView style={commonStyles.safeArea}>
            <View style={[commonStyles.container, { flex: 1 }]}>
              {/* Modal Header */}
              <View style={styles.modalHeader}>
                <TouchableOpacity onPress={() => setShowAddModal(false)}>
                  <Text style={styles.cancelButton}>Cancel</Text>
                </TouchableOpacity>
                <Text style={commonStyles.title}>
                  {editingClass ? 'Edit Class Relationship' : 'Add Class Relationship'}
                </Text>
                <TouchableOpacity onPress={handleSaveClassRelationship}>
                  <Text style={styles.saveButton}>Save</Text>
                </TouchableOpacity>
              </View>

              {/* Modal Content */}
              <View style={{ flex: 1 }}>
                {editingClass ? (
                  // Edit mode - only show class information as read-only
                  <View style={{ flex: 1 }}>
                    <ScrollView
                      contentContainerStyle={styles.modalContent}
                      showsVerticalScrollIndicator={true}
                      keyboardShouldPersistTaps="handled"
                      bounces={true}
                      bouncesZoom={true}
                      alwaysBounceVertical={true}
                      scrollEventThrottle={16}
                      style={{ flex: 1 }}
                    >
                      <View style={styles.formGroup}>
                        <Text style={styles.label}>Form/Class Level</Text>
                        <View style={[commonStyles.input, { backgroundColor: colors.card }]}> 
                          <Text style={styles.pickerText}>{formLevel}</Text>
                        </View>
                      </View>

                      <View style={styles.formGroup}>
                        <Text style={styles.label}>Class</Text>
                        <View style={[commonStyles.input, { backgroundColor: colors.card }]}> 
                          <Text style={styles.pickerText}>{selectedClass}</Text>
                        </View>
                      </View>

                      <View style={styles.formGroup}>
                        <Text style={styles.label}>Teacher Name</Text>
                        <View style={[commonStyles.input, { backgroundColor: colors.card }]}> 
                          <Text style={styles.pickerText}>{teacherName}</Text>
                        </View>
                      </View>

                      {teacherPhone ? (
                        <View style={styles.formGroup}>
                          <Text style={styles.label}>Teacher Phone Number</Text>
                          <View style={[commonStyles.input, { backgroundColor: colors.card }]}> 
                            <Text style={styles.pickerText}>{teacherPhone}</Text>
                          </View>
                        </View>
                      ) : null}
                      
                      {/* Student Selection Section for Edit Mode */}
                      <View style={[styles.formGroup, { flex: 1, marginBottom: 0, marginTop: 0 }]}>
                        <Text style={styles.label}>Select Students ({selectedStudents.length} selected)</Text>
                        <View style={[styles.studentSelectionContainer, { flex: 1 }]}>
                          <FlatList
                            data={filteredStudentsByForm}
                            keyExtractor={(item) => item.student_id}
                            renderItem={({ item }) => {
                              // Check if this student is already assigned to the selected class and form level
                              const isAlreadyAssigned = classTeacherStudents.some(cts => 
                                cts.student_id === item.student_id && 
                                cts.class_name === selectedClass && 
                                cts.form_level === formLevel
                              );
                              
                              // Pre-select students that are already assigned to this class
                              const isSelected = selectedStudents.includes(item.student_id) || isAlreadyAssigned;
                              
                              return (
                                <TouchableOpacity
                                  style={[
                                    styles.studentSelectionItem,
                                    isSelected && styles.selectedStudent
                                  ]}
                                  onPress={() => {
                                    console.log('Student item pressed:', item.student_id);
                                    toggleStudentSelection(item.student_id);
                                  }}
                                >
                                  <View style={styles.studentSelectionInfo}>
                                    <Text style={styles.studentSelectionName}>{item.student_name}</Text>
                                    <Text style={styles.studentSelectionGrade}>{item.grade}</Text>
                                    {item.parent_contact && (
                                      <Text style={styles.studentSelectionDetail}>
                                        <IconSymbol name="phone" size={12} color={colors.textSecondary} />
                                        {item.parent_contact}
                                      </Text>
                                    )}
                                  </View>
                                  {isSelected && (
                                    <IconSymbol name="checkmark" size={20} color={colors.primary} />
                                  )}
                                </TouchableOpacity>
                              );
                            }}
                            scrollEnabled={true}
                            showsVerticalScrollIndicator={true}
                            nestedScrollEnabled={true}
                            keyboardShouldPersistTaps="handled"
                            style={{ flex: 1 }}
                            bounces={true}
                            bouncesZoom={true}
                            alwaysBounceVertical={true}
                            contentContainerStyle={{ flexGrow: 1 }}
                            windowSize={5}
                            maxToRenderPerBatch={10}
                            updateCellsBatchingPeriod={50}
                            initialNumToRender={10}
                            removeClippedSubviews={true}
                          />
                        </View>
                      </View>
                    </ScrollView>
                  </View>
                ) : (
                  // Add mode - show all form fields and student selection
                  <View style={{ flex: 1 }}>
                    <ScrollView
                      contentContainerStyle={styles.modalContent}
                      showsVerticalScrollIndicator={true}
                      keyboardShouldPersistTaps="handled"
                      bounces={true}
                      bouncesZoom={true}
                      alwaysBounceVertical={true}
                      scrollEventThrottle={16}
                      style={{ flex: 1 }}
                    >
                      <View style={styles.formGroup}>
                        <Text style={styles.label}>Form/Class Level *</Text>
                        <View style={commonStyles.input}>
                          <TouchableOpacity
                            style={styles.pickerContainer}
                            onPress={() => {
                              setShowFormLevelDropdown(!showFormLevelDropdown);
                              setShowClassDropdown(false); // Close other dropdowns
                            }}
                          >
                            <Text style={styles.pickerText}>
                              {formLevel || 'Select form level'}
                            </Text>
                            <IconSymbol name="chevron.down" size={16} color={colors.textSecondary} />
                          </TouchableOpacity>
                        </View>
                        
                        {/* Form level selection options - only show when dropdown is open */}
                        {showFormLevelDropdown && (
                          <View style={styles.pickerDropdown}>
                            {formLevelItems.map((item) => (
                              <TouchableOpacity
                                key={item.value}
                                style={[
                                  styles.pickerItem,
                                  formLevel === item.value && styles.selectedPickerItem
                                ]}
                                onPress={() => {
                                  console.log('Selected form level:', item);
                                  setFormLevel(item.value);
                                  setShowFormLevelDropdown(false); // Close dropdown after selection
                                  // Reset class selection when form level changes
                                  setSelectedClass('');
                                  // Clear selected students when form level changes
                                  setSelectedStudents([]);
                                }}
                              >
                                <Text style={[
                                  styles.pickerItemText,
                                  formLevel === item.value && styles.selectedPickerItemText
                                ]}>
                                  {item.label}
                                </Text>
                              </TouchableOpacity>
                            ))}
                          </View>
                        )}
                      </View>

                      <View style={styles.formGroup}>
                        <Text style={styles.label}>Select Class *</Text>
                        <View style={commonStyles.input}>
                          <TouchableOpacity
                            style={styles.pickerContainer}
                            onPress={() => {
                              // Only show class dropdown if form level is selected
                              if (formLevel) {
                                setShowClassDropdown(!showClassDropdown);
                                setShowFormLevelDropdown(false); // Close other dropdowns
                              } else {
                                Alert.alert('Form Level Required', 'Please select a form level first');
                              }
                            }}
                            disabled={!formLevel} // Disable if form level is not selected
                          >
                            <Text style={[styles.pickerText, !formLevel && { color: colors.textSecondary }]}> 
                              {selectedClass || 'Select a class'}
                            </Text>
                            <IconSymbol name="chevron.down" size={16} color={colors.textSecondary} />
                          </TouchableOpacity>
                        </View>
                        
                        {/* Class selection options - only show when dropdown is open and form level is selected */}
                        {showClassDropdown && formLevel && (
                          <View style={styles.pickerDropdown}>
                            {classItems.map((item) => (
                              <TouchableOpacity
                                key={item.value}
                                style={[
                                  styles.pickerItem,
                                  selectedClass === item.value && styles.selectedPickerItem
                                ]}
                                onPress={() => {
                                  console.log('Selected class:', item);
                                  setSelectedClass(item.value);
                                  setShowClassDropdown(false); // Close dropdown after selection
                                  
                                  // When a class is selected, pre-select students already in this class
                                  const studentsInClass = classTeacherStudents
                                    .filter(cts => cts.class_name === item.value && cts.form_level === formLevel)
                                    .map(cts => cts.student_id);
                                  
                                  setSelectedStudents(studentsInClass);
                                }}
                              >
                                <Text style={[
                                  styles.pickerItemText,
                                  selectedClass === item.value && styles.selectedPickerItemText
                                ]}>
                                  {item.label}
                                </Text>
                              </TouchableOpacity>
                            ))}
                          </View>
                        )}
                      </View>

                      <View style={styles.formGroup}>
                        <Text style={styles.label}>Teacher Name *</Text>
                        <TextInput
                          style={commonStyles.input}
                          value={teacherName}
                          onChangeText={setTeacherName}
                          placeholder="Enter teacher's name"
                          placeholderTextColor={colors.textSecondary}
                        />
                      </View>

                      <View style={styles.formGroup}>
                        <Text style={styles.label}>Teacher Phone Number</Text>
                        <TextInput
                          style={commonStyles.input}
                          value={teacherPhone}
                          onChangeText={setTeacherPhone}
                          placeholder="Enter teacher's phone number"
                          placeholderTextColor={colors.textSecondary}
                          keyboardType="phone-pad"
                        />
                      </View>
                      
                      {/* Student Selection Section - Only one scroll for the entire list */}
                      <View style={[styles.formGroup, { flex: 1, marginBottom: 0, marginTop: 0 }]}>
                        <Text style={styles.label}>Select Students ({selectedStudents.length} selected)</Text>
                        <View style={[styles.studentSelectionContainer, { flex: 1 }]}>
                          <FlatList
                            data={filteredStudentsByForm}
                            keyExtractor={(item) => item.student_id}
                            renderItem={({ item }) => {
                              // Check if this student is already assigned to the selected class and form level
                              const isAlreadyAssigned = classTeacherStudents.some(cts => 
                                cts.student_id === item.student_id && 
                                cts.class_name === selectedClass && 
                                cts.form_level === formLevel
                              );
                              
                              // Pre-select students that are already assigned to this class
                              const isSelected = selectedStudents.includes(item.student_id) || isAlreadyAssigned;
                              
                              return (
                                <TouchableOpacity
                                  style={[
                                    styles.studentSelectionItem,
                                    isSelected && styles.selectedStudent
                                  ]}
                                  onPress={() => {
                                    console.log('Student item pressed:', item.student_id);
                                    toggleStudentSelection(item.student_id);
                                  }}
                                >
                                  <View style={styles.studentSelectionInfo}>
                                    <Text style={styles.studentSelectionName}>{item.student_name}</Text>
                                    <Text style={styles.studentSelectionGrade}>{item.grade}</Text>
                                    {item.parent_contact && (
                                      <Text style={styles.studentSelectionDetail}>
                                        <IconSymbol name="phone" size={12} color={colors.textSecondary} />
                                        {item.parent_contact}
                                      </Text>
                                    )}
                                  </View>
                                  {isSelected && (
                                    <IconSymbol name="checkmark" size={20} color={colors.primary} />
                                  )}
                                </TouchableOpacity>
                              );
                            }}
                            scrollEnabled={true}
                            showsVerticalScrollIndicator={true}
                            nestedScrollEnabled={true}
                            keyboardShouldPersistTaps="handled"
                            style={{ flex: 1 }}
                            bounces={true}
                            bouncesZoom={true}
                            alwaysBounceVertical={true}
                            contentContainerStyle={{ flexGrow: 1 }}
                            windowSize={5}
                            maxToRenderPerBatch={10}
                            updateCellsBatchingPeriod={50}
                            initialNumToRender={10}
                            removeClippedSubviews={true}
                          />
                        </View>
                      </View>
                    </ScrollView>
                  </View>
                )}
              </View>
            </View>
          </SafeAreaView>
        </Modal>

        {/* Class Detail Modal */}
        <Modal
          visible={showDetailModal}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={() => setShowDetailModal(false)}
        >
          <SafeAreaView style={commonStyles.safeArea}>
            <View style={commonStyles.container}>
              {/* Modal Header */}
              <View style={styles.modalHeader}>
                <TouchableOpacity onPress={() => setShowDetailModal(false)}>
                  <Text style={styles.cancelButton}>Close</Text>
                </TouchableOpacity>
                <Text style={commonStyles.title}>Class Details</Text>
                <View style={{ width: 60 }} /> {/* Spacer for alignment */}
              </View>

              {/* Modal Content */}
              {selectedClassGroup && (
                <ScrollView
                  style={commonStyles.container}
                  contentContainerStyle={styles.modalContent}
                  showsVerticalScrollIndicator={false}
                >
                  {/* Class Information */}
                  <View style={[commonStyles.card, styles.detailCard]}>
                    <Text style={styles.detailTitle}>{selectedClassGroup.className}</Text>
                    <View style={styles.detailRow}>
                      <IconSymbol name="person" size={16} color={colors.textSecondary} />
                      <Text style={styles.detailText}>{selectedClassGroup.teacherName}</Text>
                    </View>
                    {selectedClassGroup.teacherPhone && (
                      <View style={styles.detailRow}>
                        <IconSymbol name="phone" size={16} color={colors.textSecondary} />
                        <Text style={styles.detailText}>{selectedClassGroup.teacherPhone}</Text>
                      </View>
                    )}
                    <View style={styles.detailRow}>
                      <IconSymbol name="book" size={16} color={colors.textSecondary} />
                      <Text style={styles.detailText}>{selectedClassGroup.formLevel}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <IconSymbol name="person.3" size={16} color={colors.textSecondary} />
                      <Text style={styles.detailText}>{selectedClassGroup.students.length} Students</Text>
                    </View>
                  </View>

                  {/* Students List */}
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.md }}>
                    <Text style={styles.sectionTitle}>Students in this class</Text>
                    {loadingAttendance && (
                      <Text style={[styles.sectionTitle, { fontSize: typography.sizes.sm, color: colors.textSecondary }]}>
                        Loading...
                      </Text>
                    )}
                  </View>
                  {selectedClassGroup.students.length > 0 ? (
                    selectedClassGroup.students.map((student, index) => {
                      // Find attendance record for this student
                      const attendanceRecord = attendanceData.find(
                        record => record.student_id === student.id
                      );
                      
                      // Determine attendance status
                      let attendanceStatus = 'absent'; // Default to absent
                      let attendanceColor = colors.error;
                      
                      if (attendanceRecord) {
                        attendanceStatus = attendanceRecord.status || 'absent';
                        switch (attendanceStatus) {
                          case 'present':
                            attendanceColor = colors.success;
                            break;
                          case 'late':
                            attendanceColor = colors.warning;
                            break;
                          case 'absent':
                          default:
                            attendanceColor = colors.error;
                            attendanceStatus = 'absent';
                            break;
                        }
                      }
                      
                      return (
                        <View key={student.id} style={[commonStyles.card, styles.studentCard]}>
                          <View style={styles.studentHeader}>
                            <View style={styles.studentPhoto}>
                              <IconSymbol name="person.fill" size={24} color={colors.textSecondary} />
                            </View>
                            <View style={styles.studentInfo}>
                              <Text style={styles.studentName}>{student.name}</Text>
                              <Text style={styles.studentGrade}>{student.grade}</Text>
                              {student.parentContact && (
                                <View style={styles.detailRow}>
                                  <IconSymbol name="phone" size={14} color={colors.textSecondary} />
                                  <Text style={styles.detailText}>{student.parentContact}</Text>
                                </View>
                              )}
                              {student.email && (
                                <View style={styles.detailRow}>
                                  <IconSymbol name="envelope" size={14} color={colors.textSecondary} />
                                  <Text style={styles.detailText}>{student.email}</Text>
                                </View>
                              )}
                            </View>
                            <View style={[styles.attendanceBadge, { backgroundColor: attendanceColor }]}>
                              <Text style={styles.attendanceBadgeText}>
                                {attendanceStatus.charAt(0).toUpperCase() + attendanceStatus.slice(1)}
                              </Text>
                            </View>
                          </View>
                        </View>
                      );
                    })
                  ) : (
                    <View style={[commonStyles.card, styles.emptyCard]}>
                      <Text style={styles.emptyText}>No students assigned to this class</Text>
                    </View>
                  )}
                </ScrollView>
              )}
            </View>
          </SafeAreaView>
        </Modal>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  addButton: {
    backgroundColor: colors.primary,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.sm,
  },

  searchContainer: {
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },

  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: spacing.md,
    borderRadius: 12,
    ...shadows.sm,
  },

  searchInput: {
    flex: 1,
    paddingVertical: spacing.sm,
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },

  classCard: {
    marginBottom: spacing.md,
  },

  classHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  classInfo: {
    flex: 1,
  },

  className: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  classTeacher: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },

  classForm: {
    fontSize: typography.sizes.sm,
    color: colors.primary,
    fontWeight: typography.weights.medium,
  },

  classStats: {
    alignItems: 'flex-end',
  },

  studentCount: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    backgroundColor: colors.primary + '20',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 12,
  },

  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.sm, // Reduced from spacing.md for better mobile fit
    paddingVertical: spacing.xs, // Reduced from spacing.sm for better mobile fit
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  cancelButton: {
    fontSize: typography.sizes.sm, // Reduced from typography.sizes.md for better mobile fit
    color: colors.textSecondary,
  },

  saveButton: {
    fontSize: typography.sizes.sm, // Reduced from typography.sizes.md for better mobile fit
    fontWeight: typography.weights.semibold,
    color: colors.primary,
  },

  modalContent: {
    padding: spacing.sm,
    paddingBottom: spacing.sm,
    flexGrow: 1,
  },

  formGroup: {
    marginBottom: 0, // Removed margin to eliminate extra space
  },

  label: {
    fontSize: typography.sizes.xs,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.xs,
    marginTop: spacing.xs, // Add small top margin
  },

  pickerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.sm,
  },

  pickerText: {
    fontSize: typography.sizes.sm, // Reduced from typography.sizes.md for better mobile fit
    color: colors.text,
  },

  pickerDropdown: {
    maxHeight: 150, // Reduced from 200 for better mobile fit
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    marginTop: spacing.xs,
    ...shadows.sm,
  },

  pickerItem: {
    padding: spacing.xs, // Reduced from spacing.sm for better mobile fit
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  selectedPickerItem: {
    backgroundColor: colors.primary + '10',
  },

  pickerItemText: {
    fontSize: typography.sizes.sm, // Reduced from typography.sizes.md for better mobile fit
    color: colors.text,
  },

  selectedPickerItemText: {
    color: colors.primary,
    fontWeight: typography.weights.semibold,
  },

  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl,
  },

  emptyText: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginTop: spacing.md,
    marginBottom: spacing.xs,
  },

  emptySubtext: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
  },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.xxl,
  },

  studentSelectionContainer: {
    maxHeight: 300,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    flex: 1,
    marginTop: spacing.xs,
  },

  studentSelectionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.xs, // Reduced from spacing.sm for better mobile fit
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  selectedStudent: {
    backgroundColor: colors.primary + '10',
  },

  studentSelectionInfo: {
    flex: 1,
  },

  studentSelectionName: {
    fontSize: typography.sizes.sm, // Reduced from typography.sizes.md for better mobile fit
    color: colors.text,
  },

  studentSelectionGrade: {
    fontSize: typography.sizes.xs, // Reduced from typography.sizes.sm for better mobile fit
    color: colors.textSecondary,
  },

  studentSelectionDetail: {
    fontSize: typography.sizes.xs, // Keep as is for mobile fit
    color: colors.textSecondary,
    marginTop: spacing.xs,
    flexDirection: 'row',
    alignItems: 'center',
  },

  detailCard: {
    marginBottom: spacing.md,
  },

  detailTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.md,
  },

  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.xs,
  },

  detailText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginLeft: spacing.xs,
  },

  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
  },

  studentCard: {
    marginBottom: spacing.sm,
  },

  studentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  studentPhoto: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },

  studentInfo: {
    flex: 1,
  },

  studentName: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  studentGrade: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },

  attendanceBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 12,
    minWidth: 70,
    alignItems: 'center',
  },

  attendanceBadgeText: {
    fontSize: typography.sizes.xs,
    fontWeight: typography.weights.bold,
    color: colors.card,
  },

  emptyCard: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },

  classCardTouchable: {
    // Use the same styles as the previous TouchableOpacity
  },

  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: spacing.sm,
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },

  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    borderRadius: 8,
    marginHorizontal: spacing.xs,
  },

  editButton: {
    backgroundColor: colors.primary,
  },

  deleteButton: {
    backgroundColor: colors.error,
  },

  actionButtonText: {
    color: colors.card,
    fontWeight: typography.weights.semibold,
    marginLeft: spacing.xs,
  },
  
  helperText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    fontStyle: 'italic',
  },
});

export default ClassesScreen;
