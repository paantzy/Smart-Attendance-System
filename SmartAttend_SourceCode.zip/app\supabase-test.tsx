import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { supabase } from '../utils/supabase';

export default function SupabaseTest() {
  const [connectionStatus, setConnectionStatus] = useState('Checking...');
  const [tableStatus, setTableStatus] = useState('Checking...');
  const [authStatus, setAuthStatus] = useState('Checking...');
  const [testStudentStatus, setTestStudentStatus] = useState('Not run');

  const testConnection = async () => {
    try {
      // Test basic connection
      setConnectionStatus('Testing...');
      
      // Test if we can query the students table
      setTableStatus('Testing...');
      const { data, error } = await supabase
        .from('students')
        .select('count')
        .limit(1);
      
      if (error) {
        setTableStatus(`Error: ${error.message}`);
      } else {
        setTableStatus(`Success: ${data[0].count} records found`);
      }
      
      // Test authentication status
      setAuthStatus('Testing...');
      const { data: { session }, error: authError } = await supabase.auth.getSession();
      
      if (authError) {
        setAuthStatus(`Error: ${authError.message}`);
      } else {
        setAuthStatus(session ? `Authenticated: ${session.user?.id}` : 'Not authenticated');
      }
      
      setConnectionStatus('Connected successfully');
    } catch (error: any) {
      console.error('Connection test error:', error);
      setConnectionStatus(`Error: ${error.message}`);
    }
  };

  const testStudentOperations = async () => {
    try {
      setTestStudentStatus('Testing...');
      
      // Try to insert a test student directly using supabase client
      const { data, error } = await supabase
        .from('students')
        .insert([
          {
            student_name: 'Test Student',
            grade: 'Form 1',
            class: 'Alamanda',
            parent_contact: '+60123456789',
            email_student: 'test@example.com'
          }
        ])
        .select();
      
      if (error) {
        setTestStudentStatus(`Insert Error: ${error.message}`);
        return;
      }
      
      const insertedId = data[0].id;
      setTestStudentStatus(`Insert Success: ${insertedId}`);
      
      // Try to get all students
      const { data: studentsData, error: studentsError } = await supabase
        .from('students')
        .select('*');
      
      if (studentsError) {
        console.log(`Get students Error: ${studentsError.message}`);
      } else {
        console.log(`Found ${studentsData.length} students`);
      }
      
      // Try to delete the test student
      const { error: deleteError } = await supabase
        .from('students')
        .delete()
        .eq('id', insertedId);
      
      if (deleteError) {
        console.log(`Delete Error: ${deleteError.message}`);
      } else {
        console.log('Delete Success');
      }
    } catch (error: any) {
      console.error('Student operations test error:', error);
      setTestStudentStatus(`Error: ${error.message}`);
    }
  };

  useEffect(() => {
    testConnection();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Supabase Connection Test</Text>
      
      <View style={styles.statusContainer}>
        <Text style={styles.statusLabel}>Connection Status:</Text>
        <Text style={styles.statusValue}>{connectionStatus}</Text>
      </View>
      
      <View style={styles.statusContainer}>
        <Text style={styles.statusLabel}>Students Table Status:</Text>
        <Text style={styles.statusValue}>{tableStatus}</Text>
      </View>
      
      <View style={styles.statusContainer}>
        <Text style={styles.statusLabel}>Auth Status:</Text>
        <Text style={styles.statusValue}>{authStatus}</Text>
      </View>
      
      <View style={styles.statusContainer}>
        <Text style={styles.statusLabel}>Test Student Operations:</Text>
        <Text style={styles.statusValue}>{testStudentStatus}</Text>
      </View>
      
      <TouchableOpacity style={styles.button} onPress={testConnection}>
        <Text style={styles.buttonText}>Test Connection</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={[styles.button, styles.secondaryButton]} onPress={testStudentOperations}>
        <Text style={[styles.buttonText, styles.secondaryButtonText]}>Test Student Operations</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: '#333',
  },
  statusContainer: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    elevation: 2,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  statusLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 5,
  },
  statusValue: {
    fontSize: 14,
    color: '#666',
  },
  button: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  secondaryButton: {
    backgroundColor: '#f0f0f0',
  },
  secondaryButtonText: {
    color: '#333',
  },
});