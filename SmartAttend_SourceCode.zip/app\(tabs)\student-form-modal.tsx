import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';

interface StudentFormData {
  name: string;
  grade: string;
  class: string;  // Added back: class field for student assignment (optional)
  parentContact: string;
  email: string;
}

interface StudentFormModalProps {
  visible: boolean;
  editingStudent: any;
  initialFormData: StudentFormData;
  onClose: () => void;
  onSave: (formData: StudentFormData) => void;
  onFormChange: (formData: StudentFormData) => void; // Add this line
}

export default function StudentFormModal({
  visible,
  editingStudent,
  initialFormData,
  onClose,
  onSave,
  onFormChange,
}: StudentFormModalProps) {
  const [formData, setFormData] = useState<StudentFormData>(initialFormData);
  const [showGradeDropdown, setShowGradeDropdown] = useState(false);

  // Grade options
  const gradeOptions = ['Form 1', 'Form 2', 'Form 3', 'Form 4', 'Form 5'];
  
  // Class options by form level - these must exist in Class Management
  const classOptions: Record<string, string[]> = {
    'Form 1': ['1SC', '1AC', '1CC'],
    'Form 2': ['2SC', '2AC', '2CC'],
    'Form 3': ['3SC', '3AC', '3CC'],
    'Form 4': ['4SC', '4AC', '4CC'],
    'Form 5': ['5SC', '5AC', '5CC']
  };
  
  // Reset form data when initialFormData changes
  useEffect(() => {
    setFormData(initialFormData);
  }, [initialFormData]);

  const handleFormChange = useCallback((field: keyof StudentFormData, value: string) => {
    const newFormData = {
      ...formData,
      [field]: value
    };
    setFormData(newFormData);
    onFormChange(newFormData); // Notify parent of changes
  }, [formData, onFormChange]);

  const handleSave = useCallback(async () => {
    // Trim whitespace from all fields
    const trimmedData = {
      name: formData.name.trim(),
      grade: formData.grade.trim(),
      class: formData.class.trim(),
      parentContact: formData.parentContact.trim(),
      email: formData.email.trim()
    };
    
    // Debugging: Log the form data to see what's actually in each field
    console.log('Form Data Debug:', {
      original: formData,
      trimmed: trimmedData,
      nameEmpty: !trimmedData.name,
      gradeEmpty: !trimmedData.grade,
      parentContactEmpty: !trimmedData.parentContact,
      emailEmpty: !trimmedData.email
    });
    
    // Validation - class is optional, others are required
    if (!trimmedData.name) {
      Alert.alert('Error', 'Student name is required');
      return;
    }
    
    if (!trimmedData.grade) {
      Alert.alert('Error', 'Form level is required');
      return;
    }
    
    if (!trimmedData.parentContact) {
      Alert.alert('Error', 'Parent contact is required');
      return;
    }
    
    if (!trimmedData.email) {
      Alert.alert('Error', 'Student email is required');
      return;
    }

    // Pass the trimmed data to onSave
    onSave(trimmedData);
  }, [formData, onSave]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView 
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 80}
      >
        <SafeAreaView style={commonStyles.safeArea}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={onClose}>
              <Text style={styles.cancelButton}>Cancel</Text>
            </TouchableOpacity>
            <Text style={commonStyles.subtitle}>
              {editingStudent ? 'Edit Student' : 'Add New Student'}
            </Text>
            <TouchableOpacity onPress={handleSave}>
              <Text style={styles.saveButton}>Save</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={commonStyles.content}>
            <View style={styles.formGroup}>
              <Text style={styles.label}>Student Name *</Text>
              <TextInput
                style={commonStyles.input}
                value={formData.name}
                onChangeText={(text) => handleFormChange('name', text)}
                placeholder="Enter student name"
                placeholderTextColor={colors.textSecondary}
                autoComplete="off"
                autoCorrect={false}
                spellCheck={false}
                autoCapitalize="words"
                textContentType="none"
                keyboardType="default"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Student Email *</Text>
              <TextInput
                style={commonStyles.input}
                value={formData.email}
                onChangeText={(text) => handleFormChange('email', text)}
                placeholder="Enter student email"
                placeholderTextColor={colors.textSecondary}
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="off"
                autoCorrect={false}
                spellCheck={false}
                textContentType="none"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Form Level *</Text>
              <TouchableOpacity 
                style={commonStyles.input}
                onPress={() => setShowGradeDropdown(!showGradeDropdown)}
              >
                <View style={styles.dropdownContainer}>
                  <Text style={[styles.dropdownText, !formData.grade && styles.placeholderText]}>
                    {formData.grade || 'Select Form Level'}
                  </Text>
                  <IconSymbol name="chevron.down" size={16} color={colors.textSecondary} />
                </View>
              </TouchableOpacity>
              
              {showGradeDropdown && (
                <View style={styles.dropdownOptions}>
                  {gradeOptions.map((grade) => (
                    <TouchableOpacity
                      key={grade}
                      style={styles.dropdownOption}
                      onPress={() => {
                        handleFormChange('grade', grade);
                        setShowGradeDropdown(false);
                      }}
                    >
                      <Text style={[
                        styles.dropdownOptionText,
                        formData.grade === grade && styles.selectedOption
                      ]}>
                        {grade}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Class (Optional)</Text>
              {/* Class selection - show predefined classes based on form level */}
              {formData.grade ? (
                classOptions[formData.grade] && classOptions[formData.grade].length > 0 ? (
                  <View style={styles.classSelectionContainer}>
                    <ScrollView 
                      horizontal 
                      showsHorizontalScrollIndicator={false}
                      contentContainerStyle={styles.classSelectionContent}
                    >
                      {classOptions[formData.grade].map((className) => (
                        <TouchableOpacity
                          key={className}
                          style={[
                            styles.classChip,
                            formData.class === className && styles.selectedClassChip
                          ]}
                          onPress={() => handleFormChange('class', className)}
                        >
                          <Text style={[
                            styles.classChipText,
                            formData.class === className && styles.selectedClassChipText
                          ]}>
                            {className}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </ScrollView>
                  </View>
                ) : (
                  <View style={commonStyles.input}>
                    <Text style={styles.dropdownText}>No classes available for {formData.grade}</Text>
                  </View>
                )
              ) : (
                <View style={commonStyles.input}>
                  <Text style={styles.dropdownText}>Please select a form level first</Text>
                </View>
              )}
              
              <Text style={styles.helperText}>
                * Select a class for this student. Classes must be manually added to Class Management before they can be assigned to students.
              </Text>
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Parent Contact *</Text>
              <TextInput
                style={commonStyles.input}
                value={formData.parentContact}
                onChangeText={(text) => handleFormChange('parentContact', text)}
                placeholder="Enter parent phone number"
                placeholderTextColor={colors.textSecondary}
                keyboardType="phone-pad"
                autoComplete="off"
                autoCorrect={false}
                spellCheck={false}
                autoCapitalize="none"
                textContentType="none"
              />
            </View>
          </ScrollView>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  cancelButton: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },

  saveButton: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.primary,
  },

  formGroup: {
    marginBottom: spacing.md,
  },

  label: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  dropdownContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  dropdownText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  placeholderText: {
    color: colors.textSecondary,
  },

  dropdownOptions: {
    backgroundColor: colors.card,
    borderRadius: 8,
    marginTop: spacing.xs,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
    }),
  },

  dropdownOption: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  dropdownOptionText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },

  selectedOption: {
    fontWeight: typography.weights.bold,
    color: colors.primary,
  },

  classSelectionContainer: {
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: spacing.xs,
    minHeight: 40,
  },

  classSelectionContent: {
    paddingVertical: spacing.xs,
  },

  classChip: {
    backgroundColor: colors.background,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: 16,
    marginRight: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },

  selectedClassChip: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },

  classChipText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
  },

  selectedClassChipText: {
    color: colors.card,
    fontWeight: typography.weights.semibold,
  },

  helperText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    fontStyle: 'italic',
  },
});