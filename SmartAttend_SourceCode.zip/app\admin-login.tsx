import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/utils/supabase';

export default function AdminLoginScreen() {
  const { login, setUserId } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAdminLogin = async () => {
    // Validate inputs
    if (!username.trim()) {
      Alert.alert('Error', 'Email is required');
      return;
    }
    
    if (!password) {
      Alert.alert('Error', 'Password is required');
      return;
    }
    
    setLoading(true);
    
    try {
      // Check network connectivity first
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
        
        const response = await fetch('https://plfkwdyqqgqfnthynpcb.supabase.co/rest/v1/', {
          method: 'HEAD',
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        console.log('🌐 Network connectivity test:', response.status);
      } catch (networkError: any) {
        console.error('❌ Network connectivity test failed:', networkError);
        if (networkError.name === 'AbortError') {
          Alert.alert('Login Failed', 'Connection timed out. Please check your internet connection and try again.');
        } else {
          Alert.alert('Login Failed', 'Could not connect to server. Please check your internet connection.');
        }
        setLoading(false);
        return;
      }
      
      // Sign in with Supabase
      const { data, error } = await supabase.auth.signInWithPassword({
        email: username,
        password: password,
      });
      
      if (error) {
        console.error('❌ Auth login error:', error);
        if (error.message.includes('Invalid login credentials')) {
          Alert.alert('Login Failed', 'Invalid email or password. Please try again.');
        } else if (error.message.includes('Invalid API key') || error.message.includes('Unauthorized')) {
          Alert.alert('Login Failed', 'Invalid Supabase API key. Please contact the administrator.');
        } else if (error.message.includes('Unable to resolve host')) {
          Alert.alert('Login Failed', 'Could not connect to server. Please check your internet connection.');
        } else {
          Alert.alert('Login Failed', `Auth Error: ${error.message}`);
        }
        setLoading(false);
        return;
      }
      
      if (!data.user) {
        console.error('❌ No user data returned from auth login');
        Alert.alert('Login Failed', 'Login failed - no user data returned');
        setLoading(false);
        return;
      }
      
      // Get user role from database
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('user_type')
        .eq('id', data.user.id)
        .maybeSingle();
      
      if (userError) {
        console.error('❌ Database query error:', userError);
        if (userError.message.includes('Unable to resolve host')) {
          Alert.alert('Login Failed', 'Could not connect to server. Please check your internet connection.');
        } else {
          Alert.alert('Login Failed', `Database Error: ${userError.message}`);
        }
        setLoading(false);
        return;
      }
      
      // Check if user data exists before accessing it
      if (!userData) {
        console.error('❌ No user data found for user ID:', data.user.id);
        Alert.alert('Login Failed', 'User account not found in database.');
        setLoading(false);
        return;
      }
      
      // Check if user is admin
      if (userData.user_type !== 'admin') {
        Alert.alert('Access Denied', 'Access denied. Admin privileges required.');
        setLoading(false);
        return;
      }
      
      // Successful login
      login('admin');
      setUserId(data.user.id);
      router.replace('/(tabs)/dashboard');
    } catch (error: any) {
      console.error('💥 Admin login failed with error:', error);
      if (error.message.includes('Network request failed') || error.message.includes('Unable to resolve host')) {
        Alert.alert('Login Failed', 'Could not connect to server. Please check your internet connection.');
      } else {
        Alert.alert('Login Failed', `Unexpected Error: ${error.message || 'An unexpected error occurred'}`);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    router.replace('/login');
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <KeyboardAvoidingView 
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={styles.content}>
          <View style={styles.header}>
            <Text style={styles.title}>Admin Login</Text>
            <Text style={styles.subtitle}>Access administrative dashboard</Text>
          </View>

          <View style={styles.formContainer}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={commonStyles.input}
                value={username}
                onChangeText={setUsername}
                placeholder="Enter admin email"
                placeholderTextColor={colors.textSecondary}
                autoCapitalize="none"
                keyboardType="email-address"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Password</Text>
              <TextInput
                style={commonStyles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="Enter admin password"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry
              />
            </View>

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.loginButton}
                onPress={handleAdminLogin}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator size="small" color={colors.card} />
                ) : (
                  <Text style={styles.loginButtonText}>Login</Text>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.cancelButton}
                onPress={handleCancel}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    padding: spacing.lg,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xxl,
    marginTop: spacing.xxl,
  },
  title: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  formContainer: {
    flex: 1,
  },
  inputGroup: {
    marginBottom: spacing.lg,
  },
  label: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  buttonContainer: {
    marginTop: spacing.xxl,
    gap: spacing.md,
  },
  loginButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: 12,
    alignItems: 'center',
  },
  loginButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.card,
  },
  cancelButton: {
    paddingVertical: spacing.md,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  cancelButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },
});