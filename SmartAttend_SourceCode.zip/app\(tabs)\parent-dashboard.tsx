import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView, useWindowDimensions, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { router } from 'expo-router';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { PieChart, LineChart } from 'react-native-chart-kit';
import { getAttendanceByStudentId } from '@/utils/attendanceOperations';
import { getStudentById } from '@/utils/studentOperations';
import { supabase } from '@/utils/supabase';
import { useAuth } from '@/contexts/AuthContext';
import moment from 'moment-timezone';

interface AttendanceData {
  present: number;
  absent: number;
  late: number;
  total: number;
}

interface AttendanceRecord {
  id: string;
  student_id: string;
  student_name: string;
  class_name: string;
  check_in_time: string;
  check_out_time: string | null;
  status: 'present' | 'absent' | 'late';
  teacher_name: string;
  created_at: string;
  updated_at: string;
}

interface StudentData {
  student_id: string;
  student_name: string;
  grade: string;
  class_name: string;
  parent_contact: string;
  email_student: string;
  created_at: string;
}

export default function ParentDashboardScreen() {
  const { userId } = useAuth();
  const { width: screenWidth } = useWindowDimensions();
  const [attendanceData, setAttendanceData] = useState<AttendanceData>({
    present: 0,
    absent: 0,
    late: 0,
    total: 0,
  });
  
  const [studentData, setStudentData] = useState<StudentData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [weeklyTrend, setWeeklyTrend] = useState<any>({
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        data: [0, 0, 0, 0, 0, 0, 0],
        color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
        strokeWidth: 3,
      },
    ],
  });

  const [recentAttendance, setRecentAttendance] = useState<AttendanceRecord[]>([]);

  // Fetch parent's child data
  useEffect(() => {
    const fetchParentChildData = async () => {
      try {
        setLoading(true);
        
        // Get the parent's child ID from the users table
        const { data: userData, error: userError } = await supabase
          .from('users')
          .select('child_id')
          .eq('id', userId)
          .single();
        
        if (userError) {
          console.error('Error fetching user data:', userError);
          Alert.alert('Error', 'Failed to fetch user data');
          setLoading(false);
          return;
        }
        
        if (!userData?.child_id) {
          console.error('No child associated with this parent account');
          Alert.alert('Error', 'No child associated with this account. Please contact administrator.');
          setLoading(false);
          return;
        }
        
        // Fetch student data using the child ID
        const student = await getStudentById(userData.child_id);
        if (!student) {
          console.error('Student not found');
          Alert.alert('Error', 'Student data not found. Please check the ID with your teacher.');
          setLoading(false);
          return;
        }
        
        setStudentData(student);
        
        // Fetch attendance records for the student
        const attendanceRecords = await getAttendanceByStudentId(userData.child_id);
        
        // Calculate attendance data
        const presentCount = attendanceRecords.filter(record => record.status === 'present').length;
        const lateCount = attendanceRecords.filter(record => record.status === 'late').length;
        const absentCount = attendanceRecords.filter(record => record.status === 'absent').length;
        const totalCount = attendanceRecords.length;
        
        setAttendanceData({
          present: presentCount,
          absent: absentCount,
          late: lateCount,
          total: totalCount,
        });
        
        // Generate 7-day trend data
        const generateWeeklyTrend = () => {
          const labels = [];
          const data = [];
          
          for (let i = 6; i >= 0; i--) {
            const date = moment().tz('Asia/Kuala_Lumpur').subtract(i, 'days');
            const dateStr = date.format('YYYY-MM-DD');
            labels.push(date.format('ddd'));
            
            // Filter records for this specific date
            const dayRecords = attendanceRecords.filter(record => {
              if (!record.check_in_time) return false;
              const recordDate = moment(record.check_in_time).tz('Asia/Kuala_Lumpur').format('YYYY-MM-DD');
              return recordDate === dateStr;
            });
            
            // For parents, we'll show attendance count for the week
            data.push(dayRecords.length);
          }
          
          return {
            labels,
            datasets: [
              {
                data,
                color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
                strokeWidth: 3,
              },
            ],
          };
        };
        
        setWeeklyTrend(generateWeeklyTrend());
        
        // Get recent attendance records (last 5)
        const sortedRecords = [...attendanceRecords].sort((a, b) => {
          const dateA = a.check_in_time ? new Date(a.check_in_time) : new Date(0);
          const dateB = b.check_in_time ? new Date(b.check_in_time) : new Date(0);
          return dateB.getTime() - dateA.getTime();
        });
        
        setRecentAttendance(sortedRecords.slice(0, 5));
      } catch (error) {
        console.error('Error fetching parent dashboard data:', error);
        Alert.alert('Error', 'Failed to fetch dashboard data');
      } finally {
        setLoading(false);
      }
    };

    if (userId) {
      fetchParentChildData();
    }
  }, [userId]);

  const attendanceRate = attendanceData.total > 0 
    ? Math.round(((attendanceData.present + attendanceData.late) / attendanceData.total) * 100)
    : 0;

  const pieData = [
    {
      name: 'Present',
      population: attendanceData.present,
      color: colors.success,
      legendFontColor: colors.text,
      legendFontSize: 14,
    },
    {
      name: 'Absent',
      population: attendanceData.absent,
      color: colors.error,
      legendFontColor: colors.text,
      legendFontSize: 14,
    },
    {
      name: 'Late',
      population: attendanceData.late,
      color: colors.warning,
      legendFontColor: colors.text,
      legendFontSize: 14,
    },
  ];

  const chartConfig = {
    backgroundColor: colors.card,
    backgroundGradientFrom: colors.card,
    backgroundGradientTo: colors.card,
    decimalPlaces: 0,
    color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
    labelColor: (opacity = 1) => `rgba(33, 33, 33, ${opacity})`,
    style: {
      borderRadius: 16,
    },
    propsForDots: {
      r: '6',
      strokeWidth: '2',
      stroke: colors.primary,
    },
  };

  const StatCard = ({ title, value, subtitle, icon, color }: {
    title: string;
    value: string;
    subtitle?: string;
    icon: string;
    color: string;
  }) => (
    <View style={[styles.statCard, commonStyles.card]}>
      <View style={styles.statHeader}>
        <View style={[styles.statIcon, { backgroundColor: color }]}>
          <IconSymbol name={icon as any} size={24} color={colors.card} />
        </View>
        <Text style={styles.statTitle}>{title}</Text>
      </View>
      <Text style={styles.statValue}>{value}</Text>
      {subtitle && <Text style={styles.statSubtitle}>{subtitle}</Text>}
    </View>
  );

  const AttendanceItem = ({ record }: { record: AttendanceRecord }) => {
    const isAbsent = record.status === 'absent';
    
    const getStatusColor = (status: string) => {
      switch (status) {
        case 'present': return colors.success;
        case 'absent': return colors.error;
        case 'late': return colors.warning;
        default: return colors.textSecondary;
      }
    };

    const getStatusText = (status: string) => {
      return status.charAt(0).toUpperCase() + status.slice(1);
    };

    // For absent records, try to get date from check_in_time, created_at, or updated_at
    const getRecordDate = () => {
      if (record.check_in_time) {
        return formatDate(record.check_in_time);
      } else if (record.created_at) {
        return formatDate(record.created_at);
      } else if (record.updated_at) {
        return formatDate(record.updated_at);
      }
      return 'Date unavailable';
    };

    const formatDate = (dateString: string) => {
      return moment(dateString).tz('Asia/Kuala_Lumpur').format('MMM D, YYYY');
    };

    const formatTime = (dateString: string) => {
      return moment(dateString).tz('Asia/Kuala_Lumpur').format('hh:mm A');
    };

    return (
      <View style={[styles.attendanceItem, commonStyles.card]}>
        <View style={styles.attendanceHeader}>
          <Text style={styles.attendanceDate}>{getRecordDate()}</Text>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(record.status) }]}>
            <Text style={styles.statusBadgeText}>{getStatusText(record.status)}</Text>
          </View>
        </View>
        
        {isAbsent ? (
          // Show absent status details
          <View style={styles.attendanceDetails}>
            <View style={styles.absentInfo}>
              <Text style={styles.absentInfoText}>No check-in/check-out recorded</Text>
              <Text style={styles.absentDateText}>Date: {getRecordDate()}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <IconSymbol name="person" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Teacher: {record.teacher_name}</Text>
            </View>
            <View style={styles.detailRow}>
              <IconSymbol name="building.2" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Class: {record.class_name}</Text>
            </View>
          </View>
        ) : (
          // Show normal check-in/check-out details
          <View style={styles.attendanceDetails}>
            <View style={styles.detailRow}>
              <IconSymbol name="clock" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Check-in: {formatTime(record.check_in_time)}</Text>
            </View>
            {record.check_out_time && (
              <View style={styles.detailRow}>
                <IconSymbol name="clock.fill" size={16} color={colors.textSecondary} />
                <Text style={styles.detailText}>Check-out: {formatTime(record.check_out_time)}</Text>
              </View>
            )}
            <View style={styles.detailRow}>
              <IconSymbol name="person" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Teacher: {record.teacher_name}</Text>
            </View>
            <View style={styles.detailRow}>
              <IconSymbol name="building.2" size={16} color={colors.textSecondary} />
              <Text style={styles.detailText}>Class: {record.class_name}</Text>
            </View>
          </View>
        )}
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={[commonStyles.container, commonStyles.center]}>
          <Text style={commonStyles.body}>Loading dashboard...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!studentData) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={[commonStyles.container, commonStyles.center]}>
          <Text style={commonStyles.body}>No student data found</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <ScrollView 
        style={commonStyles.container}
        contentContainerStyle={[commonStyles.scrollContent, { paddingTop: spacing.md }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={commonStyles.content}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.headerContent}>
              <View style={{ flex: 1 }} />
              <View style={styles.titleContainer}>
                <Text style={styles.dashboardTitle} numberOfLines={1}>
                  {studentData.student_name}'s Attendance
                </Text>
              </View>
              <View style={{ flex: 1 }} />
            </View>
            <Text style={commonStyles.caption}>
              {moment().tz('Asia/Kuala_Lumpur').format('dddd, MMMM D, YYYY')}
            </Text>
          </View>

          {/* Student Info Card */}
          <View style={[commonStyles.card, styles.studentInfoCard]}>
            <View style={styles.studentHeader}>
              <View style={styles.studentIcon}>
                <IconSymbol name="person.fill" size={24} color={colors.card} />
              </View>
              <View style={styles.studentInfo}>
                <Text style={styles.studentName}>{studentData.student_name}</Text>
                <Text style={styles.studentDetails}>{studentData.grade} - {studentData.class_name}</Text>
              </View>
            </View>
            <View style={styles.contactInfo}>
              <View style={styles.contactRow}>
                <IconSymbol name="phone" size={16} color={colors.textSecondary} />
                <Text style={styles.contactText}>{studentData.parent_contact}</Text>
              </View>
              <View style={styles.contactRow}>
                <IconSymbol name="envelope" size={16} color={colors.textSecondary} />
                <Text style={styles.contactText}>{studentData.email_student}</Text>
              </View>
            </View>
          </View>

          {/* Stats Cards */}
          <View style={styles.statsGrid}>
            <StatCard
              title="Attendance Rate"
              value={`${attendanceRate}%`}
              subtitle="This month"
              icon="checkmark.circle"
              color={attendanceRate >= 80 ? colors.success : attendanceRate >= 60 ? colors.warning : colors.error}
            />
            <StatCard
              title="Present"
              value={attendanceData.present.toString()}
              subtitle="Days attended"
              icon="checkmark"
              color={colors.success}
            />
            <StatCard
              title="Late"
              value={attendanceData.late.toString()}
              subtitle="Days late"
              icon="clock"
              color={colors.warning}
            />
            <StatCard
              title="Absent"
              value={attendanceData.absent.toString()}
              subtitle="Days absent"
              icon="xmark"
              color={colors.error}
            />
          </View>

          {/* Today's Attendance Chart */}
          <View style={[commonStyles.card, styles.chartCard]}>
            <Text style={commonStyles.subtitle}>Attendance Summary</Text>
            <View style={styles.chartContainer}>
              <PieChart
                data={pieData}
                width={Math.min(screenWidth - 40, 400)} // Responsive width with max limit
                height={200}
                chartConfig={{
                  backgroundColor: colors.card,
                  backgroundGradientFrom: colors.card,
                  backgroundGradientTo: colors.card,
                  color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                }}
                accessor="population"
                backgroundColor="transparent"
                paddingLeft="15"
                center={[10, 0]}
                absolute
                style={Platform.OS === 'android' ? { marginLeft: -10 } : undefined} // Adjust for Android rendering
              />
            </View>
          </View>

          {/* 7-Day Trend */}
          <View style={[commonStyles.card, styles.chartCard]}>
            <Text style={commonStyles.subtitle}>7-Day Attendance Trend</Text>
            <View style={styles.chartContainer}>
              <LineChart
                data={weeklyTrend}
                width={Math.min(screenWidth - 40, 400)} // Responsive width with max limit
                height={200}
                chartConfig={chartConfig}
                bezier
                style={Platform.OS === 'android' ? { marginLeft: -10 } : undefined} // Adjust for Android rendering
              />
            </View>
          </View>

          {/* Recent Attendance */}
          <View style={[commonStyles.card, styles.attendanceCard]}>
            <Text style={commonStyles.subtitle}>Recent Attendance</Text>
            {recentAttendance.length > 0 ? (
              recentAttendance.map((record) => (
                <AttendanceItem key={record.id} record={record} />
              ))
            ) : (
              <Text style={commonStyles.body}>No attendance records found</Text>
            )}
          </View>

          {/* Logout Button */}
          <TouchableOpacity 
            style={styles.logoutButton}
            onPress={() => {
              Alert.alert(
                'Logout',
                'Are you sure you want to logout?',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { 
                    text: 'Logout', 
                    style: 'destructive',
                    onPress: () => {
                      router.replace('/login');
                    }
                  },
                ]
              );
            }}
          >
            <Text style={styles.logoutButtonText}>Log Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    marginBottom: spacing.lg,
    alignItems: 'center',
  },
  
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
  },
  
  titleContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.md,
  },
  
  dashboardTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    textAlign: 'center',
  },
  
  studentInfoCard: {
    marginBottom: spacing.lg,
  },
  
  studentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  
  studentIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  
  studentInfo: {
    flex: 1,
  },
  
  studentName: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  
  studentDetails: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },
  
  contactInfo: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.md,
  },
  
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  
  contactText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    marginLeft: spacing.sm,
  },
  
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: spacing.lg,
  },
  
  statCard: {
    width: '48%',
    marginBottom: spacing.md,
  },
  
  statHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },
  
  statTitle: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.textSecondary,
    flex: 1,
  },
  
  statValue: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  
  statSubtitle: {
    fontSize: typography.sizes.xs,
    color: colors.textSecondary,
  },
  
  chartCard: {
    marginBottom: spacing.lg,
  },
  
  chartContainer: {
    alignItems: 'center',
    marginTop: spacing.sm,
    // Add padding to prevent clipping on Android
    paddingHorizontal: spacing.sm,
  },
  
  attendanceCard: {
    marginBottom: spacing.lg,
  },
  
  attendanceItem: {
    marginBottom: spacing.sm,
    padding: spacing.md,
  },
  
  attendanceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  
  attendanceDate: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },
  
  statusBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 12,
  },
  
  statusBadgeText: {
    fontSize: typography.sizes.xs,
    fontWeight: typography.weights.bold,
    color: colors.card,
  },
  
  attendanceDetails: {
    paddingLeft: spacing.md,
  },
  
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  
  detailText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
    marginLeft: spacing.sm,
  },
  
  absentInfo: {
    backgroundColor: colors.background,
    padding: spacing.sm,
    borderRadius: 8,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.error + '30',
  },

  absentInfoText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.semibold,
    color: colors.error,
    marginBottom: spacing.xs,
    textAlign: 'center',
  },

  absentDateText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
    textAlign: 'center',
  },
  
  logoutButton: {
    backgroundColor: colors.card,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadows.sm,
    alignSelf: 'center',
    marginBottom: spacing.xl,
  },
  
  logoutButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.error,
  },
});