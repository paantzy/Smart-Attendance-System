import React, { useState, useEffect, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView, RefreshControl, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { getAttendanceRecords, deleteAttendanceRecord } from '../../utils/attendanceOperations';
import moment from 'moment-timezone';

interface AttendanceRecord {
  id: string;
  studentName: string;
  className: string;
  form: string;
  checkInTime: string;
  checkOutTime?: string; // Make checkOutTime optional
  date: string;
  teacher: string;
  status: 'present' | 'absent' | 'late';
}

export default function AttendanceScreen() {
  const [selectedForm, setSelectedForm] = useState('All');
  const [selectedClass, setSelectedClass] = useState('All');
  const [dateRange, setDateRange] = useState('Today'); // Default to Today
  const [showDateDropdown, setShowDateDropdown] = useState(false);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // Load attendance records from database
  useEffect(() => {
    const loadAttendanceRecords = async () => {
      try {
        setLoading(true);
        const records = await getAttendanceRecords();
        
        // Transform records to match the AttendanceRecord interface with proper timezone handling
        const transformedRecords: AttendanceRecord[] = records.map((record: any) => ({
          id: record.id.toString(),
          studentName: record.student?.student_name || 'Unknown Student',
          className: record.class_name || 'Unknown Class',
          form: record.student?.grade || 'Unknown Form',
          checkInTime: record.check_in_time ? moment(record.check_in_time).tz("Asia/Kuala_Lumpur").format("hh:mm A") : 'N/A',
          checkOutTime: record.check_out_time ? moment(record.check_out_time).tz("Asia/Kuala_Lumpur").format("hh:mm A") : undefined,
          date: record.check_in_time ? moment(record.check_in_time).tz("Asia/Kuala_Lumpur").format('YYYY-MM-DD') : 'N/A',
          teacher: record.teacher_name || 'Unknown Teacher',
          status: record.status || 'present',
        }));
        
        setAttendanceRecords(transformedRecords);
      } catch (error) {
        console.error('Error loading attendance records:', error);
        Alert.alert('Error', 'Failed to load attendance records: ' + (error as Error).message);
      } finally {
        setLoading(false);
      }
    };

    loadAttendanceRecords();
  }, []);

  // Format date as DD/MM/YYYY with proper timezone handling
  const formatDate = (dateString: string) => {
    return moment(dateString).tz('Asia/Kuala_Lumpur').format('DD/MM/YYYY');
  };

  // Get unique forms from attendance records and sort them numerically
  const uniqueForms = useMemo(() => {
    const forms = attendanceRecords.map(record => record.form);
    const uniqueForms = Array.from(new Set(forms));
    
    // Sort forms numerically (Form 1, Form 2, Form 3, Form 4, Form 5)
    uniqueForms.sort((a, b) => {
      // Handle 'Unknown Form' case
      if (a === 'Unknown Form' && b === 'Unknown Form') return 0;
      if (a === 'Unknown Form') return 1;
      if (b === 'Unknown Form') return -1;
      
      const numA = parseInt(a.replace('Form ', ''));
      const numB = parseInt(b.replace('Form ', ''));
      
      // Handle cases where parsing fails
      if (isNaN(numA) && isNaN(numB)) return 0;
      if (isNaN(numA)) return 1;
      if (isNaN(numB)) return -1;
      
      return numA - numB;
    });
    
    return ['All', ...uniqueForms];
  }, [attendanceRecords]);

  // Get unique classes from attendance records and sort them alphabetically
  const uniqueClasses = useMemo(() => {
    const classes = attendanceRecords.map(record => record.className);
    const uniqueClasses = Array.from(new Set(classes));
    
    // Sort classes alphabetically
    uniqueClasses.sort((a, b) => {
      // Handle 'Unknown Class' case
      if (a === 'Unknown Class' && b === 'Unknown Class') return 0;
      if (a === 'Unknown Class') return 1;
      if (b === 'Unknown Class') return -1;
      
      return a.localeCompare(b);
    });
    
    return ['All', ...uniqueClasses];
  }, [attendanceRecords]);

  // Date range options
  const dateRangeOptions = ['Today', 'Last 3 days', 'Last 7 days', 'Last 14 days', 'Last 30 days'];

  // Calculate date ranges
  const getDateRange = (range: string) => {
    const today = moment().tz('Asia/Kuala_Lumpur');
    let start = moment().tz('Asia/Kuala_Lumpur');
    
    switch (range) {
      case 'Today':
        start = today.startOf('day');
        break;
      case 'Last 3 days':
        start = today.clone().subtract(2, 'days').startOf('day');
        break;
      case 'Last 7 days':
        start = today.clone().subtract(6, 'days').startOf('day');
        break;
      case 'Last 14 days':
        start = today.clone().subtract(13, 'days').startOf('day');
        break;
      case 'Last 30 days':
        start = today.clone().subtract(29, 'days').startOf('day');
        break;
      default:
        start = today.startOf('day');
    }
    
    return { start, end: today.endOf('day') };
  };

  // Filter records based on selected form, selected class, and selected date range
  const filteredRecords = useMemo(() => {
    const { start, end } = getDateRange(dateRange);
    
    return attendanceRecords.filter(record => {
      const matchesForm = selectedForm === 'All' || record.form === selectedForm;
      const matchesClass = selectedClass === 'All' || record.className === selectedClass;
      
      // Parse record date using moment for proper comparison
      let recordDate: moment.Moment;
      try {
        // Parse the stored date string using moment
        recordDate = moment(record.date, 'YYYY-MM-DD').tz('Asia/Kuala_Lumpur');
      } catch (e) {
        // Fallback to today if parsing fails
        recordDate = moment().tz('Asia/Kuala_Lumpur');
      }
      
      // Check if record date is within the range
      const matchesDateRange = recordDate.isSameOrAfter(start) && recordDate.isSameOrBefore(end);
      
      return matchesForm && matchesClass && matchesDateRange;
    });
  }, [attendanceRecords, selectedForm, selectedClass, dateRange]);

  // Count total records for the selected date range
  const totalRecordsForDate = useMemo(() => {
    const { start, end } = getDateRange(dateRange);
    
    return attendanceRecords.filter(record => {
      // Parse record date using moment for proper comparison
      let recordDate: moment.Moment;
      try {
        // Parse the stored date string using moment
        recordDate = moment(record.date, 'YYYY-MM-DD').tz('Asia/Kuala_Lumpur');
      } catch (e) {
        // Fallback to today if parsing fails
        recordDate = moment().tz('Asia/Kuala_Lumpur');
      }
      
      return recordDate.isSameOrAfter(start) && recordDate.isSameOrBefore(end);
    }).length;
  }, [attendanceRecords, dateRange]);

  const AttendanceRecordItem = ({ record }: { record: AttendanceRecord }) => {
    const isAbsent = record.status === 'absent';
    
    return (
      <View style={[styles.recordCard, commonStyles.card]}>
        <View style={styles.recordHeader}>
          <Text style={styles.studentName} numberOfLines={1} ellipsizeMode="tail">{record.studentName}</Text>
          <Text style={styles.dateText}>{moment(record.date, 'YYYY-MM-DD').format('DD/MM/YYYY')}</Text>
        </View>
        
        <View style={styles.recordDetails}>
          <View style={styles.detailRow}>
            <IconSymbol name="building.2.fill" size={16} color={colors.textSecondary} />
            <Text style={styles.detailText}>{record.className} ({record.form})</Text>
          </View>
          
          <View style={styles.detailRow}>
            <IconSymbol name="person.fill" size={16} color={colors.textSecondary} />
            <Text style={styles.detailText}>{record.teacher}</Text>
          </View>
          
          {isAbsent ? (
            // Show absent status message
            <View style={styles.absentContainer}>
              <View style={[styles.statusBadge, styles.absentBadge]}>
                <IconSymbol name="xmark" size={16} color={colors.card} />
                <Text style={styles.statusBadgeText}>ABSENT</Text>
              </View>
              <View style={styles.absentInfo}>
                <Text style={styles.absentInfoText}>No check-in/check-out recorded</Text>
                <Text style={styles.absentDateText}>Date: {moment(record.date, 'YYYY-MM-DD').format('DD/MM/YYYY')}</Text>
                <Text style={styles.absentDetailsText}>Class: {record.className}</Text>
                <Text style={styles.absentDetailsText}>Teacher: {record.teacher}</Text>
              </View>
            </View>
          ) : (
            // Show normal check-in/check-out times
            <View style={styles.timeRow}>
              <View style={styles.timeItem}>
                <View style={styles.timeIconContainer}>
                  <IconSymbol name="arrow.down" size={16} color={colors.success} />
                </View>
                <View>
                  <Text style={styles.timeLabel}>Check-In</Text>
                  <Text style={styles.timeValue}>{record.checkInTime}</Text>
                </View>
              </View>
              
              <View style={styles.timeItem}>
                <View style={styles.timeIconContainer}>
                  <IconSymbol name="arrow.up" size={16} color={record.checkOutTime ? colors.error : colors.textSecondary} />
                </View>
                <View>
                  <Text style={styles.timeLabel}>Check-Out</Text>
                  <Text style={[styles.timeValue, !record.checkOutTime && { color: colors.textSecondary }]}>
                    {record.checkOutTime || 'Not checked out'}
                  </Text>
                </View>
              </View>
            </View>
          )}
        </View>
      </View>
    );
  };

  // Handle date range selection
  const onSelectDateRange = (range: string) => {
    setDateRange(range);
    setShowDateDropdown(false);
  };

  // Toggle date dropdown
  const toggleDateDropdown = () => {
    setShowDateDropdown(!showDateDropdown);
  };

  // Show loading indicator while data is loading
  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={[commonStyles.container, commonStyles.center]}>
          <Text style={commonStyles.body}>Loading attendance records...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <ScrollView 
        style={commonStyles.container}
        contentContainerStyle={commonStyles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={commonStyles.content}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={commonStyles.title}>Attendance Status</Text>
            <Text style={commonStyles.caption}>
              Detailed attendance records for all students
            </Text>
          </View>

          {/* Search and Filter */}
          <View style={styles.searchFilterContainer}>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.filtersContent}
            >
              {/* Form Filter Dropdown */}
              <TouchableOpacity
                style={styles.filterButton}
                onPress={() => {
                  // Cycle through form options
                  const currentIndex = uniqueForms.indexOf(selectedForm);
                  const nextIndex = (currentIndex + 1) % uniqueForms.length;
                  setSelectedForm(uniqueForms[nextIndex]);
                }}
              >
                <IconSymbol name="book" size={16} color={colors.textSecondary} />
                <Text style={styles.filterText}>
                  {selectedForm === 'All' ? 'All Forms' : selectedForm}
                </Text>
                <IconSymbol name="chevron.down" size={12} color={colors.textSecondary} />
              </TouchableOpacity>
              
              {/* Class Filter Dropdown */}
              <TouchableOpacity
                style={styles.filterButton}
                onPress={() => {
                  // Cycle through class options
                  const currentIndex = uniqueClasses.indexOf(selectedClass);
                  const nextIndex = (currentIndex + 1) % uniqueClasses.length;
                  setSelectedClass(uniqueClasses[nextIndex]);
                }}
              >
                <IconSymbol name="square.grid.2x2" size={16} color={colors.textSecondary} />
                <Text style={styles.filterText}>
                  {selectedClass === 'All' ? 'All Classes' : selectedClass}
                </Text>
                <IconSymbol name="chevron.down" size={12} color={colors.textSecondary} />
              </TouchableOpacity>
              
              {/* Date Filter Dropdown Button */}
              <TouchableOpacity 
                style={styles.filterButton}
                onPress={toggleDateDropdown}
              >
                <IconSymbol name="calendar" size={16} color={colors.textSecondary} />
                <Text style={styles.filterText}>
                  {dateRange} ({totalRecordsForDate} records)
                </Text>
                <IconSymbol name="chevron.down" size={12} color={colors.textSecondary} />
              </TouchableOpacity>
            </ScrollView>
          </View>

          {/* Date Range Dropdown Options */}
          {showDateDropdown && (
            <View style={styles.dropdownOptions}>
              {dateRangeOptions.map((option) => (
                <TouchableOpacity
                  key={option}
                  style={styles.dropdownOption}
                  onPress={() => onSelectDateRange(option)}
                >
                  <Text style={[
                    styles.dropdownOptionText,
                    dateRange === option && { fontWeight: 'bold' }
                  ]}>
                    {option}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Attendance Records */}
          <View style={styles.recordsContainer}>
            {filteredRecords.length > 0 ? (
              filteredRecords.map((record) => (
                <AttendanceRecordItem key={record.id} record={record} />
              ))
            ) : (
              <View style={[commonStyles.card, styles.emptyState]}>
                <IconSymbol name="person.fill" size={48} color={colors.textSecondary} />
                <Text style={styles.emptyText}>No attendance records found</Text>
                <Text style={styles.emptySubtext}>
                  {selectedForm !== 'All' || selectedClass !== 'All' || dateRange !== 'Today'
                    ? 'Try adjusting your filters'
                    : 'Attendance records will appear here after scanning QR codes'}
                </Text>
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    marginBottom: spacing.lg,
    alignItems: 'center',
  },

  searchFilterContainer: {
    marginBottom: spacing.lg,
  },

  filtersContent: {
    paddingHorizontal: spacing.md,
  },

  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
    ...shadows.sm,
    marginRight: spacing.sm,
  },

  filterText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
    marginHorizontal: spacing.xs,
  },

  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    ...shadows.sm,
    marginHorizontal: spacing.md,
  },

  searchInput: {
    flex: 1,
    fontSize: typography.sizes.md,
    color: colors.text,
    paddingVertical: 0,
  },

  dropdownOptions: {
    backgroundColor: colors.card,
    borderRadius: 12,
    ...shadows.md,
    marginHorizontal: spacing.md,
    marginBottom: spacing.lg,
    zIndex: 100,
  },

  dropdownOption: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  dropdownOptionText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
  },

  recordsContainer: {
    marginBottom: spacing.lg,
    marginHorizontal: spacing.md,
  },

  recordCard: {
    marginBottom: spacing.md,
  },

  recordHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
    paddingBottom: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  studentName: {
    flex: 1,
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginRight: spacing.sm,
  },

  dateText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    flexShrink: 0,
  },

  recordDetails: {
    // No additional styling needed
  },

  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },

  detailText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    marginLeft: spacing.sm,
  },

  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: spacing.md,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },

  timeItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  timeIconContainer: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },

  timeLabel: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },

  timeValue: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },

  absentContainer: {
    marginTop: spacing.md,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },

  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 8,
    marginBottom: spacing.md,
  },

  absentBadge: {
    backgroundColor: colors.error,
  },

  statusBadgeText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.bold,
    color: colors.card,
    marginLeft: spacing.xs,
  },

  absentInfo: {
    backgroundColor: colors.background,
    padding: spacing.md,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.error + '30',
  },

  absentInfoText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.error,
    marginBottom: spacing.sm,
    textAlign: 'center',
  },

  absentDateText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  absentDetailsText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },

  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl,
  },

  emptyText: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginTop: spacing.md,
    marginBottom: spacing.xs,
  },

  emptySubtext: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});