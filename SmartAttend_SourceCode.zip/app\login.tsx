import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
  Animated,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { router } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/utils/supabase';

interface UserRole {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export default function LoginScreen() {
  const { login, setUserId } = useAuth();
  const [selectedRole, setSelectedRole] = useState<string>('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Animated value for keyboard handling
  const keyboardOffset = useRef(new Animated.Value(0)).current;

  // Handle keyboard events
  useEffect(() => {
    const keyboardDidShow = Keyboard.addListener('keyboardDidShow', (e) => {
      Animated.timing(keyboardOffset, {
        toValue: -e.endCoordinates.height / 2,
        duration: 250,
        useNativeDriver: true,
      }).start();
    });

    const keyboardDidHide = Keyboard.addListener('keyboardDidHide', () => {
      Animated.timing(keyboardOffset, {
        toValue: 0,
        duration: 250,
        useNativeDriver: true,
      }).start();
    });

    return () => {
      keyboardDidShow.remove();
      keyboardDidHide.remove();
    };
  }, []);

  const roles: UserRole[] = [
    {
      id: 'teacher',
      name: 'Teacher',
      description: 'Manage classes and attendance',
      icon: 'person.badge.key' as any,
    },
    {
      id: 'parent',
      name: 'Parent',
      description: 'View child attendance',
      icon: 'person.2' as any,
    },
  ];

  const handleLogin = async () => {
    if (!selectedRole) {
      Alert.alert('Error', 'Please select a role');
      return;
    }

    if (!username || !password) {
      Alert.alert('Error', 'Please enter username and password');
      return;
    }

    setLoading(true);
    console.log('🚀 Starting login process');
    
    try {
      console.log('📧 Attempting to sign in user:', { email: username, selectedRole });
      
      // Check network connectivity first (using public endpoint)
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
        
        const response = await fetch('https://plfkwdyqqgqfnthynpcb.supabase.co/rest/v1/', {
          method: 'HEAD',
          signal: controller.signal,
          headers: {
            'apikey': process.env.EXPO_PUBLIC_SUPABASE_KEY || ''
          }
        });
        
        clearTimeout(timeoutId);
        // 200, 400, or 401 all mean server is reachable
        if (response.status === 200 || response.status === 401 || response.status === 400) {
          console.log('🌐 Network connectivity: OK (status:', response.status + ')');
        }
      } catch (networkError: any) {
        console.warn('⚠️ Network test failed (continuing anyway):', networkError.message);
        // Don't block login - the actual auth call will handle connection issues
      }
      
      // Sign in with Supabase
      const { data, error } = await supabase.auth.signInWithPassword({
        email: username,
        password: password,
      });
      
      if (error) {
        console.error('❌ Auth login error:', error);
        if (error.message.includes('Invalid login credentials')) {
          Alert.alert('Login Failed', 'Invalid email or password. Please try again.');
        } else if (error.message.includes('Invalid API key') || error.message.includes('Unauthorized')) {
          Alert.alert('Login Failed', 'Invalid Supabase API key. Please contact the administrator.');
        } else if (error.message.includes('Unable to resolve host')) {
          Alert.alert('Login Failed', 'Could not connect to server. Please check your internet connection.');
        } else {
          Alert.alert('Login Failed', `Auth Error: ${error.message}`);
        }
        setLoading(false);
        return;
      }
      
      console.log('✅ Auth login successful:', data);
      
      if (!data.user) {
        console.error('❌ No user data returned from auth login');
        Alert.alert('Login Failed', 'Login failed - no user data returned');
        setLoading(false);
        return;
      }
      
      // Get user role from database
      console.log('🔍 Fetching user role from database for user ID:', data.user.id);
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('user_type')
        .eq('id', data.user.id)
        .single();
      
      if (userError) {
        console.error('❌ Database query error:', userError);
        if (userError.message.includes('Unable to resolve host')) {
          Alert.alert('Login Failed', 'Could not connect to server. Please check your internet connection.');
        } else {
          Alert.alert('Login Failed', `Database Error: ${userError.message}`);
        }
        setLoading(false);
        return;
      }
      
      console.log('✅ User data fetched successfully:', userData);
      
      // Check if selected role matches user's role in database
      if (userData.user_type !== selectedRole) {
        const errorMsg = `Please select the correct role: ${userData.user_type}`;
        console.error('❌ Role mismatch:', errorMsg);
        Alert.alert('Login Failed', errorMsg);
        setLoading(false);
        return;
      }
      
      // Set user role and ID in context
      console.log('✅ Login validation successful, setting user context');
      login(selectedRole as any);
      setUserId(data.user.id);
      
      // Navigate to the main app (tabs)
      console.log('🚀 Navigating to dashboard');
      router.replace('/(tabs)/dashboard');
    } catch (error: any) {
      console.error('💥 Login failed with error:', error);
      console.error('Error name:', error.name);
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
      
      if (error.message.includes('Network request failed') || error.message.includes('Unable to resolve host')) {
        Alert.alert('Login Failed', 'Could not connect to server. Please check your internet connection.');
      } else {
        Alert.alert('Login Failed', `Unexpected Error: ${error.message || 'An unexpected error occurred'}`);
      }
    } finally {
      setLoading(false);
    }
  };

  const RoleCard = ({ role }: { role: UserRole }) => (
    <TouchableOpacity
      style={[
        styles.roleCard,
        selectedRole === role.id && styles.roleCardSelected,
      ]}
      onPress={() => setSelectedRole(role.id)}
    >
      <View style={styles.roleIcon}>
        <IconSymbol 
          name={role.icon} 
          size={24} 
          color={selectedRole === role.id ? colors.card : colors.primary} 
        />
      </View>
      <View style={styles.roleInfo}>
        <Text style={[
          styles.roleName,
          selectedRole === role.id && styles.roleNameSelected,
        ]}>
          {role.name}
        </Text>
        <Text style={[
          styles.roleDescription,
          selectedRole === role.id && styles.roleDescriptionSelected,
        ]}>
          {role.description}
        </Text>
      </View>
      {selectedRole === role.id && (
        <IconSymbol name="checkmark.circle.fill" size={20} color={colors.card} />
      )}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <KeyboardAvoidingView 
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 80}
      >
        <ScrollView>
          <Animated.View 
            style={[
              styles.animatedContainer,
              { transform: [{ translateY: keyboardOffset }] }
            ]}
          >
            <View style={styles.header}>
              <View style={styles.logoContainer}>
                <IconSymbol name="graduationcap.fill" size={48} color={colors.primary} />
              </View>
              <Text style={styles.title}>SmartAttend</Text>
              <Text style={styles.subtitle}>School Attendance Management</Text>
            </View>

            <View style={styles.content}>
              <Text style={styles.sectionTitle}>Select Your Role</Text>
              
              <View style={styles.rolesContainer}>
                {roles.map((role) => (
                  <RoleCard key={role.id} role={role} />
                ))}
              </View>

              <View style={styles.formContainer}>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Email</Text>
                  <TextInput
                    style={commonStyles.input}
                    value={username}
                    onChangeText={setUsername}
                    placeholder="Enter your email"
                    placeholderTextColor={colors.textSecondary}
                    autoCapitalize="none"
                    autoCorrect={false}
                    keyboardType="email-address"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Password</Text>
                  <TextInput
                    style={commonStyles.input}
                    value={password}
                    onChangeText={setPassword}
                    placeholder="Enter your password"
                    placeholderTextColor={colors.textSecondary}
                    secureTextEntry
                    autoCapitalize="none"
                    autoCorrect={false}
                  />
                </View>

                <TouchableOpacity
                  style={[
                    styles.loginButton,
                    (!selectedRole || !username || !password || loading) && styles.loginButtonDisabled,
                  ]}
                  onPress={handleLogin}
                  disabled={!selectedRole || !username || !password || loading}
                >
                  {loading ? (
                    <ActivityIndicator size="small" color={colors.card} />
                  ) : (
                    <Text style={styles.loginButtonText}>Sign In</Text>
                  )}
                </TouchableOpacity>

                <View style={styles.navigationContainer}>
                  <TouchableOpacity 
                    style={styles.linkButton}
                    onPress={() => {
                      // If parent role is selected, go directly to parent registration
                      if (selectedRole === 'parent') {
                        router.push('/parent-register');
                      } else if (selectedRole === 'teacher') {
                        // Pass the teacher role to the registration screen
                        router.push({ pathname: '/register', params: { userType: 'teacher' } });
                      } else {
                        // No role selected, go to registration without params
                        router.push('/register');
                      }
                    }}
                  >
                    <Text style={styles.linkText}>Create New Account</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },

  animatedContainer: {
    flex: 1,
  },

  header: {
    alignItems: 'center',
    paddingTop: spacing.xl,
    paddingBottom: spacing.lg,
  },

  logoContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.md,
    ...shadows.md,
  },

  title: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  subtitle: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
  },

  content: {
    flex: 1,
    paddingHorizontal: spacing.lg,
  },

  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
  },

  rolesContainer: {
    marginBottom: spacing.md,
  },

  roleCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    padding: spacing.md,
    borderRadius: 12,
    marginBottom: spacing.sm,
    borderWidth: 2,
    borderColor: 'transparent',
    ...shadows.sm,
  },

  roleCardSelected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },

  roleIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },

  roleInfo: {
    flex: 1,
  },

  roleName: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  roleNameSelected: {
    color: colors.card,
  },

  roleDescription: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },

  roleDescriptionSelected: {
    color: colors.card,
    opacity: 0.9,
  },

  formContainer: {
    marginTop: spacing.sm,
  },

  inputGroup: {
    marginBottom: spacing.md,
  },

  label: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  loginButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: spacing.md,
    ...shadows.sm,
  },

  loginButtonDisabled: {
    backgroundColor: colors.textSecondary,
    opacity: 0.5,
  },

  loginButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.card,
  },

  navigationContainer: {
    marginTop: spacing.lg,
    alignItems: 'center',
  },

  linkButton: {
    padding: spacing.sm,
  },

  linkText: {
    color: colors.primary,
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
  },
});