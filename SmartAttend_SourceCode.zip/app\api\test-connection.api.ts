import { supabase } from '../../utils/supabase';

export async function GET() {
  try {
    console.log('Testing Supabase connection from API route...');
    
    // Test basic connection
    const { data, error } = await supabase
      .from('users')
      .select('count')
      .limit(1);
    
    if (error) {
      if (error.message.includes('Relation "users" does not exist')) {
        return new Response(
          JSON.stringify({ 
            success: true, 
            message: 'Connection successful (users table does not exist yet)',
            error: null
          }),
          { 
            status: 200,
            headers: {
              'Content-Type': 'application/json',
            }
          }
        );
      } else {
        return new Response(
          JSON.stringify({ 
            success: false, 
            message: 'Connection test error',
            error: error.message
          }),
          { 
            status: 500,
            headers: {
              'Content-Type': 'application/json',
            }
          }
        );
      }
    } else {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Connection successful',
          data: data
        }),
        { 
          status: 200,
          headers: {
            'Content-Type': 'application/json',
          }
        }
      );
    }
  } catch (err) {
    console.error('Connection test failed:', err);
    return new Response(
      JSON.stringify({ 
        success: false, 
        message: 'Connection test failed',
        error: err instanceof Error ? err.message : 'Unknown error'
      }),
      { 
        status: 500,
        headers: {
          'Content-Type': 'application/json',
        }
      }
    );
  }
}