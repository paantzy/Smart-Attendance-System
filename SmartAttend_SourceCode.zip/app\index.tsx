import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, TouchableOpacity, Alert } from 'react-native';
import { Redirect, router } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/utils/supabase';
import NetInfo from '@react-native-community/netinfo';
import { performanceMonitor } from '@/utils/performanceMonitor';

export default function Index() {
  const { userRole, loading, isOffline } = useAuth();
  const [connectionStatus, setConnectionStatus] = useState<string>('');
  const [networkStatus, setNetworkStatus] = useState<string>('');
  const [loadTimeout, setLoadTimeout] = useState(false);
  const [performanceStats, setPerformanceStats] = useState<any>(null);

  // Test network connectivity
  useEffect(() => {
    const checkNetwork = async () => {
      try {
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Network check timeout')), 3000)
        );
        
        const networkPromise = NetInfo.fetch();
        const state = await Promise.race([networkPromise, timeoutPromise]) as any;
        
        if (state.isConnected) {
          setNetworkStatus('Connected');
        } else {
          setNetworkStatus('Offline');
        }
      } catch (err: any) {
        setNetworkStatus('Offline');
      }
    };

    checkNetwork();
  }, []);

  // Add timeout for loading state
  useEffect(() => {
    if (loading) {
      const timer = setTimeout(() => {
        setLoadTimeout(true);
        const stats = performanceMonitor.getPerformanceStats();
        setPerformanceStats(stats);
      }, 10000); // Reduced to 10 seconds

      return () => clearTimeout(timer);
    }
  }, [loading]);

  // Test Supabase connection (non-blocking)
  useEffect(() => {
    const testConnection = async () => {
      try {
        const startTime = Date.now();
        const { data, error } = await supabase
          .from('students')
          .select('id')
          .limit(1);
        
        const duration = Date.now() - startTime;
        
        if (error) {
          setConnectionStatus(`Failed (${duration}ms)`);
        } else {
          setConnectionStatus(`OK (${duration}ms)`);
        }
      } catch (err: any) {
        setConnectionStatus('Failed');
      }
    };

    testConnection();
  }, []);

  // If loading timeout reached, show error and option to retry
  if (loading && loadTimeout) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Connection Timeout</Text>
        <Text style={styles.statusText}>Unable to connect to server.</Text>
        {isOffline && <Text style={styles.statusText}>🔴 Offline Mode</Text>}
        {networkStatus && <Text style={styles.statusText}>Network: {networkStatus}</Text>}
        {connectionStatus && <Text style={styles.statusText}>DB: {connectionStatus}</Text>}
        <TouchableOpacity 
          style={styles.retryButton}
          onPress={() => {
            setLoadTimeout(false);
            setPerformanceStats(null);
            router.replace('/');
          }}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.retryButton, { backgroundColor: '#007AFF', marginTop: 10 }]}
          onPress={() => router.push('/login')}
        >
          <Text style={styles.retryButtonText}>Continue Offline</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // If we're still loading auth state, show a loading indicator
  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Initializing...</Text>
        {isOffline && <Text style={styles.statusText}>🔴 Offline</Text>}
      </View>
    );
  }

  // If user is already logged in, redirect to dashboard
  if (userRole) {
    return <Redirect href="/(tabs)/dashboard" />;
  }

  // Redirect to the login screen
  return <Redirect href="/login" />;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  loadingText: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  statusText: {
    marginTop: 10,
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
  },
  testButton: {
    backgroundColor: '#007AFF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginBottom: 20,
  },
  testButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  retryButton: {
    backgroundColor: '#1976d2',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginTop: 20,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});