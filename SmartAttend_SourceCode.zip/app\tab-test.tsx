import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';
import { getTabsForRole } from '@/utils/roleManager';

export default function TabTestScreen() {
  // Test tabs for different roles
  const adminTabs = getTabsForRole('admin');
  const teacherTabs = getTabsForRole('teacher');
  const parentTabs = getTabsForRole('parent');

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        <Text style={commonStyles.title}>Tab Configuration Test</Text>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Admin Tabs ({adminTabs.length})</Text>
          {adminTabs.map((tab, index) => (
            <View key={index} style={styles.tabItem}>
              <Text style={styles.tabName}>{tab.label}</Text>
              <Text style={styles.tabRoute}>{tab.route}</Text>
            </View>
          ))}
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Teacher Tabs ({teacherTabs.length})</Text>
          {teacherTabs.map((tab, index) => (
            <View key={index} style={styles.tabItem}>
              <Text style={styles.tabName}>{tab.label}</Text>
              <Text style={styles.tabRoute}>{tab.route}</Text>
            </View>
          ))}
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Parent Tabs ({parentTabs.length})</Text>
          {parentTabs.map((tab, index) => (
            <View key={index} style={styles.tabItem}>
              <Text style={styles.tabName}>{tab.label}</Text>
              <Text style={styles.tabRoute}>{tab.route}</Text>
            </View>
          ))}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  section: {
    ...commonStyles.card,
    marginBottom: spacing.md,
    padding: spacing.md,
  },
  
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  
  tabItem: {
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  
  tabName: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
    color: colors.text,
  },
  
  tabRoute: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    fontFamily: 'monospace',
  },
});