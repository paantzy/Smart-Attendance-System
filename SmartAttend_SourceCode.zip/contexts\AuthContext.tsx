// contexts/AuthContext.tsx
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserRole } from '@/utils/roleManager';
import { supabase } from '@/utils/supabase';
import { trackSupabaseCall } from '@/utils/performanceMonitor';

interface AuthContextType {
  userRole: UserRole | null;
  userId: string | null;
  login: (role: UserRole) => void;
  logout: () => void;
  setUserId: (id: string | null) => void;
  loading: boolean;
  isOffline: boolean; // Add offline state
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false); // Changed from true to false - no loading!
  const [isOffline, setIsOffline] = useState(false);

  // Check active session on app start (non-blocking)
  useEffect(() => {
    const checkSession = async () => {
      try {
        // Don't set loading - check session in background
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Session check timeout')), 5000)
        );
        
        const sessionPromise = trackSupabaseCall('AUTH GET SESSION', async () => {
          const { data, error } = await supabase.auth.getSession();
          return { data, error };
        });
        
        const result = await Promise.race([sessionPromise, timeoutPromise]);
        const { data: { session }, error: sessionError } = result as any;
        
        if (sessionError) {
          return;
        }
        
        if (session) {
          const userRolePromise = trackSupabaseCall('GET USER ROLE', async () => {
            const { data, error } = await supabase
              .from('users')
              .select('user_type')
              .eq('id', session.user.id)
              .maybeSingle();
            return { data, error };
          });
          
          const userRoleResult = await Promise.race([userRolePromise, timeoutPromise]) as any;
          const { data, error } = userRoleResult;
          
          if (!error && data) {
            setUserRole(data.user_type as UserRole);
            setUserId(session.user.id);
          }
        }
      } catch (error: any) {
        // Silently fail and allow offline usage
        setIsOffline(true);
      }
    };

    checkSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Database query timeout')), 5000)
        );
        
        const userRolePromise = trackSupabaseCall('GET USER ROLE ON CHANGE', async () => {
          const { data, error } = await supabase
            .from('users')
            .select('user_type')
            .eq('id', session.user.id)
            .maybeSingle();
          return { data, error };
        });
        
        Promise.race([userRolePromise, timeoutPromise])
          .then((result: any) => {
            const { data, error } = result;
            if (!error && data) {
              setUserRole(data.user_type as UserRole);
              setUserId(session.user.id);
            }
          })
          .catch(() => {
            // Silently fail
          });
      } else {
        setUserRole(null);
        setUserId(null);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const login = (role: UserRole) => {
    setUserRole(role);
  };

  const logout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (error) {
      // Silently fail
    }
    setUserRole(null);
    setUserId(null);
  };

  return (
    <AuthContext.Provider value={{ userRole, userId, login, logout, setUserId, loading, isOffline }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};