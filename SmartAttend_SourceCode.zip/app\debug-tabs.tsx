import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';
import { getTabsForRole } from '@/utils/roleManager';

export default function DebugTabsScreen() {
  const [tabsInfo, setTabsInfo] = useState({
    adminTabs: [] as any[],
    teacherTabs: [] as any[],
    parentTabs: [] as any[],
  });

  useEffect(() => {
    // Test the tab filtering
    const adminTabs = getTabsForRole('admin');
    const teacherTabs = getTabsForRole('teacher');
    const parentTabs = getTabsForRole('parent');
    
    setTabsInfo({
      adminTabs,
      teacherTabs,
      parentTabs,
    });
    
    // Log to console for debugging
    console.log('Admin Tabs:', adminTabs);
    console.log('Teacher Tabs:', teacherTabs);
    console.log('Parent Tabs:', parentTabs);
  }, []);

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        <Text style={commonStyles.title}>Tab Debug Information</Text>
        <Text style={styles.subtitle}>Verifying tab visibility for each role</Text>
        
        <ScrollView style={styles.content}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Admin Tabs ({tabsInfo.adminTabs.length})</Text>
            {tabsInfo.adminTabs.map((tab, index) => (
              <View key={index} style={styles.tabItem}>
                <Text style={styles.tabLabel}>{tab.label}</Text>
                <Text style={styles.tabRoute}>{tab.route}</Text>
                <Text style={styles.tabName}>Name: {tab.name}</Text>
              </View>
            ))}
          </View>
          
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Teacher Tabs ({tabsInfo.teacherTabs.length})</Text>
            {tabsInfo.teacherTabs.map((tab, index) => (
              <View key={index} style={styles.tabItem}>
                <Text style={styles.tabLabel}>{tab.label}</Text>
                <Text style={styles.tabRoute}>{tab.route}</Text>
                <Text style={styles.tabName}>Name: {tab.name}</Text>
              </View>
            ))}
          </View>
          
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Parent Tabs ({tabsInfo.parentTabs.length})</Text>
            {tabsInfo.parentTabs.map((tab, index) => (
              <View key={index} style={styles.tabItem}>
                <Text style={styles.tabLabel}>{tab.label}</Text>
                <Text style={styles.tabRoute}>{tab.route}</Text>
                <Text style={styles.tabName}>Name: {tab.name}</Text>
              </View>
            ))}
          </View>
          
          <View style={styles.infoSection}>
            <Text style={styles.infoTitle}>Scanner Tab Verification</Text>
            <Text style={styles.infoText}>
              Teacher has scanner permission: {getTabsForRole('teacher').some(tab => tab.name === 'scanner') ? 'YES' : 'NO'}
            </Text>
            <Text style={styles.infoText}>
              Parent has scanner permission: {getTabsForRole('parent').some(tab => tab.name === 'scanner') ? 'YES' : 'NO'}
            </Text>
            <Text style={styles.infoText}>
              Admin has scanner permission: {getTabsForRole('admin').some(tab => tab.name === 'scanner') ? 'YES' : 'NO'}
            </Text>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },
  
  subtitle: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  
  section: {
    ...commonStyles.card,
    marginBottom: spacing.md,
    padding: spacing.md,
  },
  
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  
  tabItem: {
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  
  tabLabel: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
    color: colors.text,
  },
  
  tabRoute: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    fontFamily: 'monospace',
  },
  
  tabName: {
    fontSize: typography.sizes.sm,
    color: colors.primary,
  },
  
  infoSection: {
    ...commonStyles.card,
    padding: spacing.md,
    backgroundColor: colors.primary + '10',
  },
  
  infoTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
  },
  
  infoText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    marginBottom: spacing.sm,
  },
});