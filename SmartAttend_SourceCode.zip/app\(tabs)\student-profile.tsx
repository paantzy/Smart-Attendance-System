import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView, Image, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { router, useLocalSearchParams } from 'expo-router';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { getStudentById } from '../../utils/studentOperations';
import { getAttendanceByStudentId } from '../../utils/attendanceOperations';
import QRCode from 'react-native-qrcode-svg';
import moment from 'moment-timezone';

interface AttendanceRecord {
  id: string;
  date: string;
  class?: string;
  status: 'present' | 'absent' | 'late';
  time?: string;
}

interface StudentProfile {
  id: string;
  name: string;
  grade: string;
  class?: string;
  parentContact: string;
  email: string;
  photo: string;
  attendanceRate: number;
  totalSessions: number;
  presentCount: number;
  absentCount: number;
  lateCount: number;
  attendanceHistory: AttendanceRecord[];
}

export default function StudentProfileScreen() {
  const { userRole } = useAuth();
  const { studentId } = useLocalSearchParams();
  const [student, setStudent] = useState<StudentProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Check if user is a parent
  const isParent = userRole === 'parent';

  useEffect(() => {
    const fetchStudentData = async () => {
      try {
        setLoading(true);
        if (typeof studentId === 'string') {
          const [studentData, attendanceData] = await Promise.all([
            getStudentById(studentId),
            getAttendanceByStudentId(studentId),
          ]);
          
          if (studentData) {
            // Transform the data to match our interface
            const transformedStudent: StudentProfile = {
              id: studentData.student_id,
              name: studentData.student_name,
              grade: studentData.grade,
              class: studentData.class_name,
              parentContact: studentData.parent_contact,
              email: studentData.email_student,
              photo: 'person', // Default photo
              attendanceRate: 95, // Mock data - would come from attendance records in real app
              totalSessions: 40, // Mock data
              presentCount: 38, // Mock data
              absentCount: 1, // Mock data
              lateCount: 1, // Mock data
              attendanceHistory: attendanceData || [],
            };
            
            setStudent(transformedStudent);
          } else {
            Alert.alert('Error', 'Student not found');
            router.back();
          }
        }
      } catch (error) {
        console.error('Error fetching student:', error);
        Alert.alert('Error', 'Failed to load student data');
        router.back();
      } finally {
        setLoading(false);
      }
    };

    if (studentId) {
      fetchStudentData();
    } else {
      setLoading(false);
    }
  }, [studentId]);

  // Show loading state while fetching student data
  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={commonStyles.container}>
          <Text>Loading student profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!student) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={commonStyles.container}>
          <Text>Student not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return colors.success;
      case 'absent':
        return colors.error;
      case 'late':
        return colors.warning;
      default:
        return colors.textSecondary;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'present':
        return 'checkmark';
      case 'absent':
        return 'close';
      case 'late':
        return 'clock';
      default:
        return 'minus';
    }
  };

  const formatDate = (dateString: string) => {
    return moment(dateString).tz('Asia/Kuala_Lumpur').format('ddd, MMM D');
  };

  const StatCard = ({ title, value, subtitle, color }: {
    title: string;
    value: string;
    subtitle: string;
    color: string;
  }) => (
    <View style={[styles.statCard, commonStyles.card]}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statTitle}>{title}</Text>
      <Text style={[styles.statSubtitle, { color }]}>{subtitle}</Text>
    </View>
  );

  const AttendanceItem = ({ record }: { record: AttendanceRecord }) => (
    <View style={styles.attendanceItem}>
      <View style={styles.attendanceDate}>
        <Text style={styles.dateText}>{formatDate(record.date)}</Text>
        {record.time && (
          <Text style={styles.timeText}>{record.time}</Text>
        )}
      </View>
      <View style={styles.attendanceStatus}>
        <View style={[
          styles.statusIndicator,
          { backgroundColor: getStatusColor(record.status) }
        ]}>
          <IconSymbol
            name={getStatusIcon(record.status) as any}
            size={16}
            color={colors.card}
          />
        </View>
        <Text style={[
          styles.statusText,
          { color: getStatusColor(record.status) }
        ]}>
          {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
        </Text>
        {record.class && record.class.trim() !== '' && (
          <Text style={styles.classText}>{record.class}</Text>
        )}
      </View>
    </View>
  );

  const QRCodeCard = () => {
    return (
      <View style={[commonStyles.card, styles.qrCard]}>
        <Text style={commonStyles.subtitle}>Student QR Code</Text>
        <View style={styles.qrCodeContainer}>
          <View style={styles.qrCodeWrapper}>
            <QRCode
              value={student?.id || ''}
              size={Platform.OS === 'web' ? 200 : 180} // Adjust size for mobile
              color={colors.primary}
              backgroundColor={colors.card}
              quietZone={10}
              onError={(error: any) => {
                console.error('QR Code rendering error:', error);
              }}
            />
          </View>
          <Text style={styles.qrCodeText}>ID: {student?.id || ''}</Text>
          <Text style={styles.qrInstructions}>
            Show this QR code to your teacher for attendance scanning
          </Text>
        </View>
      </View>
    );
  }

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            delayPressIn={Platform.OS === 'ios' ? 50 : 0}
            delayPressOut={Platform.OS === 'ios' ? 50 : 0}
          >
            <IconSymbol name="chevron.left" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text style={commonStyles.title}>Student Profile</Text>
          {/* Hide edit button for parents */}
          {!isParent && (
            <TouchableOpacity 
              style={styles.editButton}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              delayPressIn={Platform.OS === 'ios' ? 50 : 0}
              delayPressOut={Platform.OS === 'ios' ? 50 : 0}
            >
              <IconSymbol name="pencil" size={20} color={colors.primary} />
            </TouchableOpacity>
          )}
        </View>

        <ScrollView
          style={styles.content}
          contentContainerStyle={[commonStyles.scrollContent, { paddingBottom: 100 }]}
          showsVerticalScrollIndicator={false}
        >
          {/* Profile Header */}
          <View style={[commonStyles.card, styles.profileCard]}>
            <View style={styles.profileHeader}>
              {student.photo === 'person' ? (
                <View style={[styles.profilePhoto, { justifyContent: 'center', alignItems: 'center', backgroundColor: colors.card }]}>
                  <IconSymbol name="person.fill" size={40} color={colors.textSecondary} />
                </View>
              ) : (
                <Image source={{ uri: student.photo }} style={styles.profilePhoto} />
              )}
              <View style={styles.profileInfo}>
                <Text style={styles.studentName}>{student.name}</Text>
                <Text style={styles.studentGrade}>{student.grade}</Text>
                {student.class && student.class.trim() !== '' && (
                  <Text style={styles.studentClass}>{student.class}</Text>
                )}
              </View>
            </View>

            <View style={styles.contactInfo}>
              <View style={styles.contactRow}>
                <IconSymbol name="phone" size={16} color={colors.textSecondary} />
                <Text style={styles.contactText}>{student.parentContact}</Text>
              </View>
              <View style={styles.contactRow}>
                <IconSymbol name="envelope" size={16} color={colors.textSecondary} />
                <Text style={styles.contactText}>{student.email}</Text>
              </View>
            </View>
          </View>

          {/* Stats Cards */}
          <View style={styles.statsGrid}>
            <StatCard
              title="Attendance Rate"
              value={`${student.attendanceRate}%`}
              subtitle="Overall"
              color={student.attendanceRate >= 90 ? colors.success : colors.warning}
            />
            <StatCard
              title="Total Sessions"
              value={student.totalSessions.toString()}
              subtitle="This semester"
              color={colors.primary}
            />
            <StatCard
              title="Present"
              value={student.presentCount.toString()}
              subtitle="Days attended"
              color={colors.success}
            />
            <StatCard
              title="Absent"
              value={student.absentCount.toString()}
              subtitle="Days missed"
              color={colors.error}
            />
          </View>

          {/* QR Code */}
          <QRCodeCard />

          {/* Attendance History */}
          <View style={[commonStyles.card, styles.historyCard]}>
            <Text style={commonStyles.subtitle}>Recent Attendance</Text>
            <View style={styles.attendanceList}>
              {student.attendanceHistory.map((record) => (
                <AttendanceItem key={record.id} record={record} />
              ))}
            </View>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  backButton: {
    padding: spacing.sm,
    marginLeft: -spacing.sm,
  },

  editButton: {
    padding: spacing.sm,
    marginRight: -spacing.sm,
  },

  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },

  profileCard: {
    marginBottom: spacing.md,
  },

  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },

  profilePhoto: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: spacing.md,
  },

  profileInfo: {
    flex: 1,
  },

  studentName: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  studentGrade: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },

  studentClass: {
    fontSize: typography.sizes.md,
    color: colors.primary,
    fontWeight: typography.weights.medium,
  },

  contactInfo: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.md,
  },

  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },

  contactText: {
    fontSize: typography.sizes.md,
    color: colors.text,
    marginLeft: spacing.sm,
  },

  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },

  statCard: {
    width: '48%',
    marginBottom: spacing.sm,
    padding: spacing.md,
  },

  statValue: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  statTitle: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },

  statSubtitle: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
  },

  attendanceStatusCard: {
    marginBottom: spacing.md,
  },

  attendanceStatusItem: {
    flexDirection: 'row',
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  checkOutItem: {
    borderBottomWidth: 0,
  },

  statusIconContainer: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },

  statusContent: {
    flex: 1,
  },

  statusTitle: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  statusTextDetail: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    lineHeight: typography.sizes.md * 1.4,
  },

  qrCard: {
    marginBottom: spacing.md,
  },

  qrCodeContainer: {
    alignItems: 'center',
    padding: spacing.lg,
  },

  qrCodeWrapper: {
    padding: spacing.md,
    backgroundColor: colors.card,
    borderRadius: 12,
    marginBottom: spacing.md,
  },

  qrCodeText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },

  qrInstructions: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    textAlign: 'center',
  },

  historyCard: {
    marginBottom: spacing.lg,
  },

  attendanceList: {
    marginTop: spacing.sm,
  },

  attendanceItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  attendanceDate: {
    flex: 1,
  },

  dateText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
    color: colors.text,
  },

  timeText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },

  attendanceStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  statusIndicator: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },

  statusText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
  },

  classText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginLeft: spacing.sm,
  },
});