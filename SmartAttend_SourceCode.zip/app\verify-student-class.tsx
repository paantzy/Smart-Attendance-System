import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, Alert, TouchableOpacity } from 'react-native';
import { supabase } from '../utils/supabase';

export default function VerifyStudentClassScreen() {
  const [students, setStudents] = useState<any[]>([]);
  const [classTeacherStudents, setClassTeacherStudents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch students
      const { data: studentData, error: studentError } = await supabase
        .from('students')
        .select('*')
        .order('student_name', { ascending: true });

      if (studentError) {
        console.error('Error fetching students:', studentError);
        Alert.alert('Error', `Failed to fetch students: ${studentError.message}`);
        return;
      }

      setStudents(studentData || []);

      // Fetch class-teacher-student relationships
      const { data: ctsData, error: ctsError } = await supabase
        .from('class_teacher_student')
        .select(`
          *,
          student:students!inner(student_name, grade, parent_contact, email_student)
        `)
        .order('created_at', { ascending: false });

      if (ctsError) {
        console.error('Error fetching class-teacher-student relationships:', ctsError);
        Alert.alert('Error', `Failed to fetch class relationships: ${ctsError.message}`);
        return;
      }

      setClassTeacherStudents(ctsData || []);
    } catch (error) {
      console.error('Unexpected error:', error);
      Alert.alert('Error', 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Verify Student-Class Assignment</Text>
      
      <View style={styles.section}>
        <TouchableOpacity 
          style={[styles.button, loading && styles.buttonDisabled]} 
          onPress={fetchData}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? 'Loading...' : 'Refresh Data'}
          </Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Students ({students.length})</Text>
        {students.map((student) => (
          <View key={student.student_id} style={styles.card}>
            <Text style={styles.studentName}>{student.student_name}</Text>
            <Text>Grade: {student.grade}</Text>
            <Text>Class: {student.class_name || 'Not assigned'}</Text>
            <Text>Parent Contact: {student.parent_contact}</Text>
            <Text>Email: {student.email_student}</Text>
          </View>
        ))}
        
        {students.length === 0 && (
          <Text style={styles.emptyText}>No students found</Text>
        )}
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Class Assignments ({classTeacherStudents.length})</Text>
        {classTeacherStudents.map((cts) => (
          <View key={cts.id} style={styles.card}>
            <Text style={styles.studentName}>{cts.student?.student_name || 'Unknown Student'}</Text>
            <Text>Class: {cts.class_name}</Text>
            <Text>Form Level: {cts.form_level}</Text>
            <Text>Teacher: {cts.teacher_name}</Text>
            {cts.teacher_phone && <Text>Teacher Phone: {cts.teacher_phone}</Text>}
          </View>
        ))}
        
        {classTeacherStudents.length === 0 && (
          <Text style={styles.emptyText}>No class assignments found</Text>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: '#333',
  },
  section: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    elevation: 2,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  button: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonDisabled: {
    backgroundColor: '#ccc',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  studentName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  emptyText: {
    textAlign: 'center',
    color: '#666',
    fontStyle: 'italic',
  },
});