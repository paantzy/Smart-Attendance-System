import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Modal,
  Pressable,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router'; // Add useLocalSearchParams
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';
import { supabase } from '@/utils/supabase';

export default function RegisterScreen() {
  const { userType: userTypeParam } = useLocalSearchParams(); // Get user type from params
  console.log('📋 Registration screen loaded with userType param:', userTypeParam);
  const [userType, setUserType] = useState<'parent' | 'teacher' | ''>(userTypeParam === 'parent' ? 'parent' : userTypeParam === 'teacher' ? 'teacher' : '');
  console.log('📋 Initial userType state:', userType);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [childName, setChildName] = useState('');
  const [classValue, setClassValue] = useState(''); // Using classValue to avoid reserved word
  const [loading, setLoading] = useState(false);
  const [isClassDropdownVisible, setIsClassDropdownVisible] = useState(false);

  // If user is trying to register as parent, redirect to parent registration page
  useEffect(() => {
    if (userType === 'parent') {
      router.replace('/parent-register');
    }
  }, [userType]);

  // Class options
  const classOptions = ['Alamanda', 'Alphinia', 'Canna', 'Exora'];

  const validateForm = () => {
    // Common validations
    if (!userType) {
      Alert.alert('Error', 'Please select user type (Teacher)');
      return false;
    }
    
    if (!fullName.trim()) {
      Alert.alert('Error', 'Full Name is required');
      return false;
    }
    
    if (!email.trim()) {
      Alert.alert('Error', 'Email is required');
      return false;
    }
    
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return false;
    }
    
    if (!phone.trim()) {
      Alert.alert('Error', 'Phone is required');
      return false;
    }
    
    if (!password) {
      Alert.alert('Error', 'Password is required');
      return false;
    }
    
    if (password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return false;
    }
    
    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return false;
    }
    
    return true;
  };

  const handleRegister = async () => {
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    console.log('🚀 Starting registration process');
    
    try {
      console.log('📧 Attempting to sign up user:', { email, userType });
      
      // Check network connectivity first
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
        
        const response = await fetch('https://plfkwdyqqgqfnthynpcb.supabase.co/rest/v1/', {
          method: 'HEAD',
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        console.log('🌐 Network connectivity test:', response.status);
      } catch (networkError: any) {
        console.error('❌ Network connectivity test failed:', networkError);
        if (networkError.name === 'AbortError') {
          Alert.alert('Registration Failed', 'Connection timed out. Please check your internet connection and try again.');
        } else {
          Alert.alert('Registration Failed', 'Could not connect to server. Please check your internet connection.');
        }
        setLoading(false);
        return;
      }
      
      // Sign up the user with Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      });
      
      if (authError) {
        console.error('❌ Auth signup error:', authError);
        if (authError.status === 400) {
          Alert.alert('Registration Failed', 'Invalid email or password format.');
        } else if (authError.status === 42501) {
          Alert.alert('Registration Failed', 'Access denied. Please check your API key.');
        } else if (authError.message.includes('Invalid API key') || authError.message.includes('Unauthorized')) {
          Alert.alert('Registration Failed', 'Invalid Supabase API key. Please contact the administrator.');
        } else if (authError.message.includes('Unable to resolve host')) {
          Alert.alert('Registration Failed', 'Could not connect to server. Please check your internet connection.');
        } else {
          Alert.alert('Registration Failed', `Auth Error: ${authError.message}\nCode: ${authError.status || 'Unknown'}`);
        }
        setLoading(false);
        return;
      }
      
      console.log('✅ Auth signup result:', authData);
      
      if (!authData.user) {
        console.error('❌ No user data returned from auth signup');
        Alert.alert('Registration Failed', 'User registration failed - no user data returned');
        setLoading(false);
        return;
      }
      
      // Sign in the user automatically after signup
      const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (signInError) {
        console.error('❌ Auto sign in error:', signInError);
        Alert.alert('Registration Success', 'Account created successfully, but login failed. Please login manually.');
        router.replace('/login');
        setLoading(false);
        return;
      }
      
      console.log('✅ Auto sign in successful:', signInData);
      
      // Save additional user data to the users table
      const userData = {
        id: authData.user.id,
        full_name: fullName,
        email,
        phone,
        user_type: userType,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      console.log('💾 Saving user data to database:', userData);
      
      const { error: insertError } = await supabase
        .from('users')
        .insert([userData]);
      
      if (insertError) {
        console.error('❌ Database insert error:', insertError);
        
        // Handle RLS policy violation (code 42501)
        if (insertError.code === '42501') {
          console.log('ℹ️ RLS policy violation - user data may be handled by trigger function');
          // This is expected behavior - the user data is likely being handled by a trigger
          // Show success message and redirect to login
          Alert.alert(
            'Registration Successful',
            'Your account has been created successfully! Please login with your credentials.',
            [
              {
                text: 'OK',
                onPress: () => {
                  router.replace('/login');
                },
              },
            ]
          );
          setLoading(false);
          return;
        }
        
        // Handle other errors
        if (insertError.message.includes('Unable to resolve host')) {
          Alert.alert('Registration Failed', 'Could not connect to server. Please check your internet connection.');
        } else {
          Alert.alert('Registration Failed', `Database Error: ${insertError.message}\nCode: ${insertError.code || 'Unknown'}`);
        }
        
        setLoading(false);
        return;
      }
      
      console.log('✅ User data saved successfully');
      
      // Registration successful - redirect to login page automatically
      console.log('✅ Registration successful, redirecting to login');
      Alert.alert(
        'Registration Successful',
        'Your account has been created successfully! Please login with your credentials.',
        [
          {
            text: 'OK',
            onPress: () => {
              console.log('User acknowledged registration success');
              router.replace('/login');
            },
          },
        ]
      );
    } catch (error: any) {
      console.error('💥 Registration failed with error:', error);
      if (error.message.includes('Network request failed') || error.message.includes('Unable to resolve host')) {
        Alert.alert('Registration Failed', 'Could not connect to server. Please check your internet connection.');
      } else {
        Alert.alert('Registration Failed', `Unexpected Error: ${error.message || 'An unexpected error occurred'}`);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    router.replace('/login');
  };

  const selectClass = (className: string) => {
    setClassValue(className);
    setIsClassDropdownVisible(false);
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <KeyboardAvoidingView 
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.header}>
            <Text style={styles.title}>Teacher Registration</Text>
            <Text style={styles.subtitle}>Sign up as Teacher</Text>
          </View>

          <View style={styles.formContainer}>
            {/* Common Fields */}
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Full Name</Text>
              <TextInput
                style={commonStyles.input}
                value={fullName}
                onChangeText={setFullName}
                placeholder="Enter your full name"
                placeholderTextColor={colors.textSecondary}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={commonStyles.input}
                value={email}
                onChangeText={setEmail}
                placeholder="Enter your email"
                placeholderTextColor={colors.textSecondary}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Phone</Text>
              <TextInput
                style={commonStyles.input}
                value={phone}
                onChangeText={setPhone}
                placeholder="Enter your phone number"
                placeholderTextColor={colors.textSecondary}
                keyboardType="phone-pad"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Password</Text>
              <TextInput
                style={commonStyles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="Enter your password"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Confirm Password</Text>
              <TextInput
                style={commonStyles.input}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                placeholder="Confirm your password"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry
              />
            </View>

            {/* Action Buttons */}
            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.registerButton}
                onPress={handleRegister}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator size="small" color={colors.card} />
                ) : (
                  <Text style={styles.registerButtonText}>Register</Text>
                )}
              </TouchableOpacity>
            </View>

            <View style={styles.loginContainer}>
              <Text style={styles.loginText}>
                Already have an account?{' '}
                <Text 
                  style={styles.loginLink} 
                  onPress={() => router.replace('/login')}
                >
                  Login here
                </Text>
              </Text>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: spacing.lg,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  title: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },
  formContainer: {
    flex: 1,
  },
  inputGroup: {
    marginBottom: spacing.md,
  },
  label: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  userTypeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: 12,
    backgroundColor: colors.card,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.border,
  },
  userTypeButtonSelected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  userTypeText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },
  userTypeTextSelected: {
    color: colors.card,
  },
  buttonContainer: {
    marginTop: spacing.xl,
    gap: spacing.md,
  },
  registerButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: 12,
    alignItems: 'center',
  },
  registerButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
    color: colors.card,
  },
  loginContainer: {
    marginTop: spacing.lg,
    alignItems: 'center',
  },
  loginText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },
  loginLink: {
    color: colors.primary,
    fontWeight: typography.weights.semibold,
  },
  selectedText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },
  placeholderText: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dropdownContainer: {
    width: '80%',
    maxHeight: 200,
  },
  dropdown: {
    backgroundColor: colors.card,
    borderRadius: 8,
    paddingVertical: spacing.sm,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  dropdownItem: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  dropdownItemText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },
});