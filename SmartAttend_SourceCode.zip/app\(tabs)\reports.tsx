import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Modal,
  LayoutChangeEvent,
  ViewStyle,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { BarChart, LineChart } from 'react-native-chart-kit';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing, shadows } from '@/styles/commonStyles';
import { Dimensions } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useAuth } from '@/contexts/AuthContext';
import { getStudents } from '../../utils/studentOperations';
import { getClassTeacherStudents } from '../../utils/classTeacherStudentOperations';
import { getAttendanceRecords } from '../../utils/attendanceOperations';
import moment from 'moment';
import { Paths, File } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Linking } from 'react-native';

const screenWidth = Dimensions.get('window').width;

interface ReportData {
  byStudent: {
    name: string;
    attendanceRate: number;
    present: number;
    absent: number;
    late: number;
    studentId: string;
  }[];
  byClass: {
    className: string;
    attendanceRate: number;
    totalSessions: number;
    averageAttendance: number;
  }[];
  overall: {
    totalStudents: number;
    totalSessions: number;
    overallRate: number;
    weeklyTrend: number[];
  };
}

// New interface for monthly attendance data
interface MonthlyAttendanceData {
  studentName: string;
  studentId: string;
  className: string;
  form: string;
  attendanceRecords: {
    date: string;
    status: 'present' | 'absent' | 'late';
    checkInTime: string;
    checkOutTime?: string;
  }[];
  totalDays: number;
  presentDays: number;
  absentDays: number;
  lateDays: number;
  attendanceRate: number;
}

// Interface for attendance records
interface AttendanceRecord {
  student_id: string;
  class_name: string;
  check_in_time?: string;
  check_out_time?: string;
  status: 'present' | 'absent' | 'late';
  student?: {
    student_name: string;
    grade: string;
  };
}

export default function ReportsScreen() {
  const { userRole } = useAuth();
  const [dateRange, setDateRange] = useState('This Month');
  const [selectedClass, setSelectedClass] = useState('All Classes');
  const [selectedForm, setSelectedForm] = useState('All Forms');
  const [selectedMonth, setSelectedMonth] = useState(moment().format('YYYY-MM')); // Default to current month
  const [isClassDropdownVisible, setIsClassDropdownVisible] = useState(false);
  const [isFormDropdownVisible, setIsFormDropdownVisible] = useState(false);
  const [isMonthDropdownVisible, setIsMonthDropdownVisible] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [generatingPDF, setGeneratingPDF] = useState(false);
  const [reportData, setReportData] = useState<ReportData>({
    byStudent: [],
    byClass: [],
    overall: {
      totalStudents: 0,
      totalSessions: 0,
      overallRate: 0,
      weeklyTrend: [0, 0, 0, 0, 0, 0, 0],
    },
  });
  
  // State for monthly attendance data
  const [monthlyAttendanceData, setMonthlyAttendanceData] = useState<MonthlyAttendanceData[]>([]);
  
  // Store filtered attendance records for use in charts
  const [filteredAttendanceRecords, setFilteredAttendanceRecords] = useState<AttendanceRecord[]>([]);
  
  // Refs for measuring filter button positions
  const classFilterButtonRef = useRef<View>(null);
  const formFilterButtonRef = useRef<View>(null);
  const monthFilterButtonRef = useRef<View>(null);
  const [classFilterPosition, setClassFilterPosition] = useState({ x: 0, y: 0, width: 0 });
  const [formFilterPosition, setFormFilterPosition] = useState({ x: 0, y: 0, width: 0 });
  const [monthFilterPosition, setMonthFilterPosition] = useState({ x: 0, y: 0, width: 0 });
  
  // Check if user is a parent
  const isParent = userRole === 'parent';
  
  // Class options for the dropdown
  const [classOptions, setClassOptions] = useState<string[]>(['All Classes']);
  const [formOptions, setFormOptions] = useState<string[]>(['All Forms']);
  const [monthOptions, setMonthOptions] = useState<string[]>([]);

  // Generate month options for the last 12 months
  useEffect(() => {
    const months = [];
    const now = moment();
    for (let i = 0; i < 12; i++) {
      months.push(now.clone().subtract(i, 'months').format('YYYY-MM'));
    }
    setMonthOptions(months);
  }, []);

  // Load data on component mount and set up auto-refresh
  useEffect(() => {
    loadData();
    
    // Set up auto-refresh every 30 seconds
    const interval = setInterval(() => {
      loadData();
    }, 30000);
    
    // Clean up interval on component unmount
    return () => clearInterval(interval);
  }, [selectedForm, selectedClass, selectedMonth]);

  // Calculate weekly attendance rates
  const calculateWeeklyAttendanceRate = (attendanceRecords: any[], students: any[]) => {
    const weeklyData = [];
    const today = moment();
    
    // Get the start of the week (Sunday)
    const startOfWeek = today.clone().startOf('week');
    
    // Calculate attendance rate for each day of the week
    for (let i = 0; i < 7; i++) {
      const day = startOfWeek.clone().add(i, 'days');
      const dayString = day.format('YYYY-MM-DD');
      
      // Filter records for this specific day
      const dayRecords = attendanceRecords.filter(record => {
        if (!record.check_in_time) return false;
        const recordDate = moment(record.check_in_time).format('YYYY-MM-DD');
        return recordDate === dayString;
      });
      
      // Calculate attendance rate for this day
      if (dayRecords.length > 0) {
        const presentAndLateCount = dayRecords.filter(record => 
          record.status === 'present' || record.status === 'late'
        ).length;
        const rate = Math.round((presentAndLateCount / dayRecords.length) * 100);
        weeklyData.push(rate);
      } else {
        weeklyData.push(0);
      }
    }
    
    return weeklyData;
  };

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Fetch all required data
      const [students, classTeacherStudents, attendanceRecords] = await Promise.all([
        getStudents(),
        getClassTeacherStudents(),
        getAttendanceRecords()
      ]);
      
      // Debug log to see what data we're working with
      console.log('Raw data from Supabase:');
      console.log('- Students count:', students?.length || 0);
      console.log('- ClassTeacherStudents count:', classTeacherStudents?.length || 0);
      console.log('- AttendanceRecords count:', attendanceRecords?.length || 0);
      
      // Process class options
      let uniqueClasses = ['All Classes', ...Array.from(new Set(classTeacherStudents.map(cts => cts.class_name)))];
      
      // Filter classes based on selected form if not 'All Forms'
      if (selectedForm !== 'All Forms') {
        // Filter classTeacherStudents by the selected form
        const filteredClassTeacherStudents = classTeacherStudents.filter(cts => 
          students.find(s => s.student_id === cts.student_id)?.grade === selectedForm
        );
        uniqueClasses = ['All Classes', ...Array.from(new Set(filteredClassTeacherStudents.map(cts => cts.class_name)))];
      }
      
      setClassOptions(uniqueClasses);
      
      // Process form options
      const uniqueForms = ['All Forms', ...Array.from(new Set(students.map(student => student.grade)))];
      setFormOptions(uniqueForms);
      
      // Filter data based on selected form, class, and month
      let filteredStudents = students;
      let filteredAttendanceRecords = attendanceRecords;
      
      // Filter by form
      if (selectedForm !== 'All Forms') {
        filteredStudents = students.filter(student => student.grade === selectedForm);
        filteredAttendanceRecords = attendanceRecords.filter(record => 
          record.student && record.student.grade === selectedForm
        );
      }
      
      // Filter by class
      if (selectedClass !== 'All Classes') {
        // Filter students by class
        const studentsInClass = classTeacherStudents
          .filter(cts => cts.class_name === selectedClass)
          .map(cts => cts.student_id);
        
        filteredStudents = filteredStudents.filter(student => 
          studentsInClass.includes(student.student_id)
        );
        
        // Filter attendance records by class
        filteredAttendanceRecords = filteredAttendanceRecords.filter(record => 
          record.class_name === selectedClass
        );
      }
      
      // Filter by month
      const selectedMonthStart = moment(selectedMonth, 'YYYY-MM').startOf('month');
      const selectedMonthEnd = moment(selectedMonth, 'YYYY-MM').endOf('month');
      
      filteredAttendanceRecords = filteredAttendanceRecords.filter(record => {
        if (!record.check_in_time) return false;
        const recordDate = moment(record.check_in_time);
        return recordDate.isBetween(selectedMonthStart, selectedMonthEnd, null, '[]');
      });
      
      // Debug log after filtering
      console.log('After filtering:');
      console.log('- Filtered Students count:', filteredStudents?.length || 0);
      console.log('- Filtered AttendanceRecords count:', filteredAttendanceRecords?.length || 0);
      
      // Process student data
      const studentMap = new Map(filteredStudents.map(student => [student.student_id, student]));
      
      // Process attendance data by student
      const studentAttendanceMap = new Map();
      filteredAttendanceRecords.forEach(record => {
        if (!studentAttendanceMap.has(record.student_id)) {
          studentAttendanceMap.set(record.student_id, []);
        }
        studentAttendanceMap.get(record.student_id).push(record);
      });
      
      // Calculate student attendance rates - REAL CALCULATION
      const studentReports = filteredStudents.map(student => {
        const records = studentAttendanceMap.get(student.student_id) || [];
        const presentCount = records.filter((r: any) => r.status === 'present').length;
        const lateCount = records.filter((r: any) => r.status === 'late').length;
        const absentCount = records.filter((r: any) => r.status === 'absent').length;
        const totalCount = records.length; // Total attendance records for this student
        // Calculate attendance rate as (present + late) / total records * 100
        const attendanceRate = totalCount > 0 ? Math.round(((presentCount + lateCount) / totalCount) * 100) : 0;
        
        return {
          name: student.student_name,
          attendanceRate,
          present: presentCount,
          absent: absentCount,
          late: lateCount,
          studentId: student.student_id,
        };
      });
      
      // Process class attendance data - FIXED CALCULATION
      const classAttendanceMap = new Map();
      filteredAttendanceRecords.forEach((record: any) => {
        if (!classAttendanceMap.has(record.class_name)) {
          classAttendanceMap.set(record.class_name, []);
        }
        classAttendanceMap.get(record.class_name).push(record);
      });
      
      // Debug log for class attendance map
      console.log('Class Attendance Map:');
      classAttendanceMap.forEach((records, className) => {
        console.log(`  ${className}: ${records.length} records`);
      });
      
      // Calculate class attendance rates - REAL CALCULATION
      const classReports = Array.from(classAttendanceMap.entries()).map(([className, records]) => {
        // Group records by student to avoid counting multiple check-ins for the same student on the same day
        const studentRecordMap = new Map();
        (records as any[]).forEach((record: any) => {
          if (!studentRecordMap.has(record.student_id)) {
            studentRecordMap.set(record.student_id, []);
          }
          studentRecordMap.get(record.student_id).push(record);
        });
        
        // Count total unique students in this class
        const totalUniqueStudents = studentRecordMap.size;
        
        // Count students with present or late status (at least one record with present/late status)
        let presentOrLateStudents = 0;
        studentRecordMap.forEach((studentRecords, studentId) => {
          // Check if any record for this student has present or late status
          const hasPresentOrLate = studentRecords.some((r: any) => r.status === 'present' || r.status === 'late');
          if (hasPresentOrLate) {
            presentOrLateStudents++;
          }
        });
        
        // Calculate class attendance rate as percentage of students present/late vs total students
        const rawAttendanceRate = totalUniqueStudents > 0 ? (presentOrLateStudents / totalUniqueStudents) * 100 : 0;
        const attendanceRate = Math.min(totalUniqueStudents > 0 ? Math.round(rawAttendanceRate) : 0, 100); // Ensure never exceeds 100
        
        return {
          className,
          attendanceRate,
          totalSessions: records.length,
          averageAttendance: totalUniqueStudents > 0 ? Math.round(records.length / totalUniqueStudents) : 0,
        };
      });

      // Calculate overall statistics
      const totalStudents = filteredStudents.length;
      const totalSessions = filteredAttendanceRecords.length;
      const overallPresentAndLateCount = filteredAttendanceRecords.filter((r: any) => r.status === 'present' || r.status === 'late').length;
      const overallRate = totalSessions > 0 ? Math.round((overallPresentAndLateCount / totalSessions) * 100) : 0;
      
      // Calculate weekly trend
      const weeklyTrend = calculateWeeklyAttendanceRate(filteredAttendanceRecords, filteredStudents);
      
      // Debug log for final results
      console.log('Final Results:');
      console.log('- Student Reports:', studentReports);
      console.log('- Class Reports:', classReports);
      console.log('- Overall Rate:', overallRate);
      
      setReportData({
        byStudent: studentReports,
        byClass: classReports,
        overall: {
          totalStudents,
          totalSessions,
          overallRate,
          weeklyTrend,
        },
      });
      
      // Store the filtered attendance records for use in charts
      setFilteredAttendanceRecords(filteredAttendanceRecords);
    } catch (error) {
      console.error('Error loading report data:', error);
      Alert.alert('Error', 'Failed to load report data');
    } finally {
      setLoading(false);
    }
  };

  // Reload data when form selection changes
  useEffect(() => {
    loadData();
    
    // Update class options based on selected form
    if (selectedForm !== 'All Forms') {
      // Filter class options based on the selected form
      // This would require additional logic to determine which classes belong to which form
      // For now, we'll keep all classes available
    }
    
    // Reset selected class when form changes
    setSelectedClass('All Classes');
  }, [selectedForm]);

  // Measure filter button positions
  const onClassFilterLayout = (event: LayoutChangeEvent) => {
    const { x, y, width, height } = event.nativeEvent.layout;
    setClassFilterPosition({ x, y, width });
  };

  const onFormFilterLayout = (event: LayoutChangeEvent) => {
    const { x, y, width, height } = event.nativeEvent.layout;
    setFormFilterPosition({ x, y, width });
  };

  const onMonthFilterLayout = (event: LayoutChangeEvent) => {
    const { x, y, width, height } = event.nativeEvent.layout;
    setMonthFilterPosition({ x, y, width });
  };

  const weeklyTrendData = {
    labels: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    datasets: [
      {
        data: reportData.overall.weeklyTrend.map(rate => {
          // Ensure values are within the specified range: 20%, 40%, 60%, 80%, 100%
          if (rate <= 20) return 20;
          if (rate <= 40) return 40;
          if (rate <= 60) return 60;
          if (rate <= 80) return 80;
          return 100;
        }),
        color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
        strokeWidth: 3,
      },
    ],
  };

  const studentChartData = {
    labels: reportData.byStudent.map(s => s.name.split(' ')[0]),
    datasets: [
      {
        data: reportData.byStudent.map(s => {
          // Ensure values are within the specified range: 20%, 40%, 60%, 80%, 100%
          if (s.attendanceRate <= 20) return 20;
          if (s.attendanceRate <= 40) return 40;
          if (s.attendanceRate <= 60) return 60;
          if (s.attendanceRate <= 80) return 80;
          return 100;
        }),
        color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
        strokeWidth: 2,
      },
    ],
  };

  // Calculate student status by week (Week 1, Week 2, Week 3, Week 4)
  const studentStatusByWeekData = () => {
    // Initialize week data
    const weeks = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
    const presentData = [0, 0, 0, 0];
    const lateData = [0, 0, 0, 0];
    const absentData = [0, 0, 0, 0];
    
    // Get the selected month start and end dates
    const monthStart = moment(selectedMonth, 'YYYY-MM').startOf('month');
    const monthEnd = moment(selectedMonth, 'YYYY-MM').endOf('month');
    
    // Calculate week ranges
    const weekRanges: { start: moment.Moment; end: moment.Moment }[] = [];
    for (let i = 0; i < 4; i++) {
      const weekStart = monthStart.clone().add(i, 'weeks').startOf('week');
      const weekEnd = weekStart.clone().endOf('week');
      // Make sure week doesn't exceed month end
      if (weekStart.isSameOrBefore(monthEnd)) {
        weekRanges.push({
          start: weekStart,
          end: weekEnd.isSameOrBefore(monthEnd) ? weekEnd : monthEnd
        });
      }
    }
    
    // Use the filtered attendance records from state to get real weekly data
    filteredAttendanceRecords.forEach((record: AttendanceRecord) => {
      if (record.check_in_time) {
        const recordDate = moment(record.check_in_time);
        
        // Determine which week this record belongs to
        for (let i = 0; i < weekRanges.length; i++) {
          const weekRange = weekRanges[i];
          if (recordDate.isBetween(weekRange.start, weekRange.end, null, '[]')) {
            // Increment the appropriate counter based on status
            switch (record.status) {
              case 'present':
                presentData[i]++;
                break;
              case 'late':
                lateData[i]++;
                break;
              case 'absent':
                absentData[i]++;
                break;
            }
            break; // Exit loop once we've found the correct week
          }
        }
      }
    });
    
    // Convert raw counts to values within the specified range: 20%, 40%, 60%, 80%, 100%
    const adjustToPercentageRange = (counts: number[]): number[] => {
      return counts.map(count => {
        // Convert count to a value within the specified range
        if (count <= 20) return 20;
        if (count <= 40) return 40;
        if (count <= 60) return 60;
        if (count <= 80) return 80;
        return 100;
      });
    };
    
    const adjustedPresent = adjustToPercentageRange(presentData);
    const adjustedLate = adjustToPercentageRange(lateData);
    const adjustedAbsent = adjustToPercentageRange(absentData);
    
    return {
      labels: weeks,
      datasets: [
        {
          label: 'Present',
          data: adjustedPresent,
          color: (opacity = 1) => `rgba(76, 175, 80, ${opacity})`, // Green
          strokeWidth: 2,
        },
        {
          label: 'Late',
          data: adjustedLate,
          color: (opacity = 1) => `rgba(255, 152, 0, ${opacity})`, // Orange
          strokeWidth: 2,
        },
        {
          label: 'Absent',
          data: adjustedAbsent,
          color: (opacity = 1) => `rgba(244, 67, 54, ${opacity})`, // Red
          strokeWidth: 2,
        },
      ],
    };
  };

  // Generate report for selected form, class, and month
  const generatePDFReport = async () => {
    try {
      setGeneratingPDF(true);
      
      // Determine report title based on filters
      let reportTitle = 'School-wide Attendance Report';
      if (selectedForm !== 'All Forms' && selectedClass !== 'All Classes') {
        reportTitle = `Attendance Report for ${selectedClass} (${selectedForm})`;
      } else if (selectedForm !== 'All Forms') {
        reportTitle = `Attendance Report for ${selectedForm}`;
      } else if (selectedClass !== 'All Classes') {
        reportTitle = `Attendance Report for ${selectedClass}`;
      }
      
      // Generate HTML content for the report
      let htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Attendance Report</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #333; text-align: center; }
            h2 { color: #555; margin-top: 30px; }
            .summary-grid { display: flex; justify-content: space-between; margin: 20px 0; }
            .summary-card { 
              background: #f5f5f5; 
              border-radius: 8px; 
              padding: 15px; 
              text-align: center; 
              width: 30%; 
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .summary-value { font-size: 24px; font-weight: bold; color: #333; }
            .summary-label { font-size: 14px; color: #666; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #f2f2f2; }
            tr:nth-child(even) { background-color: #f9f9f9; }
            .footer { margin-top: 30px; text-align: center; color: #888; font-size: 12px; }
          </style>
        </head>
        <body>
          <h1>${reportTitle}</h1>
          <p style="text-align: center; color: #666;">${moment(selectedMonth, 'YYYY-MM').format('MMMM YYYY')}</p>
          
          <div class="summary-grid">
            <div class="summary-card">
              <div class="summary-value">${reportData.overall.totalStudents}</div>
              <div class="summary-label">Total Students</div>
            </div>
            <div class="summary-card">
              <div class="summary-value">${reportData.overall.totalSessions}</div>
              <div class="summary-label">Total Sessions</div>
            </div>
            <div class="summary-card">
              <div class="summary-value">${reportData.overall.overallRate}%</div>
              <div class="summary-label">Overall Rate</div>
            </div>
          </div>
          
          <h2>Class Attendance Summary</h2>
          <table>
            <thead>
              <tr>
                <th>Class</th>
                <th>Attendance Rate</th>
                <th>Total Sessions</th>
                <th>Avg Present</th>
              </tr>
            </thead>
            <tbody>
      `;
      
      // Add class data to the report
      reportData.byClass.forEach(classData => {
        htmlContent += `
          <tr>
            <td>${classData.className}</td>
            <td>${classData.attendanceRate}%</td>
            <td>${classData.totalSessions}</td>
            <td>${classData.averageAttendance}</td>
          </tr>
        `;
      });
      
      htmlContent += `
            </tbody>
          </table>
      `;
      
      // Add student data to the report if a specific class is selected
      if (selectedClass !== 'All Classes') {
        htmlContent += `
          <h2>Student Attendance Details</h2>
          <table>
            <thead>
              <tr>
                <th>Student Name</th>
                <th>Attendance Rate</th>
                <th>Present</th>
                <th>Absent</th>
                <th>Late</th>
              </tr>
            </thead>
            <tbody>
        `;
        
        reportData.byStudent.forEach(student => {
          htmlContent += `
            <tr>
              <td>${student.name}</td>
              <td>${student.attendanceRate}%</td>
              <td>${student.present}</td>
              <td>${student.absent}</td>
              <td>${student.late}</td>
            </tr>
          `;
        });
        
        htmlContent += `
            </tbody>
          </table>
        `;
      }
      
      htmlContent += `
          <div class="footer">
            <p>Report generated on ${new Date().toLocaleDateString()}</p>
            <p>SmartAttend - Student Attendance Management System</p>
          </div>
        </body>
        </html>
      `;
      
      // Save HTML file
      const fileName = `attendance-report-${selectedMonth}-${new Date().getTime()}.html`;
      const file = new File(Paths.cache, fileName);
      const filePath = file.uri;
      
      file.write(htmlContent, { encoding: 'utf8' });
      
      // Share the file
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(filePath);
        Alert.alert('Success', 'Report generated and shared successfully!');
      } else {
        throw new Error('Sharing is not available on this device');
      }
    } catch (error) {
      console.error('Error generating report:', error);
      Alert.alert('Error', 'Failed to generate report: ' + (error as Error).message);
    } finally {
      setGeneratingPDF(false);
    }
  };

  const showDatepicker = () => {
    setShowDatePicker(true);
  };

  // Date picker change handler
  const onChangeDate = (event: any, selectedDate?: Date) => {
    const currentDate = selectedDate || new Date();
    setShowDatePicker(Platform.OS === 'ios' ? true : false);
    setSelectedDate(currentDate);
  };

  const SummaryCard = ({ title, value, subtitle, icon, color }: {
    title: string;
    value: string;
    subtitle: string;
    icon: string;
    color: string;
  }) => (
    <View style={[styles.summaryCard, commonStyles.card]}>
      <View style={[styles.summaryIcon, { backgroundColor: color }]}>
        <IconSymbol name={icon as any} size={24} color={colors.card} />
      </View>
      <View style={styles.summaryContent}>
        <Text style={styles.summaryTitle}>{title}</Text>
        <Text style={styles.summaryValue}>{value}</Text>
        <Text style={styles.summarySubtitle}>{subtitle}</Text>
      </View>
    </View>
  );

  const StudentReportCard = ({ student }: { student: ReportData['byStudent'][0] }) => (
    <View style={[commonStyles.card, styles.reportCard]}>
      <View style={styles.reportHeader}>
        <Text style={styles.reportName}>{student.name}</Text>
        <View style={[
          styles.rateBadge,
          { backgroundColor: student.attendanceRate >= 80 ? colors.success : 
            student.attendanceRate >= 60 ? colors.warning : colors.error }
        ]}>
          <Text style={styles.rateText}>{student.attendanceRate}%</Text>
        </View>
      </View>
      <View style={styles.reportStats}>
        <View style={styles.statItem}>
          <IconSymbol name="checkmark" size={16} color={colors.success} />
          <Text style={styles.statValue}>{student.present}</Text>
          <Text style={styles.statLabel}>Present</Text>
        </View>
        <View style={styles.statItem}>
          <IconSymbol name="xmark" size={16} color={colors.error} />
          <Text style={styles.statValue}>{student.absent}</Text>
          <Text style={styles.statLabel}>Absent</Text>
        </View>
        <View style={styles.statItem}>
          <IconSymbol name="clock" size={16} color={colors.warning} />
          <Text style={styles.statValue}>{student.late}</Text>
          <Text style={styles.statLabel}>Late</Text>
        </View>
      </View>
    </View>
  );

  const ClassReportCard = ({ classData }: { classData: ReportData['byClass'][0] }) => (
    <View style={[commonStyles.card, styles.reportCard]}>
      <View style={styles.reportHeader}>
        <Text style={styles.reportName}>{classData.className}</Text>
        <View style={[
          styles.rateBadge,
          { backgroundColor: classData.attendanceRate >= 80 ? colors.success : 
            classData.attendanceRate >= 60 ? colors.warning : colors.error }
        ]}>
          <Text style={styles.rateText}>{classData.attendanceRate}%</Text>
        </View>
      </View>
      <View style={styles.reportStats}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{classData.totalSessions}</Text>
          <Text style={styles.statLabel}>Sessions</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{classData.averageAttendance}</Text>
          <Text style={styles.statLabel}>Avg Present</Text>
        </View>
      </View>
    </View>
  );

  const renderReportContent = () => {
    if (loading) {
      return (
        <View style={styles.loadingContainer}>
          <Text>Loading report data...</Text>
        </View>
      );
    }

    // Determine what to display based on filters
    let contentTitle = 'School-wide Attendance Report';
    if (selectedForm !== 'All Forms' && selectedClass !== 'All Classes') {
      contentTitle = `Attendance Report for ${selectedClass} (${selectedForm})`;
    } else if (selectedForm !== 'All Forms') {
      contentTitle = `Attendance Report for ${selectedForm}`;
    } else if (selectedClass !== 'All Classes') {
      contentTitle = `Attendance Report for ${selectedClass}`;
    }

    return (
      <View>
        <View style={[commonStyles.card, styles.chartCard]}>
          <Text style={commonStyles.subtitle}>{contentTitle}</Text>
          <Text style={styles.filterInfo}>
            {moment(selectedMonth, 'YYYY-MM').format('MMMM YYYY')}
          </Text>
        </View>

        {/* Summary Cards */}
        <View style={styles.summaryGrid}>
          <SummaryCard
            title="Total Students"
            value={reportData.overall.totalStudents.toString()}
            subtitle="Enrolled"
            icon="person.3.fill"
            color={colors.primary}
          />
          <SummaryCard
            title="Total Sessions"
            value={reportData.overall.totalSessions.toString()}
            subtitle="Completed"
            icon="calendar"
            color={colors.secondary}
          />
          <SummaryCard
            title="Overall Rate"
            value={`${reportData.overall.overallRate}%`}
            subtitle="Attendance"
            icon="chart.bar.fill"
            color={colors.success}
          />
        </View>

        {/* Weekly Trend Chart */}
        <View style={[commonStyles.card, styles.chartCard]}>
          <Text style={commonStyles.subtitle}>Weekly Attendance Trend</Text>
          <LineChart
            data={weeklyTrendData}
            width={screenWidth - 80}
            height={220}
            yAxisLabel=""
            chartConfig={{
              backgroundColor: colors.card,
              backgroundGradientFrom: colors.card,
              backgroundGradientTo: colors.card,
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(33, 33, 33, ${opacity})`,
              style: { borderRadius: 16 },
              propsForDots: {
                r: '6',
                strokeWidth: '2',
                stroke: colors.primary,
              },
            }}
            bezier
            style={styles.chart}
            yAxisSuffix="%"
          />
        </View>

        {/* Student Status by Week Chart */}
        <View style={[commonStyles.card, styles.chartCard]}>
          <Text style={commonStyles.subtitle}>Student Status by Week</Text>
          <BarChart
            data={studentStatusByWeekData()}
            width={screenWidth - 80}
            height={220}
            yAxisLabel=""
            chartConfig={{
              backgroundColor: colors.card,
              backgroundGradientFrom: colors.card,
              backgroundGradientTo: colors.card,
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(33, 33, 33, ${opacity})`,
              style: { borderRadius: 16 },
              propsForDots: {
                r: '6',
                strokeWidth: '2',
                stroke: colors.primary,
              },
            }}
            style={styles.chart}
            yAxisSuffix=""
            fromZero
            showValuesOnTopOfBars
          />
        </View>

        {/* Class Reports */}
        {reportData.byClass.map((classData, index) => (
          <ClassReportCard key={index} classData={classData} />
        ))}

        {/* Student Reports (only show when a specific class is selected) */}
        {selectedClass !== 'All Classes' && reportData.byStudent.map((student, index) => (
          <StudentReportCard key={student.studentId} student={student} />
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={commonStyles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={commonStyles.title}>Reports</Text>
          <View style={styles.exportButtons}>
            {/* Report generation option */}
            <TouchableOpacity
              style={styles.exportButton}
              onPress={generatePDFReport}
              disabled={generatingPDF}
            >
              <Text style={styles.exportText}>
                {generatingPDF ? 'Generating...' : 'Generate Report'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Filters */}
        <View style={styles.filtersContainer}>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filtersContent}
          >
            <View style={styles.filterContainer} onLayout={onFormFilterLayout}>
              <TouchableOpacity 
                ref={formFilterButtonRef}
                style={styles.filterButton}
                onPress={() => setIsFormDropdownVisible(!isFormDropdownVisible)}
              >
                <IconSymbol name="book" size={16} color={colors.textSecondary} />
                <Text style={styles.filterText}>{selectedForm}</Text>
                <IconSymbol name="chevron.down" size={12} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.filterContainer} onLayout={onClassFilterLayout}>
              <TouchableOpacity 
                ref={classFilterButtonRef}
                style={styles.filterButton}
                onPress={() => setIsClassDropdownVisible(!isClassDropdownVisible)}
              >
                <IconSymbol name="square.grid.2x2" size={16} color={colors.textSecondary} />
                <Text style={styles.filterText}>{selectedClass}</Text>
                <IconSymbol name="chevron.down" size={12} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.filterContainer} onLayout={onMonthFilterLayout}>
              <TouchableOpacity 
                ref={monthFilterButtonRef}
                style={styles.filterButton}
                onPress={() => setIsMonthDropdownVisible(!isMonthDropdownVisible)}
              >
                <IconSymbol name="calendar" size={16} color={colors.textSecondary} />
                <Text style={styles.filterText}>
                  {moment(selectedMonth, 'YYYY-MM').format('MMMM YYYY')}
                </Text>
                <IconSymbol name="chevron.down" size={12} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>
          </ScrollView>
          
          {/* Form Dropdown Options */}
          {isFormDropdownVisible && (
            <View style={[styles.dropdownOptions, { 
              left: formFilterPosition.x,
              top: formFilterPosition.y + formFilterPosition.width + 10
            } as ViewStyle]}>
              {formOptions.map((option) => (
                <TouchableOpacity
                  key={option}
                  style={styles.dropdownOption}
                  onPress={() => {
                    setSelectedForm(option);
                    setIsFormDropdownVisible(false);
                    // Reset class selection when form changes
                    setSelectedClass('All Classes');
                  }}
                >
                  <Text style={[
                    styles.dropdownOptionText,
                    selectedForm === option && { fontWeight: 'bold' }
                  ]}>
                    {option}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
          
          {/* Class Dropdown Options */}
          {isClassDropdownVisible && (
            <View style={[styles.dropdownOptions, { 
              left: classFilterPosition.x,
              top: classFilterPosition.y + classFilterPosition.width + 10
            } as ViewStyle]}>
              {classOptions.map((option) => (
                <TouchableOpacity
                  key={option}
                  style={styles.dropdownOption}
                  onPress={() => {
                    setSelectedClass(option);
                    setIsClassDropdownVisible(false);
                  }}
                >
                  <Text style={[
                    styles.dropdownOptionText,
                    selectedClass === option && { fontWeight: 'bold' }
                  ]}>
                    {option}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
          
          {/* Month Dropdown Options */}
          {isMonthDropdownVisible && (
            <View style={[styles.dropdownOptions, { 
              left: monthFilterPosition.x,
              top: monthFilterPosition.y + monthFilterPosition.width + 10
            } as ViewStyle]}>
              {monthOptions.map((option) => (
                <TouchableOpacity
                  key={option}
                  style={styles.dropdownOption}
                  onPress={() => {
                    setSelectedMonth(option);
                    setIsMonthDropdownVisible(false);
                  }}
                >
                  <Text style={[
                    styles.dropdownOptionText,
                    selectedMonth === option && { fontWeight: 'bold' }
                  ]}>
                    {moment(option, 'YYYY-MM').format('MMMM YYYY')}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        {/* Date Picker */}
        {showDatePicker && (
          <DateTimePicker
            testID="dateTimePicker"
            value={selectedDate}
            mode="date"
            is24Hour={true}
            onChange={onChangeDate}
            display="default"
            style={{ backgroundColor: 'transparent' }}
          />
        )}

        {/* Content */}
        <ScrollView
          style={styles.content}
          contentContainerStyle={commonStyles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {renderReportContent()}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  exportButtons: {
    flexDirection: 'row',
  },

  exportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 16,
    marginLeft: spacing.xs,
    ...shadows.sm,
  },

  exportText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginLeft: spacing.xs,
  },

  filtersContainer: {
    paddingVertical: spacing.sm,
    position: 'relative',
  },

  filtersContent: {
    paddingHorizontal: spacing.md,
  },
  
  filterContainer: {
    position: 'relative',
  },

  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
    marginRight: spacing.sm,
    ...shadows.sm,
  },

  filterText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
    marginHorizontal: spacing.xs,
  },

  dropdownOptions: {
    position: 'absolute',
    backgroundColor: colors.card,
    borderRadius: 12,
    ...shadows.md,
    zIndex: 100,
    minWidth: 150,
    maxHeight: 200,
  },

  dropdownOption: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
  },

  dropdownOptionText: {
    fontSize: typography.sizes.sm,
    color: colors.text,
  },

  content: {
    flex: 1,
    paddingHorizontal: spacing.md,
  },

  summaryGrid: {
    marginBottom: spacing.lg,
  },

  summaryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },

  summaryIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },

  summaryContent: {
    flex: 1,
  },

  summaryTitle: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },

  summaryValue: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.xs,
  },

  summarySubtitle: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },

  chartCard: {
    marginBottom: spacing.lg,
    alignItems: 'center',
  },

  chart: {
    marginVertical: spacing.sm,
    borderRadius: 16,
  },
  
  datePickerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },

  datePickerContent: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: spacing.lg,
    alignItems: 'center',
    ...shadows.lg,
  },

  datePickerCancelButton: {
    marginTop: spacing.md,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    backgroundColor: colors.error,
    borderRadius: 12,
  },

  datePickerCancelText: {
    color: colors.card,
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
  },

  reportCard: {
    marginBottom: spacing.md,
  },

  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },

  reportName: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },

  rateBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 12,
  },

  rateText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.bold,
    color: colors.card,
  },

  reportStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },

  statItem: {
    alignItems: 'center',
  },

  statValue: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.text,
  },

  statLabel: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.xxl,
  },

  // Add the missing filterInfo style
  filterInfo: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
});